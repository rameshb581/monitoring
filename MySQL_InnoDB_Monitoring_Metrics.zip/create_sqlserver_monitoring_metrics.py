import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Create workbook
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "SQL Server Monitoring Metrics"

# Define column headers (exact same as MySQL sheet)
headers = [
    "Metric Name",
    "Category",
    "Description",
    "Business Impact",
    "Technical Explanation",
    "Normal/Healthy Range",
    "Warning Threshold",
    "Critical Threshold",
    "Severity Level",
    "Monitoring Tool/Exporter",
    "Recommended Alert"
]

# Write headers
for col_num, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num)
    cell.value = header
    cell.font = Font(bold=True, color="FFFFFF", size=11)
    cell.fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

# Set column widths (same as MySQL sheet)
column_widths = {
    'A': 35,  # Metric Name
    'B': 20,  # Category
    'C': 40,  # Description
    'D': 45,  # Business Impact
    'E': 45,  # Technical Explanation
    'F': 25,  # Normal/Healthy Range
    'G': 25,  # Warning Threshold
    'H': 25,  # Critical Threshold
    'I': 15,  # Severity Level
    'J': 30,  # Monitoring Tool
    'K': 15   # Recommended Alert
}

for col_letter, width in column_widths.items():
    ws.column_dimensions[col_letter].width = width

# Comprehensive SQL Server metrics data
metrics_data = [
    # === REAL-TIME OPERATIONAL METRICS - CONNECTION METRICS ===
    [
        "User Connections",
        "Real-time Operational",
        "Number of currently active user connections to SQL Server",
        "High connections can indicate traffic spikes or connection leaks, leading to performance degradation. If maxed out, new users cannot connect, causing downtime and revenue loss.",
        "Each connection consumes memory and resources. Limited by user connections configuration or licenses.",
        "< 70% of max connections",
        "> 70% of max connections",
        "> 90% of max connections",
        "High",
        "DMV: sys.dm_exec_connections, SSMS, Azure Monitor, Grafana SQL Exporter",
        "Yes"
    ],
    [
        "Connection Memory (KB)",
        "Real-time Operational",
        "Amount of memory consumed by all current connections",
        "Excessive connection memory can starve other SQL Server components, causing queries to fail or performance to degrade severely.",
        "Each connection requires memory for context, session data, and query execution. Monitored via sys.dm_os_memory_clerks.",
        "< 10% of total server memory",
        "> 15% of total server memory",
        "> 25% of total server memory",
        "Medium",
        "DMV: sys.dm_os_memory_clerks, Azure Monitor",
        "Yes"
    ],
    [
        "Failed Login Attempts (per minute)",
        "Real-time Operational",
        "Number of failed authentication attempts",
        "May indicate brute force attacks, misconfigured applications, or credential issues. Security threat and user access problems.",
        "Tracked via error log and audit. Error 18456 indicates login failures. Pattern analysis helps detect attacks.",
        "< 5 per minute",
        "> 10 per minute",
        "> 50 per minute or coordinated pattern",
        "Critical",
        "SQL Server Error Log, Extended Events, SQL Audit, Azure Monitor",
        "Yes"
    ],
    [
        "Logins/sec",
        "Real-time Operational",
        "Rate of login attempts per second",
        "Sudden spikes may indicate connection storms or application misconfigurations. High login rates consume resources and impact performance.",
        "Performance counter showing login activity rate. Very high rates suggest connection pooling issues.",
        "Baseline login rate",
        "> 150% of baseline",
        "> 200% or causing CPU spikes",
        "Medium",
        "Perfmon: SQLServer:General Statistics, Azure Monitor, Grafana SQL Exporter",
        "Yes"
    ],
    [
        "Logouts/sec",
        "Real-time Operational",
        "Rate of logout/disconnection events per second",
        "High logout rate may indicate application errors, network instability, or connection pool thrashing - impacts user experience.",
        "Tracks connection terminations. Compare with Logins/sec to understand connection churn.",
        "Similar to Logins/sec",
        "Much higher than Logins/sec",
        "Extreme mismatch or constant churn",
        "Medium",
        "Perfmon: SQLServer:General Statistics, Azure Monitor",
        "Yes"
    ],
    [
        "Blocked Process Count",
        "Real-time Operational",
        "Number of processes currently blocked waiting for resources",
        "Blocked processes cause application timeouts and slow response times. Users see 'loading' screens indefinitely - poor experience and lost transactions.",
        "Queries waiting for locks held by other queries. Check sys.dm_exec_requests for blocking details.",
        "0-2 processes",
        "> 5 processes",
        "> 20 processes or sustained blocking",
        "Critical",
        "DMV: sys.dm_exec_requests, sys.dm_os_waiting_tasks, SSMS Activity Monitor",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - QUERY PERFORMANCE ===
    [
        "Batch Requests/sec",
        "Real-time Operational",
        "Number of T-SQL batches received per second",
        "Primary indicator of database workload and user activity. Sudden drops indicate service problems; spikes may cause performance issues and resource exhaustion.",
        "Key throughput metric. Includes all batches from clients. Baseline varies by application - monitor for significant deviations.",
        "Baseline batch rate",
        "> 150% of baseline or drop > 30%",
        "> 200% of baseline or drop > 50%",
        "High",
        "Perfmon: SQLServer:SQL Statistics, Azure Monitor, Grafana SQL Exporter",
        "Yes"
    ],
    [
        "SQL Compilations/sec",
        "Real-time Operational",
        "Rate of query compilation events per second",
        "Excessive compilations waste CPU and indicate poor query plan reuse. Causes high CPU, slow queries, and degraded application performance.",
        "SQL Server compiles execution plans for new queries. High rate suggests lack of parameterization or plan cache pressure.",
        "< 10% of Batch Requests/sec",
        "> 20% of Batch Requests/sec",
        "> 40% or causing CPU saturation",
        "High",
        "Perfmon: SQLServer:SQL Statistics, Azure Monitor, Grafana SQL Exporter",
        "Yes"
    ],
    [
        "SQL Re-Compilations/sec",
        "Real-time Operational",
        "Number of query recompilations per second",
        "Recompilations are even more expensive than compilations, consuming CPU and slowing query execution. Impacts all user queries.",
        "Plans invalidated due to schema changes, statistics updates, or plan cache pressure. Should be minimal.",
        "< 10% of Compilations/sec",
        "> 20% of Compilations/sec",
        "> 50% or constant recompilation",
        "High",
        "Perfmon: SQLServer:SQL Statistics, Azure Monitor, Extended Events",
        "Yes"
    ],
    [
        "Average Query Execution Time (ms)",
        "Real-time Operational",
        "Mean time to execute queries",
        "Slow queries directly degrade user experience - pages load slowly, transactions timeout. Customers abandon carts and leave negative reviews.",
        "Calculated from sys.dm_exec_query_stats or Extended Events. Baseline varies by application but sudden increases indicate problems.",
        "< 100ms (OLTP workloads)",
        "> 500ms average",
        "> 2000ms or steadily increasing",
        "Critical",
        "DMV: sys.dm_exec_query_stats, Extended Events, Azure Monitor",
        "Yes"
    ],
    [
        "Long Running Queries (> 30 sec)",
        "Real-time Operational",
        "Count of queries executing longer than 30 seconds",
        "Long queries block resources, cause timeouts, and frustrate users. May indicate missing indexes, poor query design, or blocking issues.",
        "Query sys.dm_exec_requests for queries with elapsed time > 30000ms. Investigate and optimize or kill if necessary.",
        "0-2 queries",
        "> 5 queries",
        "> 10 queries or queries > 5 minutes",
        "High",
        "DMV: sys.dm_exec_requests, SSMS Activity Monitor, Extended Events",
        "Yes"
    ],
    [
        "Page Life Expectancy (PLE)",
        "Real-time Operational",
        "Average seconds a data page stays in buffer cache before being flushed",
        "Low PLE means frequent disk reads - 100x slower than memory. Causes terrible query performance and poor user experience across the board.",
        "Key buffer cache health metric. < 300 seconds indicates memory pressure. Target: > 300 seconds per 4GB of buffer pool.",
        "> 300 sec/4GB buffer pool",
        "< 300 seconds",
        "< 100 seconds or rapidly declining",
        "Critical",
        "Perfmon: SQLServer:Buffer Manager, Azure Monitor, Grafana SQL Exporter",
        "Yes"
    ],
    [
        "Buffer Cache Hit Ratio",
        "Real-time Operational",
        "Percentage of data pages found in memory vs read from disk",
        "THE KEY cache performance metric. < 95% means too many slow disk reads, poor query performance, frustrated users.",
        "Should be > 98% for OLTP. < 95% indicates insufficient memory or inefficient queries causing cache thrashing.",
        "> 98% (OLTP), > 90% (OLAP)",
        "< 95%",
        "< 90% or steadily declining",
        "Critical",
        "Perfmon: SQLServer:Buffer Manager, Azure Monitor, Grafana SQL Exporter",
        "Yes"
    ],
    [
        "Lazy Writes/sec",
        "Real-time Operational",
        "Rate of dirty pages flushed to disk by lazy writer due to memory pressure",
        "Non-zero values indicate memory pressure. SQL Server is freeing memory aggressively - causes slow queries and instability.",
        "Lazy writer flushes dirty pages when SQL Server needs memory. Should be zero or minimal. Sustained activity = serious memory pressure.",
        "0 or near 0",
        "> 20 per second",
        "> 50 per second or sustained",
        "Critical",
        "Perfmon: SQLServer:Buffer Manager, Azure Monitor",
        "Yes"
    ],
    [
        "Page Reads/sec",
        "Real-time Operational",
        "Number of physical page reads from disk per second",
        "High values indicate buffer cache misses requiring slow disk reads. Directly correlates with query slowness.",
        "Physical I/O operations. Compare with Page Lookups/sec to calculate cache hit ratio. High rate suggests memory or I/O issues.",
        "Baseline I/O rate (app dependent)",
        "> 150% of baseline",
        "> 200% or I/O saturation",
        "High",
        "Perfmon: SQLServer:Buffer Manager, Azure Monitor",
        "Yes"
    ],
    [
        "Page Writes/sec",
        "Real-time Operational",
        "Number of physical page writes to disk per second",
        "Excessive writes can saturate disks causing slowdowns for all operations. Checkpoint and lazy writer activity indicator.",
        "Physical write I/O. Includes checkpoint writes and lazy writes. Very high rates indicate heavy write workload or memory pressure.",
        "Baseline write I/O rate",
        "> 150% of baseline",
        "> 200% or disk saturation",
        "Medium",
        "Perfmon: SQLServer:Buffer Manager, Azure Monitor",
        "Yes"
    ],
    [
        "Checkpoint Pages/sec",
        "Real-time Operational",
        "Pages flushed to disk per second by checkpoint process",
        "High checkpoint activity can cause I/O spikes and temporary performance degradation. Helps understand write workload patterns.",
        "Checkpoint flushes dirty pages to ensure recovery point. Indirect checkpoints smooth this out. Very high rates indicate heavy write load.",
        "Varies by recovery model",
        "> 10,000 pages/sec",
        "> 50,000 pages/sec or causing I/O contention",
        "Medium",
        "Perfmon: SQLServer:Buffer Manager, Azure Monitor",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - WAIT STATISTICS ===
    [
        "PAGEIOLATCH_* Waits",
        "Real-time Operational",
        "Time waiting for data pages to be read from disk into memory",
        "Direct indicator of I/O bottleneck. Queries waiting for disk I/O = slow application = poor user experience. May need more memory or faster storage.",
        "Most common wait type for I/O bound systems. Indicates buffer cache misses. Address by adding memory or improving I/O subsystem.",
        "< 20% of total wait time",
        "> 30% of total wait time",
        "> 50% or sustained I/O waits",
        "Critical",
        "DMV: sys.dm_os_wait_stats, sys.dm_exec_requests, Extended Events",
        "Yes"
    ],
    [
        "CXPACKET Waits",
        "Real-time Operational",
        "Wait time for query parallelism coordination",
        "High CXPACKET waits indicate inefficient parallel query execution. Queries may run slower than serial execution - wasted CPU and poor performance.",
        "Threads in parallel query waiting for each other. May indicate poor parallelism configuration or queries better run serially.",
        "< 10% of total wait time",
        "> 20% of total wait time",
        "> 30% with performance issues",
        "Medium",
        "DMV: sys.dm_os_wait_stats, Extended Events",
        "Yes"
    ],
    [
        "WRITELOG Waits",
        "Real-time Operational",
        "Time waiting for transaction log writes to complete",
        "Log write waits pause all transactions. Slow log disk = slow commits = poor application throughput. Critical for transaction-heavy systems.",
        "Transactions wait for log flush to ensure durability. High waits indicate slow log disk or excessive transaction log writes.",
        "< 10% of total wait time",
        "> 15% of total wait time",
        "> 25% or causing transaction delays",
        "Critical",
        "DMV: sys.dm_os_wait_stats, sys.dm_io_virtual_file_stats",
        "Yes"
    ],
    [
        "LCK_* Waits",
        "Real-time Operational",
        "Time spent waiting to acquire locks on database resources",
        "Lock waits mean queries blocked by other queries. Users experience delays and timeouts. Indicates locking/blocking problems.",
        "Queries waiting for row, page, table, or other locks. High values suggest poor transaction design or blocking chains.",
        "< 5% of total wait time",
        "> 10% of total wait time",
        "> 20% or sustained blocking",
        "High",
        "DMV: sys.dm_os_wait_stats, sys.dm_tran_locks",
        "Yes"
    ],
    [
        "ASYNC_NETWORK_IO Waits",
        "Real-time Operational",
        "SQL Server waiting for client application to consume results",
        "Indicates application not reading results fast enough. May suggest network issues or application problems, not database issues.",
        "SQL Server has results ready but client isn't retrieving them. Often application or network issue, not SQL Server problem.",
        "< 5% of total wait time",
        "> 10% of total wait time",
        "> 15% with application issues",
        "Low",
        "DMV: sys.dm_os_wait_stats, Extended Events",
        "No"
    ],
    [
        "SOS_SCHEDULER_YIELD Waits",
        "Real-time Operational",
        "CPU pressure - threads yielding CPU to others due to exhaustion",
        "High CPU waits indicate CPU saturation. All queries slow down competing for CPU cycles. May need CPU upgrade or query optimization.",
        "Scheduler yielding after exhausting quantum (4ms). High values indicate CPU pressure or inefficient queries.",
        "< 10% of total wait time",
        "> 20% of total wait time",
        "> 40% or CPU consistently at 100%",
        "High",
        "DMV: sys.dm_os_wait_stats, Perfmon CPU counters",
        "Yes"
    ],
    [
        "RESOURCE_SEMAPHORE Waits",
        "Real-time Operational",
        "Queries waiting for memory grants to execute",
        "Memory grant waits mean queries queued waiting for memory. Causes severe performance degradation and timeouts. Indicates memory pressure.",
        "Query needs memory for sorts, hashes, etc. but insufficient memory available. Queries queue up waiting - very bad for performance.",
        "0 or minimal",
        "> 5% of total wait time",
        "> 10% or queries timing out",
        "Critical",
        "DMV: sys.dm_os_wait_stats, sys.dm_exec_query_memory_grants",
        "Yes"
    ],
    [
        "PAGELATCH_* Waits",
        "Real-time Operational",
        "Contention on in-memory data page latches",
        "In-memory contention (not I/O). Multiple sessions fighting for same pages. Causes slowdowns even with sufficient memory.",
        "Latch contention on pages already in memory. Common on tempdb or allocation pages. Different from PAGEIOLATCH (which is I/O).",
        "< 5% of total wait time",
        "> 10% of total wait time",
        "> 15% with TempDB contention",
        "Medium",
        "DMV: sys.dm_os_wait_stats, sys.dm_os_latch_stats",
        "Yes"
    ],
    [
        "THREADPOOL Waits",
        "Real-time Operational",
        "Waiting for available worker thread from thread pool",
        "Thread pool exhaustion - no threads available for new queries. Queries queue up, causing severe delays. Often from connection leaks or blocking.",
        "SQL Server thread pool exhausted. Max worker threads reached. Indicates too many concurrent requests or long-running queries.",
        "0",
        "> 0 (any occurrences)",
        "Sustained or many waiting",
        "Critical",
        "DMV: sys.dm_os_wait_stats, sys.dm_os_workers",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - LOCKS & DEADLOCKS ===
    [
        "Lock Waits/sec",
        "Real-time Operational",
        "Number of lock requests that couldn't be satisfied immediately",
        "Lock waits cause query delays and poor application responsiveness. Users experience slow transactions and potential timeouts.",
        "Lock requests that had to wait for another lock to be released. High rate indicates contention and blocking.",
        "< 10 per second",
        "> 50 per second",
        "> 100 per second",
        "High",
        "Perfmon: SQLServer:Locks, DMV: sys.dm_tran_locks",
        "Yes"
    ],
    [
        "Lock Wait Time (ms)",
        "Real-time Operational",
        "Cumulative wait time for lock acquisitions",
        "Total time queries spent waiting for locks. Higher values indicate increasing contention and transaction delays.",
        "Sum of all lock wait time. Monitor rate of increase to identify worsening contention patterns.",
        "Minimal increase rate",
        "Rapid increase (> 1000ms/sec)",
        "Very rapid increase (> 5000ms/sec)",
        "High",
        "Perfmon: SQLServer:Locks, DMV: sys.dm_os_wait_stats",
        "Yes"
    ],
    [
        "Average Lock Wait Time (ms)",
        "Real-time Operational",
        "Average duration per lock wait event",
        "High average wait time indicates problematic locking patterns or long-running transactions blocking others.",
        "Lock Wait Time / Lock Waits. Shows typical duration queries wait for locks. > 100ms indicates issues.",
        "< 50ms",
        "> 100ms",
        "> 500ms",
        "Medium",
        "Perfmon: SQLServer:Locks (calculated)",
        "Yes"
    ],
    [
        "Number of Deadlocks/sec",
        "Real-time Operational",
        "Rate of deadlock occurrences",
        "Deadlocks cause transaction failures. Users see errors, operations fail, and must retry - very poor experience and lost business.",
        "Two or more transactions waiting for each other's locks. SQL Server chooses victim and rolls back. Application sees error 1205.",
        "0 (occasional acceptable < 1/hour)",
        "> 1 per hour",
        "> 5 per hour or sudden spike",
        "Critical",
        "Perfmon: SQLServer:Locks, Extended Events, sys.dm_os_performance_counters",
        "Yes"
    ],
    [
        "Lock Memory (KB)",
        "Real-time Operational",
        "Memory consumed by lock structures",
        "Excessive lock memory can indicate lock escalation issues or too many locks held. Consumes memory needed for queries.",
        "Memory used for lock manager structures. Very high values may indicate poorly designed transactions or lock escalation problems.",
        "< 5% of total server memory",
        "> 10% of total server memory",
        "> 20% or causing memory pressure",
        "Medium",
        "DMV: sys.dm_os_memory_clerks, Perfmon",
        "Yes"
    ],
    [
        "Lock Timeouts/sec",
        "Real-time Operational",
        "Lock requests that timed out (excluding NOWAIT requests)",
        "Lock timeouts cause application errors and failed transactions. Users see 'Lock request timeout' errors - transactions must retry.",
        "Lock wait exceeded LOCK_TIMEOUT setting. Application receives error. Indicates severe contention or long-running blockers.",
        "0",
        "> 1 per minute",
        "> 10 per minute",
        "Critical",
        "Perfmon: SQLServer:Locks, Extended Events",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - MEMORY ===
    [
        "Target Server Memory (KB)",
        "Real-time Operational",
        "Amount of memory SQL Server wants to use (configured target)",
        "Shows configured memory target. If significantly different from Total Server Memory, indicates memory pressure or startup state.",
        "Based on max server memory setting and server memory configuration. SQL Server tries to reach this target over time.",
        "= Max Server Memory (steady state)",
        "N/A",
        "N/A",
        "Low",
        "Perfmon: SQLServer:Memory Manager, DMV: sys.dm_os_sys_info",
        "No"
    ],
    [
        "Total Server Memory (KB)",
        "Real-time Operational",
        "Amount of memory SQL Server is currently using",
        "Actual memory committed by SQL Server. If far below Target, indicates recent startup or memory pressure from OS.",
        "Current memory usage. Should equal Target Server Memory in steady state. Gap indicates memory changes or pressure.",
        "≈ Target Server Memory",
        "< 80% of Target (sustained)",
        "< 50% of Target or erratic",
        "High",
        "Perfmon: SQLServer:Memory Manager, DMV: sys.dm_os_sys_info",
        "Yes"
    ],
    [
        "Memory Grants Pending",
        "Real-time Operational",
        "Number of queries waiting for memory grants",
        "Queries queued for memory cannot execute. Causes severe delays and timeouts. Users see frozen applications - critical memory pressure.",
        "Queries needing memory for sorts/hashes but no memory available. Very bad - queries literally cannot run until memory freed.",
        "0",
        "> 0 (any occurrences)",
        "> 5 or sustained",
        "Critical",
        "Perfmon: SQLServer:Memory Manager, DMV: sys.dm_exec_query_memory_grants",
        "Yes"
    ],
    [
        "Memory Grants Outstanding",
        "Real-time Operational",
        "Number of queries that have successfully obtained memory grants",
        "Shows current memory grant usage. Very high values may lead to memory grant waits for new queries.",
        "Queries currently holding memory grants. High values indicate heavy memory-intensive query load (sorts, hashes, etc.).",
        "< 50 (varies by workload)",
        "> 100",
        "> 200 or causing grant waits",
        "Medium",
        "Perfmon: SQLServer:Memory Manager, DMV: sys.dm_exec_query_memory_grants",
        "Yes"
    ],
    [
        "Stolen Server Memory (KB)",
        "Real-time Operational",
        "Memory used for non-buffer cache purposes (query plans, locks, etc.)",
        "High stolen memory reduces buffer cache size, causing more disk I/O and slower queries. Indicates memory allocation issues.",
        "Memory used by SQL Server for non-data purposes: plan cache, lock manager, optimizer, etc. Should be < 30% of total.",
        "< 30% of Total Server Memory",
        "> 40% of Total Server Memory",
        "> 50% or causing buffer cache pressure",
        "High",
        "Perfmon: SQLServer:Memory Manager",
        "Yes"
    ],
    [
        "Free Memory (KB)",
        "Real-time Operational",
        "Amount of memory not currently in use by SQL Server",
        "Free memory sitting idle - wasteful on dedicated SQL Server. Should be minimal as SQL Server should use all available memory.",
        "Memory not committed. On dedicated SQL Server, this should be minimal - SQL Server should use all allocated memory.",
        "< 5% of Total Server Memory",
        "> 20% (memory not being utilized)",
        "> 50% (configuration issue)",
        "Low",
        "Perfmon: SQLServer:Memory Manager, DMV: sys.dm_os_memory_clerks",
        "No"
    ],
    [
        "OS Available Memory (MB)",
        "Real-time Operational",
        "Free physical memory available at OS level",
        "Very low OS memory causes paging/swapping - catastrophic for SQL Server performance. System instability and crashes possible.",
        "Physical RAM available to OS. Should maintain buffer for OS operations. < 100MB critical - indicates memory pressure.",
        "> 1GB available",
        "< 500MB",
        "< 100MB or paging occurring",
        "Critical",
        "Perfmon: Memory\\Available MBytes, OS Monitoring",
        "Yes"
    ],
    [
        "Page Faults/sec",
        "Real-time Operational",
        "Rate of memory page faults (hard faults)",
        "Hard page faults mean memory paged to disk - extremely slow. Causes severe SQL Server performance degradation.",
        "OS paging memory to disk. Should be zero for SQL Server pages (locked memory). > 0 indicates serious memory pressure.",
        "0 (SQL memory should be locked)",
        "> 50 per second",
        "> 200 or SQL memory paging",
        "Critical",
        "Perfmon: Memory\\Page Faults/sec, Process Memory counters",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - TRANSACTION LOG ===
    [
        "Log Flush Wait Time (ms)",
        "Real-time Operational",
        "Time transactions waited for log flushes to complete",
        "Log flush waits delay transaction commits. Users experience slow saves and transaction processing. Critical for high-transaction systems.",
        "Time waiting for log records to be written to disk. Indicates log disk performance. High values = slow log disk.",
        "< 10ms average",
        "> 50ms average",
        "> 100ms or causing commit delays",
        "Critical",
        "DMV: sys.dm_io_virtual_file_stats (log files), Extended Events",
        "Yes"
    ],
    [
        "Log Bytes Flushed/sec",
        "Real-time Operational",
        "Volume of transaction log bytes written per second",
        "Shows write workload intensity. Very high rates can saturate log disk causing transaction delays.",
        "Byte rate of log writes. Used to size log disk I/O capacity. Compare with disk throughput limits.",
        "Baseline log write rate",
        "> 80% of disk throughput",
        "> 95% or disk saturation",
        "High",
        "Perfmon: SQLServer:Databases - Log Bytes Flushed/sec",
        "Yes"
    ],
    [
        "Log Flushes/sec",
        "Real-time Operational",
        "Number of log flush operations per second",
        "Log flush frequency. Very high rates may indicate many small transactions or synchronous commit issues.",
        "Number of times log buffer flushed to disk. Each flush is expensive. High rates suggest many small transactions.",
        "Baseline flush rate",
        "> 150% of baseline",
        "> 200% or causing performance issues",
        "Medium",
        "Perfmon: SQLServer:Databases - Log Flushes/sec",
        "Yes"
    ],
    [
        "Percent Log Used",
        "Real-time Operational",
        "Percentage of transaction log file currently in use",
        "Full transaction log prevents writes - database becomes read-only. Causes complete service outage for write operations.",
        "Space used in log file before auto-growth or full error. > 80% indicates log not being truncated properly.",
        "< 70%",
        "> 80%",
        "> 90% or growth events failing",
        "Critical",
        "Perfmon: SQLServer:Databases, DMV: sys.dm_db_log_space_usage",
        "Yes"
    ],
    [
        "Log Growths",
        "Real-time Operational",
        "Number of transaction log auto-growth events",
        "Log growths pause all transactions - causes noticeable performance hiccup. Indicates undersized log or growth issues.",
        "Count of auto-grow events. Each growth pauses activity. Frequent growths indicate log sized incorrectly.",
        "0 (log pre-sized correctly)",
        "> 1 per day",
        "> 5 per day or growth failures",
        "High",
        "Perfmon: SQLServer:Databases, Extended Events, Error Log",
        "Yes"
    ],
    [
        "Log Shrinks",
        "Real-time Operational",
        "Number of log file shrink operations",
        "Log shrinks are expensive and fragment log. Followed by growths = poor performance cycle. Indicates maintenance issues.",
        "Count of log shrink operations. Shrinking then regrowing is wasteful and causes performance issues.",
        "0 (avoid shrinking logs)",
        "> 0 regularly",
        "Frequent shrink/growth cycle",
        "Medium",
        "Perfmon: SQLServer:Databases, Extended Events",
        "Yes"
    ],
    [
        "Active Transactions",
        "Real-time Operational",
        "Number of currently active transactions",
        "Too many active transactions indicate slow transaction processing or long-running transactions blocking log truncation.",
        "Count of transactions currently open. Very high or steadily increasing indicates problems with transaction management.",
        "Baseline active transaction count",
        "> 150% of baseline",
        "> 200% or log not truncating",
        "High",
        "Perfmon: SQLServer:Databases, DMV: sys.dm_tran_active_transactions",
        "Yes"
    ],
    [
        "Longest Transaction Runtime (seconds)",
        "Real-time Operational",
        "Duration of longest currently running transaction",
        "Long transactions block log truncation causing log growth. Also block schema changes and other operations - major performance impact.",
        "Oldest open transaction. Long-running transactions prevent log reuse and can cause blocking. Check for forgotten BEGIN TRAN.",
        "< 60 seconds",
        "> 300 seconds (5 min)",
        "> 1800 seconds (30 min) or log growth",
        "Critical",
        "DMV: sys.dm_tran_active_transactions, DBCC OPENTRAN",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - TEMPDB ===
    [
        "TempDB Data File Size (MB)",
        "Real-time Operational",
        "Current size of all TempDB data files combined",
        "TempDB growth can cause performance issues and disk space exhaustion. Oversized TempDB indicates problems with queries or spills.",
        "TempDB stores temp tables, table variables, sorts, hashes, etc. Sudden growth indicates large queries or spill activity.",
        "Baseline size (varies by workload)",
        "> 150% of baseline",
        "> 200% or disk space issues",
        "High",
        "DMV: sys.master_files, sys.dm_db_file_space_usage",
        "Yes"
    ],
    [
        "TempDB Version Store Size (MB)",
        "Real-time Operational",
        "Space used by row versioning in TempDB",
        "Large version store indicates long-running transactions preventing version cleanup. Causes TempDB growth and performance issues.",
        "Used for row versioning (snapshot isolation, online index builds, triggers). Growth indicates long transactions.",
        "< 10% of TempDB size",
        "> 25% of TempDB size",
        "> 50% or causing TempDB growth",
        "High",
        "DMV: sys.dm_db_file_space_usage, sys.dm_tran_version_store",
        "Yes"
    ],
    [
        "TempDB Allocation Contention",
        "Real-time Operational",
        "PFS/GAM/SGAM page latch contention in TempDB",
        "TempDB allocation contention causes severe performance degradation for all queries using TempDB. High-concurrency bottleneck.",
        "Multiple sessions fighting to allocate TempDB pages. Monitor PAGELATCH waits on pages 2:1:1, 2:1:3, etc. Configure multiple data files.",
        "< 5% PAGELATCH waits on allocation pages",
        "> 10% PAGELATCH waits",
        "> 20% or constant contention",
        "Critical",
        "DMV: sys.dm_os_waiting_tasks, sys.dm_os_latch_stats",
        "Yes"
    ],
    [
        "TempDB Space Used by Internal Objects (MB)",
        "Real-time Operational",
        "Space consumed by internal objects (sorts, hashes, spills)",
        "High internal object usage indicates queries spilling to disk - very slow. Suggests memory pressure or inefficient queries.",
        "SQL Server creates internal objects for sorts, hashes, spills when memory insufficient. High usage = performance problems.",
        "< 20% of TempDB size",
        "> 40% of TempDB size",
        "> 60% or constant spills",
        "High",
        "DMV: sys.dm_db_task_space_usage, sys.dm_db_session_space_usage",
        "Yes"
    ],
    [
        "TempDB Space Used by User Objects (MB)",
        "Real-time Operational",
        "Space used by user-created temp tables and table variables",
        "Large user object space indicates heavy temp table usage. May need optimization to reduce TempDB dependency.",
        "User-created #temp tables and @table variables. High usage indicates application pattern - may need optimization.",
        "Varies by application",
        "> 50% of TempDB size",
        "> 70% or causing TempDB growth",
        "Medium",
        "DMV: sys.dm_db_task_space_usage, sys.dm_db_session_space_usage",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - PLAN CACHE ===
    [
        "Plan Cache Size (MB)",
        "Real-time Operational",
        "Memory consumed by cached query execution plans",
        "Large plan cache may indicate too many ad-hoc queries or poor parameterization. Steals memory from buffer cache - slows queries.",
        "Cached plans for reuse. Too large indicates plan cache bloat from non-parameterized queries. Monitor for single-use plans.",
        "< 20% of Total Server Memory",
        "> 30% of Total Server Memory",
        "> 40% or causing buffer cache pressure",
        "Medium",
        "DMV: sys.dm_os_memory_clerks (CACHESTORE_SQLCP)",
        "Yes"
    ],
    [
        "Plan Cache Hit Ratio",
        "Real-time Operational",
        "Percentage of queries reusing cached plans vs compiling new plans",
        "Low hit ratio means excessive compilations wasting CPU. Indicates poor parameterization or plan cache pressure.",
        "Plan reuse efficiency. < 90% suggests many queries compiling instead of reusing plans. Causes CPU waste.",
        "> 90%",
        "< 80%",
        "< 70% or high CPU from compilations",
        "High",
        "Perfmon: SQLServer:Plan Cache (calculated from Cache Hit Ratio)",
        "Yes"
    ],
    [
        "Single-Use Plan Count",
        "Real-time Operational",
        "Number of plans used only once (ad-hoc queries)",
        "Many single-use plans bloat plan cache and waste memory. Indicates lack of query parameterization - needs fixing.",
        "Plans used once then never reused. Indicates ad-hoc query problem. Enable 'optimize for ad hoc workloads' or fix parameterization.",
        "< 50% of total cached plans",
        "> 60% of total cached plans",
        "> 75% or plan cache bloat",
        "Medium",
        "DMV: sys.dm_exec_cached_plans",
        "Yes"
    ],
    [
        "Plan Cache Evictions/sec",
        "Real-time Operational",
        "Rate of plan evictions from cache due to pressure",
        "Plan cache pressure causes evictions and recompilations - wastes CPU. Indicates memory issues or plan cache bloat.",
        "Plans removed from cache to make room for new plans. High rate causes excessive recompilation and CPU waste.",
        "< 10 per second",
        "> 50 per second",
        "> 100 per second",
        "High",
        "Perfmon: SQLServer:Plan Cache, Extended Events",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - ALWAYS ON AVAILABILITY GROUPS ===
    [
        "Synchronization State",
        "Real-time Operational",
        "Current synchronization state of AG replicas (SYNCHRONIZED, SYNCHRONIZING, NOT SYNCHRONIZING)",
        "Non-synchronized replicas mean potential data loss if primary fails. Failover unsafe. Business continuity at risk.",
        "Shows if secondary replicas are in sync with primary. SYNCHRONIZED = safe to failover. Other states indicate problems.",
        "SYNCHRONIZED (sync mode)",
        "SYNCHRONIZING > 5 min",
        "NOT SYNCHRONIZING or DISCONNECTED",
        "Critical",
        "DMV: sys.dm_hadr_database_replica_states, SSMS Dashboard",
        "Yes"
    ],
    [
        "Synchronization Health",
        "Real-time Operational",
        "Overall health of AG replica synchronization (HEALTHY, PARTIALLY_HEALTHY, NOT_HEALTHY)",
        "Unhealthy replicas compromise high availability. Failover may fail or cause data loss. Immediate investigation required.",
        "Aggregate health of all databases in AG on replica. NOT_HEALTHY indicates serious issues with replication.",
        "HEALTHY",
        "PARTIALLY_HEALTHY",
        "NOT_HEALTHY",
        "Critical",
        "DMV: sys.dm_hadr_availability_replica_states, SSMS Dashboard",
        "Yes"
    ],
    [
        "Replica Role",
        "Real-time Operational",
        "Current role of replica (PRIMARY, SECONDARY, RESOLVING)",
        "Identifies which replica is primary (accepts writes). RESOLVING state indicates failover in progress or split-brain issues.",
        "Shows if replica is currently primary or secondary. RESOLVING is transitional - extended time indicates problems.",
        "PRIMARY or SECONDARY (stable)",
        "RESOLVING (transitional)",
        "RESOLVING > 5 min or unknown",
        "Critical",
        "DMV: sys.dm_hadr_availability_replica_states",
        "Yes"
    ],
    [
        "Estimated Data Loss Time (seconds)",
        "Real-time Operational",
        "Estimated recovery point (data loss) if primary fails now",
        "Shows potential data loss in failover scenario. High values mean minutes/hours of data could be lost - unacceptable for many businesses.",
        "For async replicas, shows how much data could be lost in failover. Based on log send queue and send rate.",
        "0 (sync mode) or < 60 sec (async)",
        "> 300 seconds (5 min)",
        "> 1800 seconds (30 min)",
        "High",
        "DMV: sys.dm_hadr_database_replica_states",
        "Yes"
    ],
    [
        "Estimated Recovery Time (seconds)",
        "Real-time Operational",
        "Estimated time for secondary to complete recovery if failover happens now",
        "Shows how long failover will take. Long recovery times mean extended downtime during planned or unplanned failover.",
        "Time needed for redo to catch up if failover occurs. Based on redo queue and redo rate. Impacts RTO.",
        "< 60 seconds",
        "> 180 seconds (3 min)",
        "> 600 seconds (10 min)",
        "High",
        "DMV: sys.dm_hadr_database_replica_states",
        "Yes"
    ],
    [
        "Log Send Queue Size (KB)",
        "Real-time Operational",
        "Amount of log waiting to be sent to secondary replicas",
        "Large log send queue indicates network issues or secondary can't keep up. Leads to data loss risk and failover delays.",
        "Log records on primary not yet sent to secondary. Grows due to network issues or heavy write load.",
        "< 10 MB",
        "> 50 MB",
        "> 200 MB or growing",
        "High",
        "DMV: sys.dm_hadr_database_replica_states, Perfmon",
        "Yes"
    ],
    [
        "Log Send Rate (KB/sec)",
        "Real-time Operational",
        "Rate at which log is being sent from primary to secondaries",
        "Shows network throughput to replicas. Compare with log generation rate. Insufficient send rate causes queue buildup.",
        "Log transfer throughput. Should be >= log generation rate. Lower rate causes log send queue growth.",
        ">= Log generation rate",
        "< Log generation rate (sustained)",
        "Much slower than log generation or stalled",
        "High",
        "DMV: sys.dm_hadr_database_replica_states",
        "Yes"
    ],
    [
        "Redo Queue Size (KB)",
        "Real-time Operational",
        "Amount of log received on secondary but not yet applied (redone)",
        "Large redo queue means secondary lagging primary. Increases recovery time and potential data loss in failover.",
        "Log records on secondary waiting to be applied. Large queue = slow redo or heavy write load.",
        "< 10 MB",
        "> 50 MB",
        "> 200 MB or causing sync issues",
        "High",
        "DMV: sys.dm_hadr_database_replica_states, Perfmon",
        "Yes"
    ],
    [
        "Redo Rate (KB/sec)",
        "Real-time Operational",
        "Rate at which log is being applied (redone) on secondary",
        "Shows how fast secondary processes changes. Slow redo causes lag and long recovery times.",
        "Log application rate on secondary. Should keep up with log send rate. Slow redo causes redo queue buildup.",
        "Keeps redo queue small",
        "Redo queue growing",
        "Redo queue growing rapidly or redo stalled",
        "High",
        "DMV: sys.dm_hadr_database_replica_states",
        "Yes"
    ],
    [
        "AG Failover Events",
        "Real-time Operational",
        "Count of automatic and manual failovers",
        "Frequent failovers indicate instability. Each failover causes brief outage. Excessive failovers = poor reliability.",
        "Number of times primary role changed. Track rate - frequent failovers suggest network or health detection issues.",
        "Rare (planned only)",
        "> 1 per day",
        "> 5 per day or frequent unplanned",
        "Critical",
        "Extended Events: alwayson_ddl_executed, SQL Error Log, Windows Event Log",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - PERFORMANCE & RESOURCE ===
    [
        "CPU Utilization (%)",
        "Real-time Operational",
        "Percentage of CPU used by SQL Server process",
        "High CPU causes slow queries and resource competition. All users experience degraded performance. May need more CPU or query optimization.",
        "SQL Server process CPU usage from OS perspective. Sustained > 80% indicates CPU pressure.",
        "< 70% average",
        "> 80% average or sustained peaks",
        "> 90% sustained or 100% peaks",
        "High",
        "Perfmon: Process\\% Processor Time, sys.dm_os_sys_info, Azure Monitor",
        "Yes"
    ],
    [
        "Signal Wait Time %",
        "Real-time Operational",
        "Percentage of wait time that's signal waits (CPU waits)",
        "High signal wait % indicates CPU pressure. Queries waiting for CPU after becoming runnable - direct CPU bottleneck indicator.",
        "Signal waits / total waits. > 25% indicates CPU pressure. Queries ready to run but waiting for CPU availability.",
        "< 15%",
        "> 25%",
        "> 40% or consistent CPU saturation",
        "High",
        "DMV: sys.dm_os_wait_stats (calculated)",
        "Yes"
    ],
    [
        "Disk Avg Read Latency (ms)",
        "Real-time Operational",
        "Average time for disk read operations (data files)",
        "Disk read latency directly impacts query speed. High latency = slow queries = poor user experience. May need faster storage.",
        "Average ms per read I/O. < 10ms good for SSD, < 20ms acceptable for HDD. Higher indicates storage bottleneck.",
        "< 10ms (SSD), < 20ms (HDD)",
        "> 20ms (SSD), > 50ms (HDD)",
        "> 50ms (SSD), > 100ms (HDD)",
        "Critical",
        "DMV: sys.dm_io_virtual_file_stats, Perfmon: LogicalDisk\\Avg Disk sec/Read",
        "Yes"
    ],
    [
        "Disk Avg Write Latency (ms)",
        "Real-time Operational",
        "Average time for disk write operations (data files)",
        "Write latency affects commits and data modifications. High latency slows all write operations and transaction throughput.",
        "Average ms per write I/O. Log disk writes especially critical - should be < 5ms.",
        "< 10ms (SSD), < 20ms (HDD)",
        "> 20ms (SSD), > 50ms (HDD)",
        "> 50ms (SSD), > 100ms (HDD)",
        "Critical",
        "DMV: sys.dm_io_virtual_file_stats, Perfmon: LogicalDisk\\Avg Disk sec/Write",
        "Yes"
    ],
    [
        "Disk Queue Length",
        "Real-time Operational",
        "Number of outstanding I/O requests waiting on disk",
        "Long disk queues indicate I/O bottleneck. Queries waiting for I/O cause slowdowns. May need faster storage or more spindles.",
        "Requests queued for disk. > 2 per disk indicates I/O saturation. Compare with disk capabilities.",
        "< 2 per physical disk",
        "> 5 per physical disk",
        "> 10 or sustained queuing",
        "High",
        "Perfmon: LogicalDisk\\Avg Disk Queue Length, PhysicalDisk counters",
        "Yes"
    ],
    [
        "Errors/sec",
        "Real-time Operational",
        "Number of errors occurring per second",
        "Increasing error rate indicates problems - application errors, permission issues, or database corruption. User impact and reliability concern.",
        "All types of errors. Spike indicates systemic issues. Review error log for details.",
        "< 1 per second (app dependent)",
        "> 5 per second",
        "> 20 or sustained error spike",
        "High",
        "Perfmon: SQLServer:SQL Errors, sys.dm_os_performance_counters",
        "Yes"
    ],
    [
        "SQL Server Process Memory (MB)",
        "Real-time Operational",
        "Total memory used by SQL Server process from OS perspective",
        "Shows actual OS-level memory consumption. Compare with Total Server Memory for discrepancies indicating memory issues.",
        "Working set size of SQL Server process. Should align with Total Server Memory. Large difference indicates problems.",
        "≈ Total Server Memory",
        "> 110% of Total Server Memory",
        "> 125% or causing OS memory pressure",
        "High",
        "Perfmon: Process\\Working Set, Task Manager",
        "Yes"
    ],
    
    # === CAPACITY PLANNING & TREND ANALYSIS ===
    [
        "Database File Growth Rate (MB/day)",
        "Capacity Planning",
        "Rate of database data file size increase",
        "Predicts when storage will be exhausted. Essential for budget planning and preventing storage-related outages.",
        "Monitor database file sizes over time from sys.master_files. Helps forecast future capacity needs.",
        "Predictable and budgeted",
        "Exceeding planned growth rate",
        "Exponential/unexpected growth",
        "High",
        "DMV: sys.master_files (tracked over time), Custom Script, Azure Monitor",
        "Yes"
    ],
    [
        "Transaction Log Growth Rate (MB/day)",
        "Capacity Planning",
        "Rate of transaction log file size increase",
        "Log growth indicates log not truncating properly or heavy write workload. Plan capacity and investigate backup/replication.",
        "Monitor log file sizes over time. Unexpected growth suggests backup or replication issues preventing log truncation.",
        "Stable (log truncates regularly)",
        "Steady growth (log not truncating)",
        "Rapid growth or approaching disk capacity",
        "Critical",
        "DMV: sys.master_files (tracked over time), sys.dm_db_log_space_usage",
        "Yes"
    ],
    [
        "TempDB Growth Trend",
        "Capacity Planning",
        "Long-term trend of TempDB size increases",
        "Growing TempDB usage indicates changing query patterns or increased spill activity. May need more memory or query optimization.",
        "Track TempDB size over weeks/months. Steady growth suggests workload changes or memory pressure issues.",
        "Stable or slight increase",
        "Growing > 20% monthly",
        "Growing > 50% monthly",
        "High",
        "DMV: sys.master_files (tracked over time)",
        "Yes"
    ],
    [
        "Connection Growth Trend",
        "Capacity Planning",
        "Trend of peak concurrent connections over time",
        "Forecasts when connection limits will be reached. Prevents future connection exhaustion during traffic growth.",
        "Track peak User Connections daily/weekly to identify growth patterns. Plan for scaling or connection pooling.",
        "Steady and predictable",
        "Growing > 20% monthly",
        "Growing > 50% monthly",
        "High",
        "Perfmon: User Connections (tracked over time), Azure Monitor",
        "Yes"
    ],
    [
        "Query Volume Trend (Batches/sec)",
        "Capacity Planning",
        "Long-term trend of query throughput",
        "Growing query volume requires capacity planning for CPU, memory, storage I/O. Prevents performance degradation during growth.",
        "Track Batch Requests/sec over weeks/months to identify trends. Helps plan hardware upgrades.",
        "Matches expected traffic growth",
        "Growing faster than capacity",
        "Approaching known capacity limits",
        "High",
        "Perfmon: Batch Requests/sec (tracked over time), Azure Monitor",
        "Yes"
    ],
    [
        "Average Query Duration Trend",
        "Capacity Planning",
        "Long-term trend of query execution time",
        "Gradually increasing query times indicate growing pains - need optimization or scaling before user experience suffers.",
        "Track average execution time from DMVs over time. Steady increase suggests degradation requiring action.",
        "Stable or improving",
        "Increasing > 25% monthly",
        "Increasing > 50% or degrading rapidly",
        "High",
        "DMV: sys.dm_exec_query_stats (tracked over time), Extended Events",
        "Yes"
    ],
    [
        "Memory Usage Trend",
        "Capacity Planning",
        "Trend of SQL Server memory consumption",
        "Growing memory needs may require more RAM. Helps plan upgrades before hitting memory limits and pressure.",
        "Track Total Server Memory over time. Growth indicates workload increase or changing patterns.",
        "Stable within capacity",
        "Approaching max server memory",
        "> 95% of max or causing pressure",
        "High",
        "Perfmon: Total Server Memory (KB) tracked over time",
        "Yes"
    ],
    [
        "CPU Usage Trend",
        "Capacity Planning",
        "Long-term trend of CPU utilization",
        "Growing CPU usage forecasts need for more cores or optimization. High CPU causes query queueing and slow response.",
        "Track CPU % over time from OS metrics. Helps plan hardware scaling.",
        "< 70% average utilization",
        "> 80% average or peaks at 100%",
        "Sustained > 90% or constant saturation",
        "High",
        "Perfmon: CPU counters tracked over time, Azure Monitor",
        "Yes"
    ],
    [
        "I/O Throughput Trend (MB/sec)",
        "Capacity Planning",
        "Trend of disk I/O volume over time",
        "Growing I/O requirements may necessitate faster storage or additional IOPS capacity. Plan before hitting I/O limits.",
        "Track total I/O throughput (reads + writes) over time. Helps plan storage upgrades.",
        "Within storage capacity",
        "Approaching I/O limits (IOPS or throughput)",
        "> 80% of storage capacity",
        "High",
        "Perfmon: Disk counters tracked over time, DMV: sys.dm_io_virtual_file_stats",
        "Yes"
    ],
    [
        "Index Fragmentation Trend",
        "Capacity Planning",
        "Average fragmentation level of key indexes over time",
        "Increasing fragmentation degrades query performance. Indicates need for maintenance schedule adjustments.",
        "Track avg_fragmentation_in_percent from sys.dm_db_index_physical_stats over time.",
        "< 30% fragmentation",
        "> 50% fragmentation",
        "> 70% or severe performance impact",
        "Medium",
        "DMV: sys.dm_db_index_physical_stats (tracked over time)",
        "Yes"
    ],
    [
        "Table Size Growth (Top 10 tables)",
        "Capacity Planning",
        "Growth rate of largest tables",
        "Identifies tables growing fastest. Helps plan archiving, partitioning, or scaling strategies.",
        "Track table row counts and sizes from sys.dm_db_partition_stats over time. Focus on top consumers.",
        "Expected growth pattern",
        "> 50% month-over-month growth",
        "> 100% month-over-month or runaway",
        "Medium",
        "DMV: sys.dm_db_partition_stats (tracked over time)",
        "Yes"
    ],
    [
        "Backup Duration Trend",
        "Capacity Planning",
        "How long backups take over time",
        "Longer backups may impact backup windows and RTO. May need backup strategy changes or compression.",
        "Monitor backup job duration from msdb.dbo.backupset. Growing duration impacts maintenance and recovery.",
        "Within acceptable window",
        "Approaching backup window limit",
        "Exceeding backup window",
        "Medium",
        "System Table: msdb.dbo.backupset, SQL Agent Job History",
        "Yes"
    ],
    [
        "Backup Size Trend",
        "Capacity Planning",
        "Rate of backup size increase",
        "Affects backup storage costs and restore times. Plan backup infrastructure capacity.",
        "Track backup_size from msdb.dbo.backupset over time. Impacts backup storage and RTO.",
        "Matches database growth",
        "Growing faster than expected",
        "Backup storage approaching limits",
        "Medium",
        "System Table: msdb.dbo.backupset",
        "Yes"
    ],
    [
        "Statistics Update Frequency",
        "Capacity Planning",
        "How often statistics are being updated (auto or manual)",
        "Stale statistics cause poor query plans. Monitor update frequency to ensure optimizer has current data.",
        "Track stats_date from sys.stats. Stale stats (> 7 days for volatile tables) cause performance issues.",
        "Updated regularly (< 7 days)",
        "Some stats > 14 days old",
        "Many stats > 30 days or query degradation",
        "Medium",
        "DMV: sys.stats, Custom Query",
        "Yes"
    ],
    [
        "Wait Statistics Trend",
        "Capacity Planning",
        "Changes in dominant wait types over time",
        "Shifting wait patterns indicate changing bottlenecks. Helps focus optimization and capacity planning efforts.",
        "Track top wait types from sys.dm_os_wait_stats over time. Identify trending bottlenecks.",
        "Stable wait patterns",
        "Significant wait type changes",
        "New critical wait types emerging",
        "Medium",
        "DMV: sys.dm_os_wait_stats (tracked over time)",
        "Yes"
    ],
    
    # === SECURITY & COMPLIANCE ===
    [
        "Failed Login Attempts by IP",
        "Security & Compliance",
        "Failed authentication attempts grouped by source IP address",
        "Identifies source of attacks. Helps detect distributed attacks or compromised internal systems. Enables IP blocking.",
        "Parse error log or Extended Events for login failures by IP. Geo-location analysis can identify attack origins.",
        "< 5 per IP per day",
        "> 20 per IP per day",
        "> 100 or coordinated from multiple IPs",
        "Critical",
        "Extended Events: login_failed, SQL Audit, Error Log Parser, Azure Monitor",
        "Yes"
    ],
    [
        "Permission/Role Changes",
        "Security & Compliance",
        "GRANT, REVOKE, ALTER ROLE, or permission changes",
        "Unauthorized permission changes = potential security breach. Compliance requires tracking all access control modifications.",
        "Monitor via SQL Audit or Extended Events (audit_event_group: DATABASE_PERMISSION_CHANGE_GROUP). Track all permission DDL.",
        "Only authorized changes",
        "Unexpected permission changes",
        "Unauthorized admin privilege grants",
        "Critical",
        "SQL Audit, Extended Events: audit_database_permission_change_event, DDL Triggers",
        "Yes"
    ],
    [
        "Login/User Account Changes",
        "Security & Compliance",
        "CREATE LOGIN, DROP LOGIN, ALTER LOGIN, CREATE USER statements",
        "Account changes must be tracked for compliance and security. Unauthorized accounts = breach risk.",
        "Track via SQL Audit, Extended Events, or DDL triggers. All account management should be logged and reviewed.",
        "Only authorized changes",
        "Unexpected account changes",
        "Unauthorized account creation",
        "Critical",
        "SQL Audit, Extended Events: audit_login_change_event, DDL Triggers",
        "Yes"
    ],
    [
        "Sensitive Data Access Patterns",
        "Security & Compliance",
        "Queries accessing tables with sensitive data (PII, PCI, PHI)",
        "Unusual access to sensitive data may indicate data exfiltration or insider threat. Requires monitoring for compliance.",
        "Monitor queries against sensitive tables via Extended Events or SQL Audit. Detect anomalous access patterns.",
        "Normal pattern baseline",
        "Moderate deviation from baseline",
        "Significant anomaly or bulk access",
        "Critical",
        "SQL Audit, Extended Events: audit_database_object_access_event, Custom Monitoring",
        "Yes"
    ],
    [
        "DDL Statement Execution",
        "Security & Compliance",
        "CREATE, ALTER, DROP statements on schema objects",
        "Schema changes must be tracked for compliance and change management. Unauthorized DDL = potential sabotage or error.",
        "Monitor via SQL Audit, Extended Events (audit_event_group: DATABASE_OBJECT_CHANGE_GROUP), or DDL triggers.",
        "Only during maintenance windows",
        "Unexpected DDL in production hours",
        "Unauthorized schema changes",
        "Critical",
        "SQL Audit, Extended Events, DDL Triggers",
        "Yes"
    ],
    [
        "SQL Injection Pattern Detection",
        "Security & Compliance",
        "Queries containing potential SQL injection signatures",
        "SQL injection = major vulnerability. Detection helps identify attack attempts or vulnerable code paths.",
        "Pattern match queries for injection signatures (UNION SELECT, comment injection, etc.). Use Extended Events or custom monitoring.",
        "0 injection patterns",
        "Potential injection attempts detected",
        "Confirmed injection attempts",
        "Critical",
        "Extended Events: sql_batch_completed with pattern matching, SQL Audit, Custom Analysis",
        "Yes"
    ],
    [
        "Transparent Data Encryption (TDE) Status",
        "Security & Compliance",
        "Whether databases are encrypted at rest with TDE",
        "TDE required for compliance with regulations requiring data-at-rest encryption (PCI DSS, HIPAA, etc.). Unencrypted = violation.",
        "Check is_encrypted from sys.databases. Sensitive databases must have TDE enabled for compliance.",
        "Enabled for all sensitive DBs",
        "Some sensitive DBs unencrypted",
        "Compliance violation or no encryption",
        "Critical",
        "DMV: sys.databases, sys.dm_database_encryption_keys",
        "Yes"
    ],
    [
        "Always Encrypted Column Usage",
        "Security & Compliance",
        "Number of columns using Always Encrypted",
        "Always Encrypted protects sensitive data even from DBAs. Tracking usage ensures compliance with data protection policies.",
        "Query sys.columns for encryption_type. Always Encrypted provides column-level encryption with client-side keys.",
        "Per security policy",
        "N/A",
        "Sensitive data not encrypted per policy",
        "High",
        "DMV: sys.columns (encryption_type), sys.column_encryption_keys",
        "Yes"
    ],
    [
        "Connection Encryption Ratio",
        "Security & Compliance",
        "Percentage of connections using SSL/TLS encryption",
        "Unencrypted connections expose data in transit. Compliance often requires encryption (PCI DSS, HIPAA, GDPR).",
        "Check encrypt_option from sys.dm_exec_connections. All production connections should use TLS.",
        "100% encrypted",
        "< 100% (some unencrypted)",
        "< 80% or sensitive data unencrypted",
        "High",
        "DMV: sys.dm_exec_connections, Extended Events",
        "Yes"
    ],
    [
        "Audit Log Size and Retention",
        "Security & Compliance",
        "Audit log file sizes and retention compliance",
        "Audit logs required for compliance. Must ensure adequate storage and retention. Missing logs = compliance failure.",
        "Monitor audit file sizes and age. Must meet retention requirements (often 1-7 years depending on regulation).",
        "Within retention policy",
        "Approaching storage limits",
        "Logs not being retained properly",
        "High",
        "DMV: sys.dm_server_audit_status, File System Monitoring",
        "Yes"
    ],
    [
        "Privileged Account Usage",
        "Security & Compliance",
        "Activity from sysadmin and highly privileged accounts",
        "Privileged account abuse is high-risk. All admin activity should be logged and reviewed for unauthorized actions.",
        "Track connections and queries from sysadmin accounts via Extended Events or SQL Audit. Detect anomalous admin activity.",
        "Expected admin activity only",
        "Unexpected admin account usage",
        "Admin activity from unusual sources",
        "Critical",
        "SQL Audit, Extended Events: audit_admin_operations, DMV: sys.dm_exec_sessions",
        "Yes"
    ],
    [
        "Weak Authentication Accounts",
        "Security & Compliance",
        "SQL Authentication accounts vs Windows Authentication",
        "SQL Authentication is weaker than Windows Auth. Best practice: use Windows Auth. Track SQL auth usage for security.",
        "Query sys.server_principals for SQL auth accounts. Windows Auth preferred for better security and central management.",
        "Windows Auth preferred",
        "Mix of SQL and Windows Auth",
        "Many SQL Auth accounts or weak passwords",
        "Medium",
        "DMV: sys.server_principals, sys.sql_logins",
        "Yes"
    ],
    [
        "Password Policy Compliance",
        "Security & Compliance",
        "SQL logins adhering to password policy and expiration",
        "Password policies enforce security standards. Non-compliant accounts = security risk and potential audit finding.",
        "Check is_policy_checked and is_expiration_checked from sys.sql_logins. Ensure policy enforcement.",
        "All accounts policy compliant",
        "Some accounts non-compliant",
        "Many accounts bypass policy",
        "High",
        "DMV: sys.sql_logins",
        "Yes"
    ],
    [
        "Backup Encryption Status",
        "Security & Compliance",
        "Whether backups are encrypted",
        "Unencrypted backups = data exposure risk. Compliance often requires backup encryption for sensitive data.",
        "Check encryption_algorithm from msdb.dbo.backupset. Backups should be encrypted for security and compliance.",
        "All backups encrypted",
        "Some backups unencrypted",
        "Sensitive data backups unencrypted",
        "Critical",
        "System Table: msdb.dbo.backupset",
        "Yes"
    ],
    [
        "Certificate and Key Expiration",
        "Security & Compliance",
        "Days until certificates and encryption keys expire",
        "Expired certificates cause TDE and other encryption features to fail. Service outages and security issues.",
        "Monitor expiry_date from sys.certificates and sys.symmetric_keys. Set alerts well before expiration (30-90 days).",
        "> 90 days until expiration",
        "< 90 days until expiration",
        "< 30 days or expired",
        "Critical",
        "DMV: sys.certificates, sys.symmetric_keys, sys.asymmetric_keys",
        "Yes"
    ],
    [
        "Guest User Access",
        "Security & Compliance",
        "Databases where guest user has permissions",
        "Guest user access is security risk - allows access without explicit login. Should be disabled except in msdb/tempdb.",
        "Check guest user permissions via sys.database_permissions. Guest should be disabled in user databases.",
        "Disabled except msdb/tempdb",
        "Enabled in some user databases",
        "Enabled with permissions in production",
        "High",
        "DMV: sys.database_permissions, sys.database_principals",
        "Yes"
    ],
    [
        "Cross-Database Ownership Chaining",
        "Security & Compliance",
        "Databases with cross-DB ownership chaining enabled",
        "Cross-DB ownership chaining can bypass security checks. Potential security hole if not carefully managed.",
        "Check is_db_chaining_on from sys.databases. Should be OFF unless specifically required and understood.",
        "OFF (default)",
        "ON without justification",
        "ON in production without controls",
        "Medium",
        "DMV: sys.databases",
        "Yes"
    ],
    [
        "Trustworthy Database Property",
        "Security & Compliance",
        "Databases with TRUSTWORTHY property enabled",
        "TRUSTWORTHY = security risk allowing privilege escalation. Should be OFF except for specific scenarios (SSRS, SSISDB).",
        "Check is_trustworthy_on from sys.databases. OFF preferred - ON allows code to impersonate high privileges.",
        "OFF (default)",
        "ON without justification",
        "ON in production databases",
        "High",
        "DMV: sys.databases",
        "Yes"
    ],
    [
        "C2 Audit Mode Status",
        "Security & Compliance",
        "Whether C2 audit mode is enabled (DOD compliance)",
        "C2 audit mode tracks all security events for DOD compliance. Required for certain government and defense contracts.",
        "Check configuration value for 'c2 audit mode'. Required for C2 level security certification.",
        "Per compliance requirements",
        "N/A",
        "Non-compliant with C2 requirements",
        "Medium",
        "System View: sys.configurations",
        "No"
    ],
    [
        "SQL Audit Status",
        "Security & Compliance",
        "Whether SQL Server Audit is configured and running",
        "SQL Audit essential for compliance tracking and security monitoring. Audit failure = blind spot in security.",
        "Check is_state_enabled from sys.server_audits and sys.database_audits. Ensure audits are running.",
        "Enabled and running",
        "Configured but not running",
        "Not configured or failed",
        "Critical",
        "DMV: sys.server_audits, sys.database_audits, sys.dm_server_audit_status",
        "Yes"
    ],
    [
        "Extended Events Session Status",
        "Security & Compliance",
        "Critical Extended Events sessions for security monitoring",
        "Extended Events capture security-relevant events. Session failures mean missing audit data.",
        "Verify critical XE sessions running via sys.dm_xe_sessions. Sessions for login tracking, DDL, etc. must be active.",
        "All critical sessions running",
        "Some sessions not running",
        "Security monitoring sessions down",
        "High",
        "DMV: sys.dm_xe_sessions, sys.server_event_sessions",
        "Yes"
    ],
    [
        "Data Classification Status",
        "Security & Compliance",
        "Percentage of columns with data classification labels",
        "Data classification (sensitivity labels) required for GDPR and other privacy regulations. Helps identify and protect sensitive data.",
        "Check sys.sensitivity_classifications. All sensitive columns should be labeled for compliance and data discovery.",
        "All sensitive data classified",
        "< 80% classified",
        "< 50% or no classification",
        "High",
        "DMV: sys.sensitivity_classifications (SQL 2019+), Azure SQL Database",
        "Yes"
    ],
    [
        "Dynamic Data Masking Usage",
        "Security & Compliance",
        "Number of columns using dynamic data masking",
        "DDM masks sensitive data for non-privileged users. Compliance tool for protecting PII while allowing access.",
        "Check is_masked from sys.masked_columns. DDM provides view-time masking for sensitive columns.",
        "Per security policy",
        "Sensitive columns unmasked",
        "PII exposed without masking",
        "Medium",
        "DMV: sys.masked_columns",
        "Yes"
    ],
    [
        "Row-Level Security Policy Count",
        "Security & Compliance",
        "Number of RLS policies enforcing data access controls",
        "RLS enforces row-level access control. Multi-tenant or compliance scenarios require RLS for data isolation.",
        "Count from sys.security_policies. RLS ensures users only see authorized rows - critical for multi-tenancy.",
        "Per application design",
        "N/A",
        "Required RLS policies missing",
        "High",
        "DMV: sys.security_policies, sys.security_predicates",
        "Yes"
    ]
]

# Write data rows
for row_num, row_data in enumerate(metrics_data, 2):
    for col_num, value in enumerate(row_data, 1):
        cell = ws.cell(row=row_num, column=col_num)
        cell.value = value
        cell.alignment = Alignment(vertical="top", wrap_text=True)
        cell.border = Border(
            left=Side(style='thin', color='CCCCCC'),
            right=Side(style='thin', color='CCCCCC'),
            top=Side(style='thin', color='CCCCCC'),
            bottom=Side(style='thin', color='CCCCCC')
        )
        
        # Category coloring (same as MySQL)
        if col_num == 2:  # Category column
            if value == "Real-time Operational":
                cell.fill = PatternFill(start_color="E7F4FF", end_color="E7F4FF", fill_type="solid")
            elif value == "Capacity Planning":
                cell.fill = PatternFill(start_color="FFF4E7", end_color="FFF4E7", fill_type="solid")
            elif value == "Security & Compliance":
                cell.fill = PatternFill(start_color="FFE7E7", end_color="FFE7E7", fill_type="solid")
        
        # Severity Level coloring (same as MySQL)
        if col_num == 9:  # Severity Level column
            if value == "Critical":
                cell.fill = PatternFill(start_color="FF6B6B", end_color="FF6B6B", fill_type="solid")
                cell.font = Font(bold=True, color="FFFFFF")
            elif value == "High":
                cell.fill = PatternFill(start_color="FFB366", end_color="FFB366", fill_type="solid")
                cell.font = Font(bold=True, color="FFFFFF")
            elif value == "Medium":
                cell.fill = PatternFill(start_color="FFE066", end_color="FFE066", fill_type="solid")
                cell.font = Font(bold=True)
            elif value == "Low":
                cell.fill = PatternFill(start_color="B3E6B3", end_color="B3E6B3", fill_type="solid")
        
        # Alert recommendation coloring (same as MySQL)
        if col_num == 11:  # Recommended Alert column
            if value == "Yes":
                cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
                cell.font = Font(bold=True)
            elif value == "No":
                cell.fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")

# Freeze header row
ws.freeze_panes = "A2"

# Auto-filter
ws.auto_filter.ref = f"A1:K{len(metrics_data) + 1}"

# Save workbook
wb.save("/home/ubuntu/SQLServer_Database_Monitoring_Metrics.xlsx")
print("Excel file created successfully!")
print(f"Total metrics documented: {len(metrics_data)}")
print(f"- Real-time Operational: {sum(1 for m in metrics_data if m[1] == 'Real-time Operational')}")
print(f"- Capacity Planning: {sum(1 for m in metrics_data if m[1] == 'Capacity Planning')}")
print(f"- Security & Compliance: {sum(1 for m in metrics_data if m[1] == 'Security & Compliance')}")
