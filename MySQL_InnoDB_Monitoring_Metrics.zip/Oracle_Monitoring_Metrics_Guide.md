# Oracle Database Monitoring Metrics - Comprehensive Documentation

## 📊 Overview

This comprehensive Excel spreadsheet documents **105 critical monitoring metrics** for Oracle Database systems. The metrics are organized into three main categories to support different operational needs:

- **Real-time Operational Metrics**: 66 metrics for day-to-day monitoring and alerting
- **Capacity Planning & Trend Analysis**: 15 metrics for long-term planning and growth forecasting
- **Security & Compliance**: 24 metrics for security monitoring and regulatory compliance

## 🎯 Purpose

This document is designed for presentation to **non-technical managers and management teams**, with a focus on:
- **Business Impact**: Clear explanations of how each metric affects revenue, user experience, and downtime costs
- **Simple Language**: Technical concepts explained in business-friendly terms
- **Visual Indicators**: Color-coded severity levels for quick assessment
- **Actionable Thresholds**: Clear warning and critical thresholds for each metric

## 📁 File Information

**File Name**: `Oracle_Database_Monitoring_Metrics.xlsx`  
**Location**: `/home/ubuntu/Oracle_Database_Monitoring_Metrics.xlsx`

## 📋 Column Descriptions

| Column | Description |
|--------|-------------|
| **Metric Name** | Technical name used in monitoring tools (OEM, Grafana, Prometheus) |
| **Category** | Real-time Operational / Capacity Planning / Security & Compliance |
| **Description** | Simple explanation of what this metric measures |
| **Business Impact** | Why this matters - downtime costs, user experience, revenue impact |
| **Technical Explanation** | Simplified technical details for IT teams |
| **Normal/Healthy Range** | What values are considered good |
| **Warning Threshold** | When to pay attention |
| **Critical Threshold** | When immediate action is needed |
| **Severity Level** | Critical/High/Medium/Low (color-coded) |
| **Monitoring Tool/Exporter** | Which tool captures this metric |
| **Recommended Alert** | Yes/No - should this trigger alerts? |

## 🎨 Visual Formatting

### Category Colors
- **Light Blue** (Real-time Operational): Day-to-day monitoring metrics
- **Light Orange** (Capacity Planning): Long-term planning and trend analysis
- **Light Red** (Security & Compliance): Security and audit metrics

### Severity Level Colors
- **🔴 Red (Critical)**: Immediate business impact - service outages, data loss, security breaches
- **🟠 Orange (High)**: Significant impact - performance degradation, user experience issues
- **🟡 Yellow (Medium)**: Moderate impact - potential future issues, investigation needed
- **🟢 Green (Low)**: Minor impact - informational, trending analysis

### Alert Recommendation
- **Green "Yes"**: Should trigger automated alerts
- **Gray "No"**: Monitoring only, no immediate alerts needed

## 📊 Metric Categories Breakdown

### 1. Real-time Operational Metrics (66 metrics)

#### **Session Metrics** (7 metrics)
- Active Sessions, Total Sessions, Blocked Sessions
- Long Running Sessions, Inactive Sessions Holding Locks
- Critical for connection management and preventing session exhaustion

#### **SQL Performance** (12 metrics)
- Executions Per Second, Parse Counts (Hard/Total), SQL Response Time
- Physical/Logical Reads, Sorts (Disk/Memory), Full Table Scans
- Redo Size, Transactions Per Second
- Directly impacts user experience and application responsiveness

#### **Wait Events** (12 metrics)
- DB Time Per Second, Average Active Sessions (AAS)
- db file sequential read, db file scattered read
- log file sync, log file parallel write
- Transaction lock contention, Library cache lock/pin
- Latch contention (cache buffers chains, shared pool)
- CPU Wait Time, Total Wait Time
- THE most important Oracle performance indicators

#### **Memory (SGA/PGA)** (11 metrics)
- SGA Size, Buffer Cache Hit Ratio, Buffer Cache Size
- Shared Pool Size, Library Cache Hit Ratio
- Dictionary Cache Hit Ratio
- PGA Aggregate Target, PGA Usage, PGA Cache Hit Ratio
- Shared Pool Free Memory, Result Cache Usage
- Key performance indicators for database speed

#### **Tablespace & Storage** (7 metrics)
- Tablespace Usage % (Data, TEMP, UNDO, SYSAUX)
- Datafile I/O Wait Time
- ASM Diskgroup Free Space, ASM Disk Failures
- CRITICAL - full tablespaces cause immediate outages

#### **Redo & Archive Logs** (7 metrics)
- Redo Log Switches Per Hour
- Archive Log Generation Rate
- Archive Log Gap, Standby Apply Lag, Transport Lag (Data Guard)
- Redo Log Space Requests, Checkpoint Not Complete Count
- Essential for Data Guard and disaster recovery

#### **Backup & Recovery** (6 metrics)
- Last Successful Backup Age, Backup Success Rate
- Backup Performance, RMAN Error Count
- Flashback Database Status, Fast Recovery Area Usage
- Critical for business continuity and recovery objectives

#### **RAC-Specific** (4 metrics)
- Global Cache Block Transfer Time
- Global Cache Block Loss Ratio
- RAC Instance Membership
- GES/GCS Deadlock Rate
- Essential for RAC cluster health and performance

### 2. Capacity Planning & Trend Analysis (15 metrics)

**Storage Planning**
- Database Size Growth Rate, Tablespace Growth Trends
- Archive Log Accumulation Rate
- Prevents storage-related outages and supports budget planning

**Resource Trending**
- Session Count Trend, SQL Execution Volume Trend
- Average SQL Response Time Trend
- CPU Utilization Trend, Memory Usage Growth Trend
- I/O Throughput Trend (IOPS & MB/s)
- Forecasts when scaling or optimization is needed

**Backup & Recovery Trending**
- Backup Duration Trend, Backup Storage Growth
- Impacts disaster recovery capabilities

**Database Growth Patterns**
- Undo Retention Requirement Trend
- Temp Tablespace Usage Trend
- Number of Objects Growth
- AWR Retention and Growth
- Helps plan for data lifecycle management

### 3. Security & Compliance (24 metrics)

**Authentication & Access Control**
- Failed Login Attempts, Failed Login from Unusual Locations
- Privileged User Activity, Direct SYS Logins
- GRANT/REVOKE Operations, User Account Changes
- Schema Object DDL Operations
- Detects security threats and policy violations

**Account Security**
- Profile Violation Attempts
- Accounts with Default Passwords
- Accounts with Non-Expiring Passwords
- Unused/Dormant User Accounts
- Prevents weak authentication vulnerabilities

**Data Protection**
- Database Vault Status
- Transparent Data Encryption (TDE) Status
- Network Encryption Usage
- Data Masking Policy Coverage
- Required for regulatory compliance (PCI DSS, HIPAA, GDPR)

**Audit & Compliance**
- Audit Trail Size and Growth
- Unified Audit Status
- Fine-Grained Audit Policy Coverage
- Compliance Report Generation Status
- Supports audit readiness and regulatory requirements

**Threat Detection**
- SQL Injection Pattern Detection
- Sensitive Data Access Anomalies
- Supports forensics and incident response

**Configuration Security**
- Database Patch Level Compliance
- PUBLIC Privilege Audit
- External Authentication Failures
- Ensures security hardening and compliance

## 🛠️ Monitoring Tools Reference

The metrics can be captured using various tools:

### Oracle-Specific Tools:
- **Oracle Enterprise Manager (OEM)**: Comprehensive Oracle monitoring solution
- **Automatic Workload Repository (AWR)**: Built-in performance repository
- **Active Session History (ASH)**: Real-time session activity tracking
- **ADDM (Automatic Database Diagnostic Monitor)**: Performance analysis

### Open Source/Third-Party:
- **Grafana with Oracle Exporter**: Visualization with prometheus exporters
- **Prometheus oracledb_exporter**: Metrics collection for Prometheus
- **Custom SQL Scripts**: V$ and DBA_ view queries
- **RMAN**: Recovery Manager for backup metrics
- **Data Guard Broker**: For standby database metrics
- **Grid Infrastructure**: For RAC and ASM metrics

### Audit & Security:
- **Unified Audit Trail**: Modern audit framework (12c+)
- **Database Vault**: Separation of duties and realm protection
- **DBMS_REDACT**: Data masking for sensitive columns
- **Alert Log Monitoring**: System-level events and errors

## 🚨 Critical Metrics Requiring Immediate Alerts

The spreadsheet identifies **87 metrics** that should trigger automated alerts (marked "Yes" in Recommended Alert column). Priority examples include:

### Immediate Outage Risk:
1. **Total Sessions** - Hitting SESSIONS limit, users cannot connect
2. **Blocked Sessions** - Users waiting, transactions stalled
3. **Tablespace Usage %** - Full tablespace = ORA-01653, immediate outage
4. **TEMP Tablespace Usage** - Full temp = query failures
5. **UNDO Tablespace Usage** - Transaction failures and snapshot too old
6. **Fast Recovery Area Usage** - FRA full = database hang

### Performance Degradation:
7. **DB Time Per Second / AAS** - System overloaded
8. **log file sync Wait Time** - Commit performance issues
9. **Buffer Cache Hit Ratio** - Excessive physical I/O
10. **PGA Aggregate Memory Usage** - Memory pressure, disk sorts

### Data Guard & High Availability:
11. **Standby Apply Lag** - DR capability degraded
12. **Archive Log Gap** - Standby synchronization issues
13. **RAC Instance Membership** - Reduced cluster capacity

### Backup & Recovery:
14. **Last Successful Backup Age** - Recovery risk
15. **Backup Success Rate** - RPO/RTO at risk

### Security & Compliance:
16. **Failed Login Attempts** - Potential brute force attack
17. **Privileged User Activity** - Unauthorized admin operations
18. **TDE Status** - Data-at-rest encryption missing
19. **Audit Trail Issues** - Compliance violation risk

## 📈 How to Use This Document

### For Management & Executives
1. Review **Business Impact** column to understand why metrics matter
2. Focus on **Critical** severity metrics first (red-highlighted)
3. Use **Category** filter to view specific areas of concern
4. Check metrics marked "Yes" for recommended alerts as priority monitoring
5. Understand cost implications of downtime and performance issues

### For Database Administrators
1. Use **Metric Name** to configure monitoring tools
2. Reference **Normal/Healthy Range** for baseline configuration
3. Set up alerts based on **Warning** and **Critical** thresholds
4. Review **Technical Explanation** for troubleshooting guidance
5. Query V$ and DBA_ views to collect metrics
6. Use AWR/ASH reports for historical analysis

### For DevOps & SRE Teams
1. Use **Monitoring Tool/Exporter** column to implement collection
2. Prioritize metrics with **Recommended Alert = Yes**
3. Build dashboards organized by **Category**
4. Track **Capacity Planning** metrics for proactive scaling
5. Integrate with Grafana, Prometheus, or custom monitoring stacks
6. Set up alert routing and escalation policies

### For Security Teams
1. Focus on **Security & Compliance** category (24 metrics)
2. Implement Unified Auditing for comprehensive tracking
3. Monitor privileged user activities and failed logins
4. Ensure encryption compliance (TDE, SQL*Net encryption)
5. Track audit trail health and retention
6. Detect anomalous access patterns

## 🎓 Best Practices

### Implementation Strategy:
1. **Phase 1 - Critical Metrics**: Implement high-severity alerts first (outage prevention)
2. **Phase 2 - Performance**: Add wait events and performance metrics
3. **Phase 3 - Capacity Planning**: Set up trending and growth monitoring
4. **Phase 4 - Security**: Implement comprehensive security monitoring
5. **Phase 5 - Optimization**: Fine-tune thresholds based on baselines

### Operational Excellence:
1. **Establish Baselines**: Monitor normal ranges for your specific workload before setting alerts
2. **Avoid Alert Fatigue**: Set appropriate thresholds to prevent false positives
3. **Review Regularly**: Update thresholds quarterly as application grows
4. **Correlate Metrics**: Use OEM or Grafana to view multiple related metrics together
5. **Document Incidents**: Track which metrics predicted or detected incidents
6. **Capacity Planning**: Review growth trends monthly to prevent emergencies
7. **Security Audits**: Quarterly review of security metrics and compliance status

### Oracle-Specific Recommendations:
- Use **AWR** reports (generated hourly) for historical performance analysis
- Leverage **ADDM** for automatic performance recommendations
- Use **ASH** (Active Session History) for real-time troubleshooting
- Enable **Unified Auditing** (12c+) for better audit performance
- Implement **Database Vault** for sensitive data protection
- Configure **Data Guard** for high availability and disaster recovery
- Monitor **RAC** interconnect carefully if using Real Application Clusters
- Size **SGA** and **PGA** appropriately (typically 60-70% and 20-30% of RAM respectively)
- Keep **patches** current (within 1-2 quarters of latest RU/PSU)

## 🔗 Oracle-Specific Data Sources

### Dynamic Performance Views (V$ Views):
- **V$SESSION**: Session information and wait events
- **V$SYSSTAT**: System statistics
- **V$SYSMETRIC**: Real-time metric values
- **V$SQL**: SQL statement statistics
- **V$SYSTEM_EVENT**: Wait event summary
- **V$FILESTAT**: Datafile I/O statistics
- **V$SGASTAT**: SGA component sizes
- **V$PGASTAT**: PGA memory statistics
- **V$ASM_DISKGROUP**: ASM storage information
- **V$ARCHIVED_LOG**: Archive log history
- **V$DATAGUARD_STATS**: Data Guard metrics
- **V$RMAN_BACKUP_JOB_DETAILS**: Backup information

### Data Dictionary Views (DBA_ Views):
- **DBA_DATA_FILES**: Tablespace file information
- **DBA_FREE_SPACE**: Tablespace free space
- **DBA_TEMP_FILES**: Temporary tablespace files
- **DBA_USERS**: User account information
- **DBA_AUDIT_TRAIL**: Traditional audit records
- **UNIFIED_AUDIT_TRAIL**: Unified audit records (12c+)
- **DBA_TAB_PRIVS**: Table privileges
- **DBA_SYS_PRIVS**: System privileges
- **DBA_ENCRYPTED_COLUMNS**: TDE encryption status

### Automatic Workload Repository:
- **DBA_HIST_SYSSTAT**: Historical system statistics
- **DBA_HIST_SYSTEM_EVENT**: Historical wait events
- **DBA_HIST_SQLSTAT**: Historical SQL statistics
- **DBA_HIST_ACTIVE_SESS_HISTORY**: ASH data

## 📞 Support & Maintenance

### Regular Activities:
- **Daily**: Review critical alerts, check tablespace/FRA space, verify backup success
- **Weekly**: Review top wait events, analyze slow SQL, check security audit trail
- **Monthly**: Capacity planning review, AWR report analysis, patch compliance check
- **Quarterly**: Threshold tuning, security audit, disaster recovery test

### Escalation Paths:
- **Critical Severity**: Immediate page to on-call DBA, engage incident management
- **High Severity**: Alert within 15 minutes, investigate within 1 hour
- **Medium Severity**: Email alert, investigate within 4 hours
- **Low Severity**: Dashboard monitoring, weekly review

### Documentation Requirements:
- Maintain runbooks for each critical alert type
- Document baseline values and expected patterns
- Track threshold adjustments and rationale
- Keep disaster recovery procedures current

## 📚 Related Oracle Documentation

- Oracle Database Performance Tuning Guide
- Oracle Database Administrator's Guide
- Oracle Enterprise Manager Cloud Control Documentation
- Oracle Data Guard Concepts and Administration
- Oracle Real Application Clusters Administration
- Oracle Database Security Guide
- Oracle Database VLDB and Partitioning Guide
- Oracle Automatic Storage Management Administrator's Guide
- Oracle Database Backup and Recovery User's Guide

## 🔍 Key Differences from MySQL Monitoring

For teams familiar with MySQL monitoring, note these Oracle-specific aspects:

| Aspect | Oracle | MySQL |
|--------|--------|-------|
| **Primary Perf Metric** | DB Time / AAS | Threads Running / QPS |
| **Wait Events** | Extensive wait event framework | Limited wait instrumentation |
| **Memory Architecture** | SGA (shared) + PGA (private) | Global buffers + per-thread |
| **Cache Hit Ratio** | Buffer Cache Hit Ratio | InnoDB Buffer Pool Hit Ratio |
| **High Availability** | Data Guard, RAC | InnoDB Cluster, Replication |
| **Audit Framework** | Unified Audit, Database Vault | Audit Plugin, Binary Logs |
| **Performance Repository** | AWR/ASH (built-in) | Performance Schema |
| **Monitoring Tool** | OEM (Oracle Enterprise Manager) | PMM (Percona Monitoring) |

---

**Document Version**: 1.0  
**Last Updated**: November 23, 2025  
**Total Metrics**: 105 (66 Real-time + 15 Capacity Planning + 24 Security)  
**Alert-Worthy Metrics**: 87  
**Database Versions Covered**: Oracle Database 11g, 12c, 18c, 19c, 21c, 23c
