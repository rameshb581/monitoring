import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Create workbook
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "MySQL Monitoring Metrics"

# Define column headers
headers = [
    "Metric Name",
    "Category",
    "Description",
    "Business Impact",
    "Technical Explanation",
    "Normal/Healthy Range",
    "Warning Threshold",
    "Critical Threshold",
    "Severity Level",
    "Monitoring Tool/Exporter",
    "Recommended Alert"
]

# Write headers
for col_num, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num)
    cell.value = header
    cell.font = Font(bold=True, color="FFFFFF", size=11)
    cell.fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

# Set column widths
column_widths = {
    'A': 35,  # Metric Name
    'B': 20,  # Category
    'C': 40,  # Description
    'D': 45,  # Business Impact
    'E': 45,  # Technical Explanation
    'F': 25,  # Normal/Healthy Range
    'G': 25,  # Warning Threshold
    'H': 25,  # Critical Threshold
    'I': 15,  # Severity Level
    'J': 30,  # Monitoring Tool
    'K': 15   # Recommended Alert
}

for col_letter, width in column_widths.items():
    ws.column_dimensions[col_letter].width = width

# Comprehensive metrics data
metrics_data = [
    # === REAL-TIME OPERATIONAL METRICS - CONNECTION METRICS ===
    [
        "Threads_connected",
        "Real-time Operational",
        "Number of currently open client connections to the database",
        "High connections can indicate traffic spikes or connection leaks, leading to performance degradation. If maxed out, new users cannot connect, causing downtime and revenue loss.",
        "Each client connection consumes memory and system resources. MySQL has a max_connections limit that caps concurrent connections.",
        "< 70% of max_connections",
        "> 70% of max_connections",
        "> 90% of max_connections",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Threads_running",
        "Real-time Operational",
        "Number of threads currently executing queries (not sleeping/idle)",
        "High values indicate many concurrent active queries competing for CPU, causing slow response times and poor user experience.",
        "Threads in running state are actively using CPU. High values suggest CPU saturation or slow queries blocking resources.",
        "< 10-20 (varies by CPU cores)",
        "> 20 or > 2x CPU cores",
        "> 50 or > 4x CPU cores",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Max_used_connections",
        "Real-time Operational",
        "Peak number of simultaneous connections since server start",
        "Helps identify if you've ever hit connection limits during peak times. Prevents future connection exhaustion and service outages.",
        "This counter tracks the highest connection watermark. Used for capacity planning and setting max_connections appropriately.",
        "< 70% of max_connections",
        "> 80% of max_connections",
        "> 95% of max_connections",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Connection_errors_max_connections",
        "Real-time Operational",
        "Number of refused connections due to hitting max_connections limit",
        "Direct user impact - customers see 'Too many connections' errors and cannot access services. Lost transactions = lost revenue.",
        "When new connections are attempted but max_connections is reached, MySQL rejects them and increments this counter.",
        "0",
        "> 0 (any occurrences)",
        "> 10 per minute",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Aborted_connects",
        "Real-time Operational",
        "Failed connection attempts due to authentication failures, network issues, or client errors",
        "May indicate security threats (brute force attacks), misconfigured applications, or network problems affecting availability.",
        "Counts connections that failed to establish properly due to bad credentials, network timeouts, or protocol errors.",
        "< 1% of total connections",
        "> 5% of total connections",
        "> 10% or sustained increase",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Aborted_clients",
        "Real-time Operational",
        "Connections terminated improperly by clients (didn't close cleanly)",
        "Indicates application bugs or network instability. Can lead to connection pool exhaustion and degraded application performance.",
        "Client disconnected without properly closing connection (network issue, application crash, or timeout).",
        "< 2% of total connections",
        "> 5% of total connections",
        "> 10% or sudden spikes",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - QUERY PERFORMANCE ===
    [
        "Questions",
        "Real-time Operational",
        "Total number of statements executed by the server (queries per second when monitored over time)",
        "Primary indicator of database workload and user activity. Sudden drops indicate service problems; spikes may cause performance issues.",
        "Counts all statements sent by clients, including queries, inserts, updates, deletes. Used to calculate QPS (Questions Per Second).",
        "Baseline QPS (varies by application)",
        "> 150% of baseline or sudden drop > 30%",
        "> 200% of baseline or drop > 50%",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Queries",
        "Real-time Operational",
        "Total number of queries executed, including stored procedure statements",
        "Similar to Questions but includes stored procedure internal statements. Helps track overall database processing load.",
        "Includes Questions plus statements executed within stored procedures and prepared statements.",
        "Baseline query rate",
        "> 150% of baseline",
        "> 200% of baseline",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Slow_queries",
        "Real-time Operational",
        "Number of queries taking longer than long_query_time parameter",
        "Slow queries directly degrade user experience - pages load slowly, transactions timeout, customers abandon carts. Revenue and satisfaction impact.",
        "Queries exceeding long_query_time threshold (typically 1-10 seconds). Indicates inefficient queries, missing indexes, or resource contention.",
        "< 1% of total queries",
        "> 5% of total queries",
        "> 10% of total queries or sudden spike",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Select_full_join",
        "Real-time Operational",
        "Queries performing joins without using indexes (table scans)",
        "Inefficient queries consuming excessive CPU and I/O. Causes slow response times and can impact all users during high load.",
        "JOIN operations that scan entire tables due to missing indexes or poor query design. Very resource intensive.",
        "0 or minimal (< 0.1% of queries)",
        "> 1% of queries",
        "> 5% or consistent occurrence",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Select_full_range_join",
        "Real-time Operational",
        "Joins using range searches on reference table",
        "Less severe than full joins but still inefficient. Can slow queries and increase I/O load affecting overall performance.",
        "JOIN that requires range scans on the reference table. Better than full scan but not optimal.",
        "< 5% of joins",
        "> 10% of joins",
        "> 20% of joins",
        "Low",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "No"
    ],
    [
        "Select_range",
        "Real-time Operational",
        "Queries using range searches on the first table",
        "Normal operation indicator. Monitoring for abnormal increases helps identify query pattern changes.",
        "First table accessed using range condition (WHERE with >, <, BETWEEN, IN). Generally acceptable performance.",
        "Baseline range query rate",
        "> 150% of baseline",
        "> 200% of baseline with performance issues",
        "Low",
        "PMM, Alloy MySQL Exporter",
        "No"
    ],
    [
        "Select_scan",
        "Real-time Operational",
        "Full table scans performed",
        "Table scans are expensive and slow. High values cause poor query performance, especially on large tables, affecting user wait times.",
        "Queries reading entire tables without using indexes. Acceptable for small tables but problematic for large ones.",
        "< 10% of SELECT queries",
        "> 20% of SELECT queries",
        "> 30% with performance degradation",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Sort_merge_passes",
        "Real-time Operational",
        "Number of merge passes sort algorithm had to do (indicates insufficient sort buffer)",
        "When sort buffer is too small, sorting requires multiple disk passes - very slow. Impacts ORDER BY and GROUP BY query performance.",
        "Sorts that don't fit in sort_buffer_size must write temporary results to disk and merge them - expensive disk I/O.",
        "0 or very low",
        "> 100 per hour",
        "> 1000 per hour or consistent",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Created_tmp_disk_tables",
        "Real-time Operational",
        "Temporary tables created on disk (not in memory)",
        "Disk-based temp tables are 10-100x slower than in-memory. Causes query slowdowns and increased I/O, affecting application responsiveness.",
        "When temp tables exceed tmp_table_size/max_heap_table_size or contain BLOB/TEXT columns, MySQL creates them on disk.",
        "< 10% of Created_tmp_tables",
        "> 25% of Created_tmp_tables",
        "> 50% of Created_tmp_tables",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Created_tmp_tables",
        "Real-time Operational",
        "Total number of temporary tables created automatically during query execution",
        "Indicates complex queries requiring intermediate storage. Excessive temp tables consume memory and resources.",
        "MySQL creates temp tables for GROUP BY, ORDER BY, DISTINCT, subqueries, unions, etc.",
        "Baseline tmp table creation rate",
        "> 150% of baseline",
        "> 200% with performance issues",
        "Low",
        "PMM, Alloy MySQL Exporter",
        "No"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - REPLICATION ===
    [
        "Seconds_Behind_Master",
        "Real-time Operational",
        "Replication lag - how far behind replica is from primary (in seconds)",
        "CRITICAL for data consistency and failover readiness. High lag means stale data for users and longer recovery time if primary fails.",
        "Time difference between when transaction executed on primary vs when it applied on replica. Network, load, or config issues cause lag.",
        "< 1 second",
        "> 5 seconds",
        "> 30 seconds",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Slave_IO_Running / Replica_IO_Running",
        "Real-time Operational",
        "Whether I/O thread is running and connected to primary",
        "If No, replication is completely broken. Data divergence occurs, failover impossible, potential data loss. IMMEDIATE ACTION REQUIRED.",
        "I/O thread receives binary log events from primary. If stopped, replica cannot receive new changes.",
        "Yes",
        "Flapping (intermittent)",
        "No",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor, Custom Script",
        "Yes"
    ],
    [
        "Slave_SQL_Running / Replica_SQL_Running",
        "Real-time Operational",
        "Whether SQL thread is applying received transactions",
        "If No, replication is broken. Replica data becomes stale. Business impact: reporting inaccurate, failover not viable, data loss risk.",
        "SQL thread applies relay log events to replica database. Stops on errors (duplicate key, missing data, etc.).",
        "Yes",
        "Flapping (intermittent)",
        "No",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor, Custom Script",
        "Yes"
    ],
    [
        "group_replication_member_state",
        "Real-time Operational",
        "InnoDB Cluster member status (ONLINE, RECOVERING, OFFLINE, ERROR)",
        "Critical for cluster health. Non-ONLINE members reduce redundancy and failover capacity. Cluster may lose quorum and become unavailable.",
        "Shows if cluster member is actively participating (ONLINE), catching up (RECOVERING), disconnected (OFFLINE), or having issues (ERROR).",
        "ONLINE",
        "RECOVERING > 5 min",
        "OFFLINE or ERROR",
        "Critical",
        "PMM, Alloy MySQL Exporter, Custom Exporter",
        "Yes"
    ],
    [
        "group_replication_primary_member",
        "Real-time Operational",
        "UUID of the current primary (write) node in the cluster",
        "Identifies which node handles writes. Essential for routing write traffic and understanding cluster topology during incidents.",
        "In single-primary mode, only one member accepts writes. This metric identifies that node's UUID.",
        "Valid UUID present",
        "Primary changes frequently",
        "No primary defined or unstable",
        "High",
        "PMM, Custom Exporter",
        "Yes"
    ],
    [
        "group_replication_applier_queue",
        "Real-time Operational",
        "Number of transactions in applier queue waiting to be applied",
        "Large queue indicates replica cannot keep up with writes. Leads to replication lag and stale data for read queries.",
        "Transactions certified by group but not yet applied to local database. Backlog indicates performance bottleneck.",
        "< 1000",
        "> 5000",
        "> 10000",
        "High",
        "PMM, Custom Exporter",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - LOCKS & CONTENTION ===
    [
        "Table_locks_waited",
        "Real-time Operational",
        "Number of times table lock couldn't be acquired immediately",
        "Lock waits mean queries are blocked waiting for other queries to finish. Users experience slow response times and transaction delays.",
        "Table-level locks blocking new queries. Common with MyISAM but rare with InnoDB unless using LOCK TABLES.",
        "Near 0 for InnoDB workloads",
        "> 10 per minute",
        "> 100 per minute",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_row_lock_waits",
        "Real-time Operational",
        "Number of times InnoDB row lock had to wait",
        "Row lock contention causes transaction delays. High values indicate locking issues affecting transaction throughput and user experience.",
        "Transactions waiting to acquire row-level locks held by other transactions. Indicates concurrency conflicts.",
        "< 1% of Innodb_rows_read/written",
        "> 5% or increasing trend",
        "> 10% or sustained high rate",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_row_lock_time",
        "Real-time Operational",
        "Total time spent waiting for row locks (milliseconds)",
        "Cumulative wait time - higher values mean transactions are frequently blocked, causing slow application performance.",
        "Sum of all time transactions spent waiting for locks since server start. Monitor rate of increase.",
        "Minimal increase rate",
        "Rapid increase (> 1000ms/sec)",
        "Very rapid increase (> 5000ms/sec)",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_row_lock_time_avg",
        "Real-time Operational",
        "Average time per row lock wait (milliseconds)",
        "High average wait time indicates problematic locking patterns or long-running transactions blocking others.",
        "Innodb_row_lock_time / Innodb_row_lock_waits. Shows typical duration queries wait for locks.",
        "< 50ms",
        "> 100ms",
        "> 500ms",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_deadlocks",
        "Real-time Operational",
        "Number of deadlocks detected by InnoDB",
        "Deadlocks cause transaction rollbacks and failures. Users see error messages, failed operations, and must retry - poor experience.",
        "Two or more transactions waiting for each other's locks in circular fashion. InnoDB detects and rolls back one transaction.",
        "0-5 per hour (occasional acceptable)",
        "> 10 per hour",
        "> 50 per hour or sudden spike",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_lock_wait_timeout_count",
        "Real-time Operational",
        "Transactions that exceeded innodb_lock_wait_timeout",
        "Lock wait timeouts cause transaction failures and application errors. Users see 'Lock wait timeout exceeded' and operations fail.",
        "Transaction waited too long for lock (default 50 seconds) and was rolled back. Indicates severe lock contention.",
        "0",
        "> 1 per hour",
        "> 10 per hour",
        "Critical",
        "PMM, Alloy MySQL Exporter, Custom Exporter",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - BUFFER POOL & CACHE ===
    [
        "Innodb_buffer_pool_size",
        "Real-time Operational",
        "Size of InnoDB buffer pool (configured value)",
        "Most important MySQL tuning parameter. Too small = excessive disk I/O and terrible performance. Affects all query speeds.",
        "InnoDB's cache for table and index data. Should be 70-80% of available RAM on dedicated DB server.",
        "70-80% of available RAM",
        "< 50% of RAM or > 90% causing swapping",
        "< 25% of RAM or causing system instability",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "No"
    ],
    [
        "Innodb_buffer_pool_read_requests",
        "Real-time Operational",
        "Logical reads from buffer pool (data requested from cache)",
        "Shows total data access activity. Used to calculate buffer pool hit ratio - key performance indicator.",
        "Number of reads InnoDB made from the buffer pool cache (memory).",
        "N/A (used for ratio calculation)",
        "N/A",
        "N/A",
        "Low",
        "PMM, Alloy MySQL Exporter",
        "No"
    ],
    [
        "Innodb_buffer_pool_reads",
        "Real-time Operational",
        "Physical reads from disk because data wasn't in buffer pool",
        "Disk reads are 100x slower than memory. High values mean poor cache efficiency and slow query performance.",
        "Data not found in buffer pool so InnoDB had to read from disk. Should be very low compared to read_requests.",
        "< 1% of read_requests",
        "> 2% of read_requests",
        "> 5% of read_requests",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_buffer_pool_hit_ratio",
        "Real-time Operational",
        "Percentage of reads served from memory vs disk (calculated metric)",
        "THE KEY cache performance metric. < 99% means too many slow disk reads, poor query performance, frustrated users.",
        "Calculated: 100 * (1 - Innodb_buffer_pool_reads / Innodb_buffer_pool_read_requests). Measures cache effectiveness.",
        "> 99%",
        "< 98%",
        "< 95%",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_buffer_pool_pages_free",
        "Real-time Operational",
        "Number of free pages in buffer pool",
        "If near zero, buffer pool is full. May need to increase size or investigate memory usage patterns.",
        "Free pages available for caching new data. Very low value means buffer pool is saturated.",
        "> 5% of total pages",
        "< 5% of total pages",
        "< 1% of total pages",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_buffer_pool_pages_dirty",
        "Real-time Operational",
        "Number of modified pages not yet written to disk",
        "High dirty pages can cause checkpoint stalls and sudden performance drops. Indicates write load and checkpoint efficiency.",
        "Modified pages in memory waiting to be flushed to disk. Too many indicates flush threads can't keep up.",
        "< 75% of buffer pool pages",
        "> 80% of buffer pool pages",
        "> 90% or causing checkpoints stalls",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_buffer_pool_wait_free",
        "Real-time Operational",
        "Number of times had to wait for free page in buffer pool",
        "Waits mean query delays while MySQL makes space in buffer pool. Direct performance impact on all queries.",
        "No free pages available, query must wait for InnoDB to flush dirty pages to disk. Very bad for performance.",
        "0",
        "> 0 (any occurrences)",
        "Consistently > 0",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Query_cache_hit_ratio",
        "Real-time Operational",
        "Percentage of queries served from query cache (if enabled)",
        "Query cache is deprecated in MySQL 8.0+. If used, hit ratio shows cache effectiveness for repeated identical queries.",
        "Percentage of queries returning results from cache vs executing. Note: Query cache often causes more problems than benefits.",
        "Deprecated in MySQL 8.0+",
        "< 20% if enabled (ineffective)",
        "N/A",
        "Low",
        "PMM, MySQL Enterprise Monitor (legacy)",
        "No"
    ],
    [
        "Key_read_requests",
        "Real-time Operational",
        "MyISAM key cache read requests",
        "Only relevant for MyISAM tables. High values without high Key_reads indicates good MyISAM cache performance.",
        "Index block reads requested from MyISAM key cache. InnoDB users can ignore this.",
        "N/A (InnoDB preferred)",
        "N/A",
        "N/A",
        "Low",
        "PMM, Alloy MySQL Exporter (if using MyISAM)",
        "No"
    ],
    [
        "Key_reads",
        "Real-time Operational",
        "MyISAM key cache misses requiring disk reads",
        "Disk reads for MyISAM indexes. Should be very low compared to Key_read_requests for good performance.",
        "Index blocks read from disk because not in key cache. InnoDB users can ignore.",
        "< 1% of Key_read_requests",
        "> 2% of Key_read_requests",
        "> 5% of Key_read_requests",
        "Medium",
        "PMM, Alloy MySQL Exporter (if using MyISAM)",
        "No"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - TRANSACTIONS ===
    [
        "Com_commit",
        "Real-time Operational",
        "Number of COMMIT statements executed",
        "Transaction throughput indicator. Drops indicate application problems or database issues preventing successful transactions.",
        "Explicit and implicit commits. Measures successful transaction completion rate.",
        "Baseline commit rate",
        "> 30% deviation from baseline",
        "> 50% deviation or sudden drop",
        "Medium",
        "PMM, Alloy MySQL Exporter",
        "Yes"
    ],
    [
        "Com_rollback",
        "Real-time Operational",
        "Number of ROLLBACK statements executed",
        "High rollbacks indicate application errors, deadlocks, or constraint violations. Failed transactions = failed business operations.",
        "Explicit rollbacks by application or automatic rollbacks due to errors/deadlocks.",
        "< 5% of Com_commit",
        "> 10% of Com_commit",
        "> 20% or sudden spike",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Handler_commit",
        "Real-time Operational",
        "Number of internal commit operations",
        "Lower level than Com_commit - includes storage engine commits. Used for detailed transaction analysis.",
        "Internal handler-level commit operations. Includes both explicit and internal commits.",
        "Baseline handler commit rate",
        "> 30% deviation",
        "> 50% deviation",
        "Low",
        "PMM, Alloy MySQL Exporter",
        "No"
    ],
    [
        "Handler_rollback",
        "Real-time Operational",
        "Number of internal rollback operations",
        "Similar to Com_rollback but at storage engine level. Helps diagnose transaction failure patterns.",
        "Internal handler-level rollback operations.",
        "< 5% of Handler_commit",
        "> 10% of Handler_commit",
        "> 20% or sudden spike",
        "Low",
        "PMM, Alloy MySQL Exporter",
        "No"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - I/O & DISK ===
    [
        "Innodb_data_reads",
        "Real-time Operational",
        "Number of OS file reads performed by InnoDB",
        "I/O activity indicator. High values suggest insufficient memory cache or heavy read workload. Can saturate disk I/O.",
        "Physical read operations to datafiles. High rate indicates buffer pool misses.",
        "Baseline I/O rate",
        "> 150% of baseline",
        "> 200% or I/O saturation",
        "Medium",
        "PMM, Alloy MySQL Exporter",
        "Yes"
    ],
    [
        "Innodb_data_writes",
        "Real-time Operational",
        "Number of OS file writes performed by InnoDB",
        "Write I/O activity. Excessive writes can saturate disks causing slowdowns for all operations.",
        "Physical write operations to datafiles. Includes data pages and redo log writes.",
        "Baseline write I/O rate",
        "> 150% of baseline",
        "> 200% or I/O saturation",
        "Medium",
        "PMM, Alloy MySQL Exporter",
        "Yes"
    ],
    [
        "Innodb_data_fsyncs",
        "Real-time Operational",
        "Number of fsync() operations",
        "fsync forces data to disk - slow operation. High rate can cause performance issues especially with slow storage.",
        "Ensuring data durability by forcing writes to persistent storage. Critical for data integrity but expensive.",
        "Baseline fsync rate",
        "> 150% of baseline",
        "> 200% or causing latency",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_os_log_written",
        "Real-time Operational",
        "Bytes written to InnoDB redo log",
        "Redo log write volume. Helps size redo logs appropriately and understand write workload intensity.",
        "All transaction changes must be logged before commit. High rate indicates heavy write load.",
        "Baseline redo log write rate",
        "> 150% of baseline",
        "> 200% of baseline",
        "Low",
        "PMM, Alloy MySQL Exporter",
        "No"
    ],
    [
        "Innodb_log_waits",
        "Real-time Operational",
        "Number of times log buffer was too small and had to wait",
        "Log waits pause transactions - direct performance impact. Indicates innodb_log_buffer_size is too small.",
        "Log buffer full, transaction must wait for flush to continue. Should be zero - resize buffer if happening.",
        "0",
        "> 0 (any occurrences)",
        "Consistently > 0",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Innodb_checkpoint_age",
        "Real-time Operational",
        "Age of the oldest dirty page in the buffer pool",
        "Large checkpoint age can cause aggressive flushing and sudden performance drops. Indicates write workload vs flush capacity.",
        "Difference between current LSN and last checkpoint LSN. Too large means redo logs will fill and force synchronous flush.",
        "< 75% of redo log size",
        "> 80% of redo log size",
        "> 90% or causing async checkpoint stalls",
        "Medium",
        "PMM, Custom Exporter",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - THREADS & PROCESSES ===
    [
        "Threads_created",
        "Real-time Operational",
        "Total threads created to handle connections",
        "High thread creation rate indicates thread cache misses. Thread creation is expensive - impacts connection establishment speed.",
        "When thread cache is empty, MySQL creates new threads. Monitor rate of increase.",
        "Minimal increase rate",
        "Consistently increasing > 10/sec",
        "> 50/sec or rapid increase",
        "Medium",
        "PMM, Alloy MySQL Exporter",
        "Yes"
    ],
    [
        "Threads_cached",
        "Real-time Operational",
        "Number of threads in the thread cache",
        "Cached threads can be reused, avoiding expensive thread creation. Good cache utilization improves connection performance.",
        "Idle threads kept in cache for reuse. Should stay near thread_cache_size during steady state.",
        "Close to thread_cache_size",
        "Consistently at 0",
        "N/A",
        "Low",
        "PMM, Alloy MySQL Exporter",
        "No"
    ],
    [
        "Open_tables",
        "Real-time Operational",
        "Number of tables currently open",
        "Too many open tables wastes memory. If hitting table_open_cache limit, causes table open/close thrashing - performance impact.",
        "Cached table file descriptors. Controlled by table_open_cache. Opening tables is expensive.",
        "< 80% of table_open_cache",
        "> 90% of table_open_cache",
        "At table_open_cache limit consistently",
        "Medium",
        "PMM, Alloy MySQL Exporter",
        "Yes"
    ],
    [
        "Opened_tables",
        "Real-time Operational",
        "Total number of tables opened since server start",
        "Monitor rate of increase. Rapid increase indicates table cache thrashing - need larger table_open_cache.",
        "Cumulative count of table opens. Should increase slowly during steady state.",
        "Slow increase rate",
        "Rapid increase (> 100/sec)",
        "Very rapid increase (> 500/sec)",
        "Medium",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Table_open_cache_misses",
        "Real-time Operational",
        "Number of table open cache misses",
        "Cache misses force expensive table opens. High rate slows query execution and wastes resources.",
        "Table needed but not in cache - must open from disk. Indicates table_open_cache too small.",
        "< 10 per second",
        "> 50 per second",
        "> 100 per second",
        "Medium",
        "PMM, Alloy MySQL Exporter",
        "Yes"
    ],
    [
        "Open_files",
        "Real-time Operational",
        "Number of files currently open",
        "If approaching OS file descriptor limit or open_files_limit, MySQL cannot open new files - causes errors and availability issues.",
        "Open file descriptors (tables, logs, temp files). Must stay below open_files_limit and OS limit.",
        "< 70% of open_files_limit",
        "> 80% of open_files_limit",
        "> 90% of open_files_limit",
        "High",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - ERROR & STATUS ===
    [
        "Uptime",
        "Real-time Operational",
        "Seconds since server was started",
        "Unexpected restarts indicate crashes or instability. Downtime = service unavailability and revenue loss.",
        "Time since last server start. Sudden reset indicates crash or restart.",
        "Increasing continuously",
        "Unexpected reset",
        "Frequent resets",
        "Critical",
        "PMM, Alloy MySQL Exporter, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Prepared_stmt_count",
        "Real-time Operational",
        "Number of current prepared statements",
        "Too many prepared statements consume memory. Can indicate application not properly closing statements - memory leak risk.",
        "Prepared statements cached in memory. Excessive count may indicate application bugs.",
        "< max_prepared_stmt_count",
        "> 75% of max_prepared_stmt_count",
        "> 90% or causing memory issues",
        "Medium",
        "PMM, Alloy MySQL Exporter",
        "Yes"
    ],
    
    # === CAPACITY PLANNING & TREND ANALYSIS ===
    [
        "Disk_Space_Used (datadir)",
        "Capacity Planning",
        "Total disk space consumed by MySQL data directory",
        "Running out of disk space causes database crashes and complete service outage. Must plan capacity to prevent emergencies.",
        "Size of all database files, logs, temp files in data directory. Monitor growth rate for planning.",
        "< 70% of available disk",
        "> 80% of available disk",
        "> 90% of available disk",
        "Critical",
        "OS Monitoring, PMM, Custom Script",
        "Yes"
    ],
    [
        "Disk_Space_Growth_Rate",
        "Capacity Planning",
        "Rate of database storage growth (GB per day/week)",
        "Predicts when you'll run out of space. Essential for budget planning and preventing storage-related outages.",
        "Calculated by monitoring disk usage over time. Helps forecast future capacity needs.",
        "Predictable and budgeted",
        "Exceeding planned growth rate",
        "Exponential/unexpected growth",
        "High",
        "PMM (calculated), Custom Script",
        "Yes"
    ],
    [
        "Table_Size_Growth",
        "Capacity Planning",
        "Growth rate of largest tables",
        "Identifies tables growing fastest. Helps plan archiving, partitioning, or scaling strategies before performance degrades.",
        "Query information_schema to track table sizes over time. Focus on top 10 largest tables.",
        "Expected growth pattern",
        "> 50% month-over-month growth",
        "> 100% month-over-month or runaway",
        "Medium",
        "Custom Query/Script, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Index_Size_Growth",
        "Capacity Planning",
        "Growth rate of table indexes",
        "Large indexes slow queries and consume memory. Helps identify over-indexing or table/index bloat issues.",
        "Sum of index sizes from information_schema. Indexes often grow larger than tables themselves.",
        "Proportional to table growth",
        "Indexes > 2x table size",
        "Indexes > 5x table size",
        "Medium",
        "Custom Query/Script",
        "No"
    ],
    [
        "Connection_Growth_Trend",
        "Capacity Planning",
        "Trend of peak concurrent connections over time",
        "Helps forecast when you'll hit max_connections limit. Prevents future connection exhaustion during traffic growth.",
        "Track Max_used_connections daily/weekly to identify growth trends.",
        "Steady and predictable",
        "Growing > 20% monthly",
        "Growing > 50% monthly",
        "High",
        "PMM (calculated), Custom Analysis",
        "Yes"
    ],
    [
        "Query_Volume_Trend",
        "Capacity Planning",
        "Trend of queries per second over weeks/months",
        "Growing QPS requires capacity planning for CPU, memory, storage I/O. Prevents performance degradation during growth.",
        "Track Questions or Queries metrics over time to identify growth patterns.",
        "Matches expected traffic growth",
        "Growing faster than capacity",
        "Approaching known capacity limits",
        "High",
        "PMM (calculated), Custom Analysis",
        "Yes"
    ],
    [
        "Average_Query_Response_Time_Trend",
        "Capacity Planning",
        "Long-term trend of query performance",
        "Gradually increasing response times indicate growing pains - need optimization or scaling before user experience suffers.",
        "Track average query execution time from Performance Schema or slow query log analysis over time.",
        "Stable or improving",
        "Increasing > 25% monthly",
        "Increasing > 50% or degrading rapidly",
        "High",
        "PMM, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Memory_Usage_Trend",
        "Capacity Planning",
        "Trend of MySQL memory consumption",
        "Growing memory usage may require more RAM or optimization. Prevents swapping and OOM kills which cause outages.",
        "Track RSS (Resident Set Size) of MySQL process over time from OS metrics.",
        "Stable within available RAM",
        "Approaching 90% of available RAM",
        "> 95% or causing swapping",
        "High",
        "OS Monitoring, PMM",
        "Yes"
    ],
    [
        "CPU_Usage_Trend",
        "Capacity Planning",
        "Trend of CPU utilization over time",
        "Growing CPU usage forecasts need for more cores or optimization. High CPU causes query queueing and slow response.",
        "Track MySQL process CPU % from OS metrics over time.",
        "< 70% average utilization",
        "> 80% average or peaks at 100%",
        "Sustained > 90% or constant saturation",
        "High",
        "OS Monitoring, PMM",
        "Yes"
    ],
    [
        "Backup_Size_Growth",
        "Capacity Planning",
        "Rate of backup size increase",
        "Affects backup storage costs and backup/restore times. Plan backup infrastructure capacity.",
        "Track full backup sizes over time. Impacts RTO (Recovery Time Objective) as restores take longer.",
        "Matches database growth",
        "Growing faster than expected",
        "Backup storage approaching limits",
        "Medium",
        "Backup Tool Logs, Custom Script",
        "Yes"
    ],
    [
        "Backup_Duration_Trend",
        "Capacity Planning",
        "How long backups take over time",
        "Longer backups may impact backup windows and RTO. May need backup strategy changes (incremental, parallel, etc.).",
        "Monitor backup job duration. Growing duration impacts maintenance windows and recovery objectives.",
        "Within acceptable window",
        "Approaching maintenance window limit",
        "Exceeding maintenance window",
        "Medium",
        "Backup Tool Logs, Custom Script",
        "Yes"
    ],
    [
        "Binlog_Size_Growth",
        "Capacity Planning",
        "Binary log accumulation rate",
        "Binary logs required for replication and point-in-time recovery. Excessive growth consumes disk and may indicate purge issues.",
        "Monitor size of binary log files and expiration settings. Affects disaster recovery capabilities.",
        "Purged according to policy",
        "Growing beyond purge schedule",
        "Consuming excessive disk space",
        "Medium",
        "Custom Script, PMM",
        "Yes"
    ],
    [
        "Number_of_Databases_Trend",
        "Capacity Planning",
        "Trend in number of databases (schemas)",
        "Rapid database proliferation affects management complexity and resource allocation.",
        "Count from information_schema.SCHEMATA. Growth may indicate multi-tenancy patterns.",
        "Stable or planned growth",
        "Unplanned rapid growth",
        "Uncontrolled proliferation",
        "Low",
        "Custom Query",
        "No"
    ],
    [
        "Number_of_Tables_Trend",
        "Capacity Planning",
        "Trend in total number of tables",
        "Many tables impact metadata performance and operations like backup. May need partitioning or archival strategy.",
        "Count from information_schema.TABLES. Too many tables (>10k) can cause metadata performance issues.",
        "< 1000 tables preferred",
        "> 5000 tables",
        "> 10000 tables",
        "Medium",
        "Custom Query",
        "No"
    ],
    [
        "Temp_File_Size_Trend",
        "Capacity Planning",
        "Growth of temporary file usage",
        "Large temp file usage indicates complex queries or insufficient memory. Affects temp filesystem capacity planning.",
        "Monitor tmpdir disk usage and Created_tmp_disk_tables rate.",
        "Minimal temp file usage",
        "Frequent large temp files",
        "Temp filesystem full or near full",
        "Medium",
        "OS Monitoring, Alloy MySQL Exporter",
        "Yes"
    ],
    
    # === SECURITY & COMPLIANCE ===
    [
        "Failed_Login_Attempts",
        "Security & Compliance",
        "Number of failed authentication attempts",
        "Sudden spikes indicate brute force attacks or credential stuffing. Security breach risk and compliance violation concern.",
        "Count from audit log or error log parsing. Pattern analysis helps identify attack vectors.",
        "< 5 per hour (occasional typos)",
        "> 20 per hour",
        "> 100 per hour or coordinated pattern",
        "Critical",
        "Audit Plugin, Custom Log Parser, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Failed_Login_From_Unknown_Hosts",
        "Security & Compliance",
        "Failed logins from unexpected IP addresses",
        "External attack indicator. Requires immediate investigation and potential IP blocking.",
        "Correlate failed attempts with expected source IPs. Unknown sources indicate reconnaissance or attack.",
        "0 from unexpected sources",
        "> 0 from unknown sources",
        "Sustained attempts from unknown sources",
        "Critical",
        "Audit Plugin, Custom Log Parser, Firewall Integration",
        "Yes"
    ],
    [
        "Privilege_Changes",
        "Security & Compliance",
        "GRANT, REVOKE, or privilege table modifications",
        "Unauthorized privilege changes = potential security breach. Compliance requires tracking all permission changes.",
        "Monitor GRANT/REVOKE statements and mysql.user/mysql.db table changes via audit log.",
        "Only authorized changes",
        "Unexpected privilege changes",
        "Unauthorized admin privilege grants",
        "Critical",
        "Audit Plugin, Binary Log Analysis, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "User_Account_Changes",
        "Security & Compliance",
        "CREATE USER, DROP USER, ALTER USER statements",
        "User account changes must be tracked for compliance and security auditing. Unauthorized account creation = breach risk.",
        "Track user management DDL statements via audit log or binary log.",
        "Only authorized changes",
        "Unexpected account changes",
        "Unauthorized account creation",
        "Critical",
        "Audit Plugin, Binary Log Analysis",
        "Yes"
    ],
    [
        "Access_Denied_Errors",
        "Security & Compliance",
        "Access denied errors from authenticated users",
        "May indicate privilege misconfigurations or insider threat attempting unauthorized data access.",
        "Users authenticated but trying operations they lack privileges for. Pattern analysis important.",
        "Rare (occasional mistakes)",
        "> 10 per hour per user",
        "Sustained or pattern suggesting attack",
        "High",
        "Error Log Parser, Audit Plugin",
        "Yes"
    ],
    [
        "Root_Login_Attempts",
        "Security & Compliance",
        "Login attempts using root or admin accounts",
        "Root should rarely log in directly (use sudo). Direct root access violates security best practices and compliance.",
        "Track root user connections. Should use dedicated admin accounts with logging.",
        "0 direct root logins (use sudo)",
        "Direct root logins occurring",
        "Root logins from unexpected sources",
        "High",
        "Audit Plugin, Connection Log Analysis",
        "Yes"
    ],
    [
        "SSL_TLS_Connection_Ratio",
        "Security & Compliance",
        "Percentage of connections using encrypted SSL/TLS",
        "Unencrypted connections expose data in transit. Compliance regulations often require encryption (PCI DSS, HIPAA, GDPR).",
        "Compare Ssl_accepts vs Connections. All production connections should use TLS.",
        "100% encrypted",
        "< 100% (some unencrypted)",
        "< 80% or sensitive data unencrypted",
        "High",
        "PMM, Alloy MySQL Exporter, Custom Script",
        "Yes"
    ],
    [
        "Weak_Password_Accounts",
        "Security & Compliance",
        "User accounts with weak or no passwords",
        "Weak passwords = easy breach point. Compliance violations and security risk.",
        "Use validate_password plugin to check. Scan mysql.user for accounts with empty passwords.",
        "0 weak passwords",
        "> 0 weak passwords",
        "Empty passwords or many weak",
        "Critical",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "Accounts_Without_Host_Restrictions",
        "Security & Compliance",
        "Users with '%' (any host) in host column",
        "Overly permissive host restrictions = security risk. Best practice: restrict to specific IPs/networks.",
        "Query mysql.user for host='%'. Should limit to specific IPs or networks.",
        "0 or very few (non-privileged only)",
        "Admin accounts with '%' host",
        "Critical accounts accessible anywhere",
        "High",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "Anonymous_User_Accounts",
        "Security & Compliance",
        "Anonymous users (empty username) in user table",
        "Anonymous accounts = major security hole. Should be removed immediately.",
        "Query mysql.user WHERE user=''. Common in default installations, must remove.",
        "0",
        "> 0",
        "> 0",
        "Critical",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "Accounts_With_SUPER_Privilege",
        "Security & Compliance",
        "Number of accounts with SUPER or *_ADMIN privileges",
        "Too many admin accounts = increased breach risk. Minimize privileged accounts per least privilege principle.",
        "Query mysql.user for SUPER and various _ADMIN privileges. Should be very limited.",
        "< 5 admin accounts",
        "> 10 admin accounts",
        "> 20 or service accounts with SUPER",
        "High",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "Audit_Log_Size_Growth",
        "Security & Compliance",
        "Audit log size and growth rate",
        "Audit logs required for compliance. Must ensure adequate storage and retention. Missing logs = compliance failure.",
        "Monitor audit log file sizes and rotation. Critical for forensics and compliance audits.",
        "Within retention policy",
        "Approaching storage limits",
        "Logs not being retained properly",
        "High",
        "Custom Script, OS Monitoring",
        "Yes"
    ],
    [
        "Data_Access_Pattern_Anomalies",
        "Security & Compliance",
        "Unusual data access patterns (time, volume, tables)",
        "Anomalies may indicate data exfiltration, insider threat, or compromised account. Requires ML/AI or baseline analysis.",
        "Compare current access patterns to baseline. Unusual SELECT volume, timing, or table access requires investigation.",
        "Normal pattern baseline",
        "Moderate deviation from baseline",
        "Significant anomaly or off-hours bulk access",
        "High",
        "MySQL Enterprise Monitor, Custom ML Analysis, Audit Log Analysis",
        "Yes"
    ],
    [
        "DDL_Statement_Execution",
        "Security & Compliance",
        "CREATE, ALTER, DROP, TRUNCATE statements",
        "Schema changes must be tracked for compliance and change management. Unauthorized DDL = potential sabotage or error.",
        "Monitor DDL via audit log or binary log. Should match approved change management process.",
        "Only during maintenance windows",
        "Unexpected DDL in production hours",
        "Unauthorized schema changes",
        "Critical",
        "Audit Plugin, Binary Log Analysis",
        "Yes"
    ],
    [
        "Replication_User_Activity",
        "Security & Compliance",
        "Activity on replication user accounts",
        "Replication accounts should only be used by replicas. Other activity indicates compromise or misconfiguration.",
        "Monitor connections and queries from replication user. Should only see binlog dump activity.",
        "Only binlog dump connections",
        "Replication user used for other queries",
        "Replication user running DML/DDL",
        "Critical",
        "Audit Plugin, Connection Log Analysis",
        "Yes"
    ],
    [
        "SQL_Injection_Pattern_Detection",
        "Security & Compliance",
        "Queries containing potential SQL injection patterns",
        "SQL injection = major application vulnerability. Detection helps identify attack attempts or vulnerable code.",
        "Pattern matching on queries for common injection signatures (UNION, comment injection, etc.).",
        "0 injection patterns",
        "Potential injection attempts detected",
        "Confirmed injection attempts",
        "Critical",
        "Custom Log Analysis, WAF Integration, MySQL Enterprise Monitor",
        "Yes"
    ],
    [
        "Binary_Log_Encryption_Status",
        "Security & Compliance",
        "Whether binary logs are encrypted at rest",
        "Binary logs contain all data changes. Encryption required for compliance with sensitive data regulations.",
        "Check binlog_encryption setting. Should be ON for compliance.",
        "ON (encrypted)",
        "OFF (not encrypted) with sensitive data",
        "OFF (compliance violation)",
        "High",
        "Configuration Audit, Custom Script",
        "Yes"
    ],
    [
        "Data_At_Rest_Encryption_Status",
        "Security & Compliance",
        "Percentage of tables using encryption",
        "Data at rest encryption required for compliance (PCI DSS, HIPAA, etc.). Unencrypted sensitive data = major risk.",
        "Check ENCRYPTION='Y' in information_schema.TABLES. Should be 100% for sensitive data.",
        "100% for sensitive tables",
        "< 100% coverage",
        "Sensitive data unencrypted",
        "Critical",
        "Custom Query, Configuration Audit",
        "Yes"
    ],
    [
        "Password_Expiration_Compliance",
        "Security & Compliance",
        "User accounts with expired or non-expiring passwords",
        "Password rotation required by many compliance frameworks. Non-expiring passwords violate policy.",
        "Check password_lifetime and password_last_changed from mysql.user.",
        "All passwords within policy",
        "Some accounts overdue rotation",
        "Many accounts non-compliant",
        "Medium",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "Connections_From_Unexpected_Countries",
        "Security & Compliance",
        "Database connections from unusual geographic locations",
        "GeoIP analysis can detect compromised credentials used from attacker locations.",
        "Correlate connection source IPs with GeoIP data. Unexpected countries may indicate breach.",
        "Only expected geographic sources",
        "Connections from unexpected countries",
        "Connections from high-risk countries",
        "High",
        "Custom GeoIP Analysis, Firewall Logs",
        "Yes"
    ],
    [
        "Backup_Encryption_Status",
        "Security & Compliance",
        "Whether backups are encrypted",
        "Unencrypted backups = data exposure risk. Compliance requires backup encryption for sensitive data.",
        "Verify backup tool encryption settings. Critical for compliance and security.",
        "All backups encrypted",
        "Some backups unencrypted",
        "Sensitive data backups unencrypted",
        "Critical",
        "Backup Tool Audit, Custom Script",
        "Yes"
    ],
    [
        "Compliance_Report_Generation_Status",
        "Security & Compliance",
        "Successful generation of compliance reports (PCI DSS, HIPAA, SOX, etc.)",
        "Failed report generation impacts audit readiness and compliance certification. Business and legal risk.",
        "Monitor automated compliance report job status. Reports must be available for audits.",
        "All reports generating successfully",
        "Report generation failures",
        "Extended outage or missing reports",
        "High",
        "Custom Compliance System, Monitoring",
        "Yes"
    ]
]

# Write data rows
for row_num, row_data in enumerate(metrics_data, 2):
    for col_num, value in enumerate(row_data, 1):
        cell = ws.cell(row=row_num, column=col_num)
        cell.value = value
        cell.alignment = Alignment(vertical="top", wrap_text=True)
        cell.border = Border(
            left=Side(style='thin', color='CCCCCC'),
            right=Side(style='thin', color='CCCCCC'),
            top=Side(style='thin', color='CCCCCC'),
            bottom=Side(style='thin', color='CCCCCC')
        )
        
        # Category coloring
        if col_num == 2:  # Category column
            if value == "Real-time Operational":
                cell.fill = PatternFill(start_color="E7F4FF", end_color="E7F4FF", fill_type="solid")
            elif value == "Capacity Planning":
                cell.fill = PatternFill(start_color="FFF4E7", end_color="FFF4E7", fill_type="solid")
            elif value == "Security & Compliance":
                cell.fill = PatternFill(start_color="FFE7E7", end_color="FFE7E7", fill_type="solid")
        
        # Severity Level coloring
        if col_num == 9:  # Severity Level column
            if value == "Critical":
                cell.fill = PatternFill(start_color="FF6B6B", end_color="FF6B6B", fill_type="solid")
                cell.font = Font(bold=True, color="FFFFFF")
            elif value == "High":
                cell.fill = PatternFill(start_color="FFB366", end_color="FFB366", fill_type="solid")
                cell.font = Font(bold=True, color="FFFFFF")
            elif value == "Medium":
                cell.fill = PatternFill(start_color="FFE066", end_color="FFE066", fill_type="solid")
                cell.font = Font(bold=True)
            elif value == "Low":
                cell.fill = PatternFill(start_color="B3E6B3", end_color="B3E6B3", fill_type="solid")
        
        # Alert recommendation coloring
        if col_num == 11:  # Recommended Alert column
            if value == "Yes":
                cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
                cell.font = Font(bold=True)
            elif value == "No":
                cell.fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")

# Freeze header row
ws.freeze_panes = "A2"

# Auto-filter
ws.auto_filter.ref = f"A1:K{len(metrics_data) + 1}"

# Save workbook
wb.save("/home/ubuntu/MySQL_InnoDB_Cluster_Monitoring_Metrics.xlsx")
print("Excel file created successfully!")
print(f"Total metrics documented: {len(metrics_data)}")
print(f"- Real-time Operational: {sum(1 for m in metrics_data if m[1] == 'Real-time Operational')}")
print(f"- Capacity Planning: {sum(1 for m in metrics_data if m[1] == 'Capacity Planning')}")
print(f"- Security & Compliance: {sum(1 for m in metrics_data if m[1] == 'Security & Compliance')}")
