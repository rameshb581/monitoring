import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Create workbook
wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Oracle Monitoring Metrics"

# Define column headers
headers = [
    "Metric Name",
    "Category",
    "Description",
    "Business Impact",
    "Technical Explanation",
    "Normal/Healthy Range",
    "Warning Threshold",
    "Critical Threshold",
    "Severity Level",
    "Monitoring Tool/Exporter",
    "Recommended Alert"
]

# Write headers
for col_num, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_num)
    cell.value = header
    cell.font = Font(bold=True, color="FFFFFF", size=11)
    cell.fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

# Set column widths
column_widths = {
    'A': 40,  # Metric Name
    'B': 20,  # Category
    'C': 40,  # Description
    'D': 45,  # Business Impact
    'E': 45,  # Technical Explanation
    'F': 25,  # Normal/Healthy Range
    'G': 25,  # Warning Threshold
    'H': 25,  # Critical Threshold
    'I': 15,  # Severity Level
    'J': 35,  # Monitoring Tool
    'K': 15   # Recommended Alert
}

for col_letter, width in column_widths.items():
    ws.column_dimensions[col_letter].width = width

# Comprehensive Oracle metrics data
metrics_data = [
    # === REAL-TIME OPERATIONAL METRICS - SESSION METRICS ===
    [
        "Active Sessions",
        "Real-time Operational",
        "Number of sessions currently executing SQL or waiting for resources",
        "High active sessions indicate heavy workload or resource contention. Can lead to slow response times, transaction delays, and poor user experience affecting productivity and revenue.",
        "Sessions in V$SESSION with STATUS='ACTIVE'. Indicates concurrent work being performed. High values suggest CPU saturation or wait events.",
        "< 70% of PROCESSES parameter",
        "> 70% of PROCESSES or sustained high",
        "> 90% of PROCESSES or causing queuing",
        "High",
        "OEM, Grafana Oracle Exporter, Prometheus oracledb_exporter",
        "Yes"
    ],
    [
        "Total Sessions",
        "Real-time Operational",
        "Total number of database sessions including active and inactive",
        "If approaching SESSIONS or PROCESSES limit, new users cannot connect causing application failures and service outages. Direct revenue impact.",
        "Count from V$SESSION. Must stay below SESSIONS parameter (typically 1.5x PROCESSES). Maximum concurrent connections.",
        "< 80% of SESSIONS parameter",
        "> 85% of SESSIONS parameter",
        "> 95% or hitting SESSIONS limit",
        "High",
        "OEM, Grafana Oracle Exporter, Prometheus oracledb_exporter",
        "Yes"
    ],
    [
        "Blocked Sessions",
        "Real-time Operational",
        "Sessions waiting due to locks held by other sessions",
        "Blocked sessions mean users are waiting - transactions stall, applications hang, users see spinning wheels. Frustration leads to abandoned transactions and lost revenue.",
        "Sessions with BLOCKING_SESSION IS NOT NULL in V$SESSION. Lock contention preventing work from completing.",
        "0-2 sessions",
        "> 5 sessions blocked",
        "> 10 sessions or long duration (>5 min)",
        "Critical",
        "OEM, Grafana Oracle Exporter, Custom Script",
        "Yes"
    ],
    [
        "Long Running Sessions",
        "Real-time Operational",
        "Sessions with queries running longer than threshold (e.g., 30 min)",
        "Long-running queries consume resources and can block other users. May indicate runaway queries, missing indexes, or inefficient SQL affecting overall performance.",
        "Query V$SESSION_LONGOPS or track LAST_CALL_ET in V$SESSION. Long-running can be legitimate batch jobs or problematic queries.",
        "Expected batch jobs only",
        "> 5 long-running non-batch queries",
        "> 10 or unexpected long-running queries",
        "High",
        "OEM, Custom SQL Script",
        "Yes"
    ],
    [
        "Inactive Sessions Holding Locks",
        "Real-time Operational",
        "Inactive sessions that still hold locks on database objects",
        "Zombie sessions blocking active work. Users cannot complete transactions due to forgotten uncommitted changes. Causes application hangs and requires manual intervention.",
        "Inactive sessions (STATUS='INACTIVE') with locks in V$LOCK. Often due to application connection pool issues or uncommitted transactions.",
        "0 sessions",
        "> 2 sessions",
        "> 5 sessions or long duration",
        "High",
        "OEM, Custom SQL Script",
        "Yes"
    ],
    [
        "Sessions at PROCESSES Limit",
        "Real-time Operational",
        "Current process count approaching or at PROCESSES parameter limit",
        "Hitting process limit means no new connections possible - complete application failure. ORA-00020 maximum processes exceeded causes immediate outage.",
        "Compare current process count to PROCESSES init parameter. Operating system and Oracle both have process limits.",
        "< 80% of PROCESSES",
        "> 85% of PROCESSES",
        "> 95% or ORA-00020 errors",
        "Critical",
        "OEM, Grafana Oracle Exporter, Alert Log Monitoring",
        "Yes"
    ],
    [
        "Parallel Query Sessions",
        "Real-time Operational",
        "Number of active parallel query slave processes",
        "Excessive parallel queries can saturate CPU and memory resources, degrading performance for all users. Needs monitoring to prevent resource monopolization.",
        "Count of PX (parallel execution) processes from V$PROCESS or V$PX_SESSION. Can quickly consume all CPU cores.",
        "< 50% of PARALLEL_MAX_SERVERS",
        "> 70% of PARALLEL_MAX_SERVERS",
        "> 90% or resource saturation",
        "Medium",
        "OEM, Custom Script",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - SQL PERFORMANCE ===
    [
        "Executions Per Second",
        "Real-time Operational",
        "Number of SQL statements executed per second (transactions per second indicator)",
        "Primary workload indicator. Sudden drops indicate application or database problems affecting users. Spikes may overwhelm system causing performance degradation.",
        "Derived from V$SYSSTAT or V$SYSMETRIC - EXECUTE COUNT statistic. Key performance metric for transaction throughput.",
        "Baseline TPS for application",
        "> 150% baseline or drop > 30%",
        "> 200% baseline or drop > 50%",
        "High",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Parse Count (Hard)",
        "Real-time Operational",
        "Number of hard parses (new SQL statements requiring full parse)",
        "Hard parses are expensive - consume CPU and generate library cache latches. Excessive hard parsing causes performance degradation and scalability issues.",
        "V$SYSSTAT metric 'parse count (hard)'. Each hard parse requires significant CPU. Should use bind variables to minimize.",
        "< 10% of total parses",
        "> 20% of total parses",
        "> 30% or causing CPU saturation",
        "High",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Parse Count (Total)",
        "Real-time Operational",
        "Total number of parse calls (hard + soft parses)",
        "High parse rates indicate SQL not being reused properly. Impacts cursor management and library cache efficiency.",
        "V$SYSSTAT metric 'parse count (total)'. Includes both hard and soft parses. Monitor rate and ratio to executes.",
        "Parse to Execute ratio < 30%",
        "Parse to Execute ratio > 50%",
        "Parse to Execute ratio > 80%",
        "Medium",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "SQL Response Time (Average)",
        "Real-time Operational",
        "Average SQL execution time across all statements",
        "Directly impacts user experience. Slow SQL means slow applications - users wait longer, transactions timeout, productivity drops, revenue decreases.",
        "From V$SQLSTATS or V$SQL (ELAPSED_TIME / EXECUTIONS). Key user experience metric. Should be subsecond for OLTP.",
        "< 100ms for OLTP, varies by app",
        "> 500ms average or increasing trend",
        "> 1000ms average or severe degradation",
        "Critical",
        "OEM, AWR Report, Custom ASH Query",
        "Yes"
    ],
    [
        "Physical Reads Per Second",
        "Real-time Operational",
        "Number of blocks read from disk per second",
        "Physical I/O is 100-1000x slower than memory. High physical reads indicate cache misses causing slow query performance affecting all users.",
        "V$SYSMETRIC 'Physical Reads Per Sec'. Blocks read from disk due to buffer cache misses. Should be minimal compared to logical reads.",
        "< 10% of total reads",
        "> 20% of total reads",
        "> 30% or I/O saturation",
        "High",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Logical Reads Per Second",
        "Real-time Operational",
        "Number of blocks read from memory (buffer cache) per second",
        "Indicates overall query activity volume. Used to calculate buffer cache hit ratio. High logical reads may indicate inefficient SQL.",
        "V$SYSMETRIC 'Logical Reads Per Sec'. Blocks read from SGA buffer cache. Shows workload intensity.",
        "Baseline for application",
        "> 150% of baseline",
        "> 200% with performance issues",
        "Low",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "No"
    ],
    [
        "Sorts (Disk)",
        "Real-time Operational",
        "Number of sort operations requiring disk spills (not fitting in memory)",
        "Disk sorts are very slow - indicate insufficient PGA memory. Causes query slowdowns especially for ORDER BY and GROUP BY operations.",
        "V$SYSSTAT 'sorts (disk)'. Sorts exceeding PGA_AGGREGATE_TARGET memory spilling to temp tablespace. Performance killer.",
        "0 or < 1% of total sorts",
        "> 5% of total sorts",
        "> 10% or consistent disk sorting",
        "High",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Sorts (Memory)",
        "Real-time Operational",
        "Number of sort operations completed entirely in memory",
        "Indicates healthy PGA configuration when high relative to disk sorts. Memory sorts are fast and efficient.",
        "V$SYSSTAT 'sorts (memory)'. Sorts completed in PGA work areas. Should be majority of all sorts.",
        "> 95% of total sorts",
        "< 90% of total sorts",
        "< 80% of total sorts",
        "Low",
        "OEM, Grafana Oracle Exporter",
        "No"
    ],
    [
        "Full Table Scans Per Second",
        "Real-time Operational",
        "Rate of full table scan operations",
        "Full table scans are expensive for large tables. High rate may indicate missing indexes causing slow queries and excessive I/O.",
        "Derived from V$SYSSTAT 'table scans (long tables)'. Can be normal for small tables or DW queries but problematic for OLTP.",
        "Low rate for OLTP systems",
        "> baseline with slow queries",
        "Excessive rate causing I/O saturation",
        "Medium",
        "OEM, AWR Report",
        "Yes"
    ],
    [
        "Index Fast Full Scans",
        "Real-time Operational",
        "Number of index fast full scan operations",
        "Index scans bypassing table access. Can be efficient but monitoring helps identify query patterns and index usage.",
        "V$SYSSTAT metric. Fast full scans read entire index without accessing table. More efficient than table scans.",
        "Expected pattern for workload",
        "Unexpected increase",
        "Causing performance issues",
        "Low",
        "OEM, AWR Report",
        "No"
    ],
    [
        "Redo Size Per Second",
        "Real-time Operational",
        "Amount of redo log data generated per second (bytes)",
        "Indicates write workload intensity. Excessive redo generation can cause log file sync waits and checkpoint stress affecting transaction throughput.",
        "V$SYSMETRIC 'Redo Generated Per Sec'. All changes must be logged. High rate indicates heavy DML or large transactions.",
        "Baseline for application",
        "> 150% of baseline",
        "> 200% or causing log sync waits",
        "Medium",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Transactions Per Second",
        "Real-time Operational",
        "Number of user transactions committed or rolled back per second",
        "Core business metric - transaction volume directly correlates to business activity. Drops indicate application problems or database issues.",
        "V$SYSMETRIC 'User Transaction Per Sec'. Measures actual business transaction throughput.",
        "Baseline TPS for business hours",
        "> 30% deviation from baseline",
        "> 50% deviation or sudden drop",
        "High",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - WAIT EVENTS ===
    [
        "DB Time Per Second",
        "Real-time Operational",
        "Total database time spent working or waiting per second (key performance indicator)",
        "THE primary Oracle performance metric. DB Time > CPU cores indicates performance bottleneck. Users experience slow response times.",
        "Sum of all foreground wait time + CPU time. From V$SYSMETRIC. Should not significantly exceed CPU core count during steady state.",
        "< number of CPU cores",
        "> 1.5x CPU cores",
        "> 2x CPU cores or sustained high",
        "Critical",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Average Active Sessions (AAS)",
        "Real-time Operational",
        "Average number of active sessions over time period",
        "Key capacity metric. AAS > CPU cores means system overloaded. Results in queueing, slow response, and poor user experience.",
        "DB Time / Elapsed Time. From V$SYSMETRIC or ASH. Should stay below CPU core count for good performance.",
        "< 70% of CPU cores",
        "> CPU core count",
        "> 1.5x CPU cores",
        "Critical",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "db file sequential read Wait Time",
        "Real-time Operational",
        "Time spent waiting for single block reads (index lookups, table access by rowid)",
        "Most common I/O wait event. High time indicates slow storage or hot blocks. Causes slow query execution and poor application responsiveness.",
        "Single block reads from datafiles (indexed access). Average wait should be < 10ms. Check storage performance if high.",
        "< 5ms average wait",
        "> 10ms average wait",
        "> 20ms average wait",
        "High",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "db file scattered read Wait Time",
        "Real-time Operational",
        "Time spent waiting for multiblock reads (full table scans, index fast full scans)",
        "Multiblock I/O for scans. High waits indicate slow storage or excessive scanning. Impacts batch jobs and reporting queries.",
        "Multiblock reads from datafiles (full scans). Average wait depends on storage but should be < 20ms.",
        "< 10ms average wait",
        "> 20ms average wait",
        "> 50ms average wait",
        "High",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "log file sync Wait Time",
        "Real-time Operational",
        "Time waiting for commit confirmation (redo write to disk)",
        "COMMIT waits - directly impacts transaction completion time. High waits mean users wait longer for confirmations. Affects user experience and throughput.",
        "Time LGWR takes to write redo to disk and confirm to session. Should be < 10ms. Check redo log placement and I/O if high.",
        "< 5ms average wait",
        "> 10ms average wait",
        "> 20ms average wait",
        "Critical",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "log file parallel write Wait Time",
        "Real-time Operational",
        "Time LGWR spends writing redo to online redo log files",
        "LGWR performance directly affects commit performance. Slow writes cause log file sync waits impacting all committing sessions.",
        "LGWR writing redo buffers to disk. Should be < 5ms. High values indicate I/O bottleneck on redo logs.",
        "< 2ms average wait",
        "> 5ms average wait",
        "> 10ms average wait",
        "Critical",
        "OEM, AWR Report",
        "Yes"
    ],
    [
        "enq: TX - row lock contention Wait Time",
        "Real-time Operational",
        "Time waiting to acquire row locks held by other transactions",
        "Row lock contention - users waiting for other users to release locks. Causes transaction delays and application slowdowns. Business process bottleneck.",
        "Transaction lock waits. Indicates concurrent updates to same rows. May need application logic review or table partitioning.",
        "Minimal wait time",
        "> 100ms per wait or frequent",
        "> 500ms per wait or blocking users",
        "High",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "library cache lock/pin Wait Time",
        "Real-time Operational",
        "Time waiting for library cache locks or pins (shared pool contention)",
        "Shared pool contention - DDL, invalidations, or parsing issues. Can cause widespread application slowdowns when many sessions wait.",
        "Waits for library cache object locks/pins. Often caused by hard parsing, DDL, or invalidations. Can spike during application deployments.",
        "< 1% of DB time",
        "> 5% of DB time",
        "> 10% of DB time or widespread",
        "High",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "latch: cache buffers chains Wait Time",
        "Real-time Operational",
        "Time waiting for buffer cache hash chain latches (hot blocks)",
        "Hot block contention in buffer cache. Multiple sessions competing for same data blocks. Indicates poor application design or index contention.",
        "Latch protecting buffer cache hash chains. High waits indicate hot blocks or poor SQL. May need partitioning or application changes.",
        "< 1% of DB time",
        "> 5% of DB time",
        "> 10% or causing CPU spin",
        "Medium",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "latch: shared pool Wait Time",
        "Real-time Operational",
        "Time waiting for shared pool latches",
        "Shared pool memory allocation contention. Caused by excessive hard parsing, literal SQL, or shared pool fragmentation. Impacts cursor operations.",
        "Latch protecting shared pool memory structures. High waits indicate parsing or memory allocation issues.",
        "< 1% of DB time",
        "> 5% of DB time",
        "> 10% or causing application delays",
        "Medium",
        "OEM, AWR Report, ASH Analysis",
        "Yes"
    ],
    [
        "CPU Wait Time",
        "Real-time Operational",
        "Time sessions spend consuming CPU (not waiting)",
        "High CPU time is good if it means work is being done. But if CPU > 80% sustained, can indicate CPU saturation and need for tuning or scaling.",
        "CPU consumed by foreground sessions. From V$SYSMETRIC or ASH. Should be majority of DB time in healthy system.",
        "> 50% of DB time (CPU bound good)",
        "> 80% system CPU utilization",
        "> 95% CPU or causing queueing",
        "High",
        "OEM, AWR Report, OS Monitoring",
        "Yes"
    ],
    [
        "Total Wait Time (Non-Idle)",
        "Real-time Operational",
        "Sum of all non-idle wait event time",
        "Measures time database spends waiting vs doing work. High wait time relative to DB time indicates bottlenecks degrading performance.",
        "Sum of all wait events excluding idle waits. From V$SYSTEM_EVENT. Should identify top wait events for tuning.",
        "< 50% of DB time",
        "> 70% of DB time",
        "> 80% (more waiting than working)",
        "High",
        "OEM, AWR Report",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - MEMORY (SGA/PGA) ===
    [
        "SGA Size",
        "Real-time Operational",
        "Total System Global Area (SGA) memory allocated",
        "SGA is Oracle's shared memory. Size impacts cache efficiency and performance. Too small = excessive I/O and slow queries. Too large = OS swapping.",
        "V$SGA or SHOW PARAMETER sga_target. Contains buffer cache, shared pool, redo buffers, large pool, java pool, streams pool.",
        "60-70% of available RAM (dedicated)",
        "< 40% or > 90% of available RAM",
        "Causing OS memory pressure/swapping",
        "High",
        "OEM, Grafana Oracle Exporter, OS Monitoring",
        "No"
    ],
    [
        "Buffer Cache Hit Ratio",
        "Real-time Operational",
        "Percentage of data blocks found in memory vs read from disk",
        "KEY performance metric. Low hit ratio means excessive physical I/O - slow queries, poor performance, frustrated users, lost productivity.",
        "Calculated: 1 - (physical reads / logical reads). From V$SYSSTAT. Should be > 95% for OLTP. Low ratio = increase buffer cache.",
        "> 95% for OLTP, > 90% for DW",
        "< 90% for OLTP",
        "< 85% or causing performance issues",
        "Critical",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Buffer Cache Size",
        "Real-time Operational",
        "Size of database buffer cache in SGA",
        "Most important SGA component. Caches data blocks. Insufficient size causes excessive physical I/O destroying performance.",
        "V$SGASTAT 'buffer_cache' or DB_CACHE_SIZE parameter. Should be majority of SGA. Needs to fit working set of data.",
        "Based on working set size",
        "Hit ratio < 90%",
        "Hit ratio < 85% with high phys reads",
        "High",
        "OEM, Grafana Oracle Exporter",
        "Yes"
    ],
    [
        "Shared Pool Size",
        "Real-time Operational",
        "Size of shared pool (SQL cursors, stored procedures, dictionary cache)",
        "Holds parsed SQL cursors. Too small causes cursor aging, hard parses, and library cache thrashing. Performance and scalability impact.",
        "V$SGASTAT 'shared pool' or SHARED_POOL_SIZE. Contains library cache and dictionary cache. Must fit frequently executed SQL.",
        "Based on SQL volume and complexity",
        "High library cache misses",
        "ORA-04031 (unable to allocate memory)",
        "High",
        "OEM, Grafana Oracle Exporter",
        "Yes"
    ],
    [
        "Library Cache Hit Ratio",
        "Real-time Operational",
        "Percentage of SQL cursors found in library cache (not requiring parse)",
        "Low hit ratio means excessive parsing - CPU overhead and performance degradation. Should reuse cursors via bind variables.",
        "Calculated from V$LIBRARYCACHE (GETHITS / (GETS + PINS)). Should be > 95%. Low ratio = hard parsing or no bind variables.",
        "> 95%",
        "< 90%",
        "< 85% with high parse rates",
        "High",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Dictionary Cache Hit Ratio",
        "Real-time Operational",
        "Percentage of data dictionary info found in cache",
        "Data dictionary access required for parsing. Low hit ratio causes extra I/O and parse delays. Indicates insufficient shared pool.",
        "From V$ROWCACHE. Should be > 95%. Low ratio increases parse time and library cache operations.",
        "> 95%",
        "< 90%",
        "< 85% or causing parse delays",
        "Medium",
        "OEM, AWR Report",
        "Yes"
    ],
    [
        "PGA Aggregate Target",
        "Real-time Operational",
        "Target size for total Program Global Area memory across all sessions",
        "Controls work area memory for sorts, hash joins, bitmap operations. Insufficient causes disk spills - major performance killer.",
        "SHOW PARAMETER pga_aggregate_target. Oracle automatically allocates to sessions. Too small = disk sorts and poor performance.",
        "20-30% of available RAM",
        "Frequent disk sorts occurring",
        "Excessive disk sorts degrading perf",
        "High",
        "OEM, Grafana Oracle Exporter",
        "Yes"
    ],
    [
        "PGA Aggregate Memory Usage",
        "Real-time Operational",
        "Current total PGA memory used by all sessions",
        "Actual PGA consumption. Exceeding target causes memory allocation issues. If approaching OS limits can cause swapping or OOM.",
        "V$PGASTAT 'total PGA allocated'. Monitor vs PGA_AGGREGATE_TARGET and available memory.",
        "< 90% of PGA target",
        "> 100% of PGA target",
        "> 120% or causing memory pressure",
        "High",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "PGA Cache Hit Ratio",
        "Real-time Operational",
        "Percentage of PGA work operations completed in memory (not spilling to disk)",
        "Measures PGA efficiency. Low ratio means operations spilling to temp tablespace - very slow. Should be > 95%.",
        "From V$PGASTAT - bytes processed vs bytes in temp. High ratio means adequate PGA for workload.",
        "> 95%",
        "< 90%",
        "< 80% with frequent disk sorts",
        "High",
        "OEM, AWR Report",
        "Yes"
    ],
    [
        "Shared Pool Free Memory",
        "Real-time Operational",
        "Amount of free memory available in shared pool",
        "Low free memory indicates fragmentation or insufficient sizing. Can lead to ORA-04031 errors preventing new SQL from loading.",
        "Query V$SGASTAT for 'free memory' in shared pool. Should maintain reasonable free space for new SQL and objects.",
        "> 10% of shared pool",
        "< 5% of shared pool",
        "< 2% or ORA-04031 errors",
        "Medium",
        "OEM, Custom Query",
        "Yes"
    ],
    [
        "Result Cache Memory Usage",
        "Real-time Operational",
        "Percentage of result cache in use",
        "Result cache stores query results for reuse. Useful for frequently accessed data. Monitor for efficiency.",
        "V$RESULT_CACHE_STATISTICS. Can significantly improve performance for repeated queries. Memory usage should be reasonable.",
        "< 80% if enabled",
        "> 90% if enabled",
        "N/A (optional feature)",
        "Low",
        "OEM, Custom Query",
        "No"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - TABLESPACE & STORAGE ===
    [
        "Tablespace Usage %",
        "Real-time Operational",
        "Percentage of tablespace capacity used",
        "CRITICAL - tablespace full causes ORA-01653 errors. Applications cannot insert/update data. Complete service outage until space added.",
        "Query DBA_DATA_FILES and DBA_FREE_SPACE. Each tablespace must be monitored. Full tablespace = immediate outage.",
        "< 85% used",
        "> 90% used",
        "> 95% or ORA-01653 errors",
        "Critical",
        "OEM, Grafana Oracle Exporter, Custom Script",
        "Yes"
    ],
    [
        "TEMP Tablespace Usage %",
        "Real-time Operational",
        "Percentage of temporary tablespace in use",
        "Temp tablespace full causes ORA-01652 errors. Sorts and hash operations fail. Queries abort causing application failures.",
        "Query V$TEMP_SPACE_HEADER and V$TEMPSEG_USAGE. Used for sorts, hash joins, temp tables. Full = query failures.",
        "< 80% used",
        "> 85% used",
        "> 95% or ORA-01652 errors",
        "Critical",
        "OEM, Grafana Oracle Exporter, Custom Script",
        "Yes"
    ],
    [
        "UNDO Tablespace Usage %",
        "Real-time Operational",
        "Percentage of undo tablespace capacity used",
        "Undo space full causes transaction failures and ORA-30036. Cannot rollback or support read consistency. Critical database failure.",
        "Query DBA_DATA_FILES for UNDO tablespace. Undo stores rollback info. Insufficient undo = transaction errors and snapshot too old.",
        "< 85% used",
        "> 90% used",
        "> 95% or ORA-30036/ORA-01555",
        "Critical",
        "OEM, Grafana Oracle Exporter, Custom Script",
        "Yes"
    ],
    [
        "SYSAUX Tablespace Usage %",
        "Real-time Operational",
        "Percentage of SYSAUX (auxiliary system) tablespace used",
        "SYSAUX holds AWR, ASH, AUM, and other important repository data. Full SYSAUX disables monitoring and causes operational issues.",
        "SYSAUX is critical for database operations. Contains AWR snapshots, audit trails, stats. Full = monitoring failure.",
        "< 85% used",
        "> 90% used",
        "> 95% used",
        "High",
        "OEM, Grafana Oracle Exporter, Custom Script",
        "Yes"
    ],
    [
        "Datafile I/O Wait Time",
        "Real-time Operational",
        "Average I/O wait time per datafile",
        "Identifies slow datafiles or hot files. High wait times indicate storage performance issues affecting specific tablespaces.",
        "From V$FILESTAT or ASH. Helps identify I/O bottlenecks at file level. May indicate need to redistribute I/O.",
        "< 10ms average per file",
        "> 20ms for hot files",
        "> 50ms or causing slowdowns",
        "Medium",
        "OEM, AWR Report, Custom Script",
        "Yes"
    ],
    [
        "ASM Diskgroup Free Space %",
        "Real-time Operational",
        "Percentage of free space in ASM disk groups",
        "ASM manages Oracle storage. Running out of diskgroup space is catastrophic - database cannot write and crashes. Immediate outage.",
        "Query V$ASM_DISKGROUP. Each diskgroup must be monitored. Must maintain free space for redundancy and growth.",
        "< 85% used",
        "> 90% used",
        "> 95% or nearing capacity",
        "Critical",
        "OEM, Grafana ASM Exporter, Custom Script",
        "Yes"
    ],
    [
        "ASM Disk Failures",
        "Real-time Operational",
        "Number of failed or offline disks in ASM disk groups",
        "Disk failures reduce redundancy. Multiple failures in same diskgroup causes data loss. IMMEDIATE action required to restore redundancy.",
        "V$ASM_DISK status. Healthy disks should show NORMAL. OFFLINE or dismounted disks need immediate attention.",
        "0 offline disks",
        "> 0 offline disks",
        "Multiple failures or data at risk",
        "Critical",
        "OEM, Alert Log, Custom Script",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - REDO & ARCHIVE LOGS ===
    [
        "Redo Log Switches Per Hour",
        "Real-time Operational",
        "Number of times database switches between online redo log groups per hour",
        "Frequent log switches indicate undersized redo logs or heavy write load. Can cause checkpoint stress and performance impact.",
        "Query V$LOG_HISTORY. Frequent switches (> 15/hour) cause extra checkpoint activity. May need larger redo logs.",
        "< 15 per hour",
        "> 20 per hour",
        "> 30 per hour or checkpoint pressure",
        "Medium",
        "OEM, Grafana Oracle Exporter, AWR Report",
        "Yes"
    ],
    [
        "Archive Log Generation Rate (GB/hour)",
        "Real-time Operational",
        "Amount of archive log data generated per hour",
        "High archive rate impacts backup strategy, storage capacity, and Data Guard lag. Affects disaster recovery capabilities and storage costs.",
        "Calculate from V$ARCHIVED_LOG size over time. Heavy DML, bulk loads, or large transactions increase archive generation.",
        "Baseline for application",
        "> 150% of baseline",
        "> 200% or storage issues",
        "High",
        "OEM, Custom Script",
        "Yes"
    ],
    [
        "Archive Log Gap (Data Guard)",
        "Real-time Operational",
        "Number of archive logs primary ahead of standby",
        "Archive gap means standby is behind. Delays disaster recovery capability. Large gaps indicate network or standby performance issues.",
        "Query V$ARCHIVE_GAP on standby. Gap means standby cannot failover cleanly. Monitor carefully for DR readiness.",
        "0 gap (fully synchronized)",
        "> 5 archive logs behind",
        "> 20 logs or hours of lag",
        "Critical",
        "OEM, Data Guard Broker, Custom Script",
        "Yes"
    ],
    [
        "Standby Apply Lag (Data Guard)",
        "Real-time Operational",
        "Time lag between primary and standby database (seconds or minutes)",
        "Standby lag affects RTO and RPO. High lag means more data at risk and longer failover time. Critical for disaster recovery SLAs.",
        "V$DATAGUARD_STATS 'apply lag'. Measures how current standby is. Impacts RPO (Recovery Point Objective) during disaster.",
        "< 60 seconds",
        "> 5 minutes",
        "> 30 minutes or impacting RTO/RPO",
        "Critical",
        "OEM, Data Guard Broker, Custom Script",
        "Yes"
    ],
    [
        "Standby Transport Lag (Data Guard)",
        "Real-time Operational",
        "Lag in shipping redo from primary to standby",
        "Transport lag indicates network issues or standby connectivity problems. Affects overall Data Guard replication health.",
        "V$DATAGUARD_STATS 'transport lag'. Network or configuration issues cause transport delays.",
        "< 30 seconds",
        "> 2 minutes",
        "> 10 minutes or network issues",
        "High",
        "OEM, Data Guard Broker",
        "Yes"
    ],
    [
        "Redo Log Space Requests",
        "Real-time Operational",
        "Number of times session waited because redo log space was unavailable",
        "Redo log space waits indicate log switches happening faster than LGWR can write/archive. Causes transaction delays. Need larger logs or faster I/O.",
        "V$SYSSTAT 'redo log space requests'. Should be zero. Non-zero indicates redo logs too small or archival bottleneck.",
        "0",
        "> 0 (any occurrence)",
        "Frequent occurrences causing delays",
        "High",
        "OEM, AWR Report",
        "Yes"
    ],
    [
        "Checkpoint Not Complete Count",
        "Real-time Operational",
        "Occurrences of 'checkpoint not complete' messages in alert log",
        "Indicates redo logs switching before previous checkpoint completes. Causes waits and performance issues. Need larger redo logs.",
        "Alert log message 'checkpoint not complete'. Means DBWR cannot keep up with redo generation. Performance bottleneck.",
        "0 occurrences",
        "> 0 per day",
        "Frequent or causing performance impact",
        "High",
        "Alert Log Monitoring, OEM",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - BACKUP & RECOVERY ===
    [
        "Last Successful Backup Age",
        "Real-time Operational",
        "Time since last successful full or incremental backup",
        "Outdated backups = longer recovery time and potential data loss. Backup failures leave database unprotected. Business continuity risk.",
        "Query RMAN RC_BACKUP_SET or V$RMAN_BACKUP_JOB_DETAILS. Backup must succeed within RPO requirements.",
        "< 24 hours (or RPO requirement)",
        "> 24 hours or missed backup window",
        "> 48 hours or no recent backup",
        "Critical",
        "RMAN Reports, OEM, Backup Tool Logs",
        "Yes"
    ],
    [
        "Backup Success Rate",
        "Real-time Operational",
        "Percentage of backup jobs completing successfully",
        "Failed backups leave database vulnerable. Must maintain high success rate to meet RPO/RTO. Failures require immediate investigation.",
        "Calculate from V$RMAN_BACKUP_JOB_DETAILS (COMPLETED / TOTAL). Should be 100% or investigate failures immediately.",
        "100% success",
        "< 100% (any failures)",
        "Consecutive failures or critical backup failing",
        "Critical",
        "RMAN Reports, OEM, Backup Tool",
        "Yes"
    ],
    [
        "Backup Performance (GB/hour)",
        "Real-time Operational",
        "Backup throughput rate",
        "Slow backups may not complete within backup window. Affects RPO and system performance during backup. May need tuning or infrastructure upgrade.",
        "Calculate from V$RMAN_BACKUP_JOB_DETAILS (bytes / elapsed time). Should complete within maintenance window.",
        "Completes within backup window",
        "Approaching window limit",
        "Exceeding backup window",
        "Medium",
        "RMAN Reports, OEM",
        "Yes"
    ],
    [
        "RMAN Error Count",
        "Real-time Operational",
        "Number of RMAN errors in recent backup operations",
        "RMAN errors indicate backup problems - configuration issues, storage problems, or corruption. Must resolve to ensure recoverability.",
        "Parse RMAN logs or query RC_RMAN_OUTPUT. Even warnings should be investigated to prevent backup failures.",
        "0 errors",
        "> 0 warnings",
        "> 0 errors or backup failures",
        "High",
        "RMAN Logs, OEM",
        "Yes"
    ],
    [
        "Flashback Database Status",
        "Real-time Operational",
        "Whether Flashback Database is enabled and functioning",
        "Flashback enables fast database rewind to past point-in-time. If disabled or space issues, lose quick recovery capability.",
        "Query V$DATABASE.FLASHBACK_ON. Fast recovery area must have space. Critical for rapid recovery from logical errors.",
        "ON with adequate FRA space",
        "OFF when required by policy",
        "ON but FRA space issues",
        "Medium",
        "OEM, Custom Query",
        "Yes"
    ],
    [
        "Fast Recovery Area Usage %",
        "Real-time Operational",
        "Percentage of Fast Recovery Area (FRA) space used",
        "FRA holds backups, archive logs, flashback logs. Full FRA stops archive logs causing database hang. CRITICAL space management.",
        "V$RECOVERY_FILE_DEST for usage. Must maintain space for backups and archive logs or database hangs with ORA-19815.",
        "< 85% used",
        "> 90% used",
        "> 95% or ORA-19815 (FRA full)",
        "Critical",
        "OEM, Grafana Oracle Exporter, Custom Script",
        "Yes"
    ],
    
    # === REAL-TIME OPERATIONAL METRICS - RAC SPECIFIC ===
    [
        "RAC Global Cache Block Transfer Time",
        "Real-time Operational",
        "Average time to transfer data blocks between RAC instances (cache fusion)",
        "RAC-specific. Slow interconnect causes cache fusion delays impacting all queries requiring cross-instance blocks. Scalability bottleneck.",
        "From GV$SYSSTAT 'gc cr/current block receive time'. Should be < 3ms. High values indicate interconnect or network issues.",
        "< 3ms average",
        "> 5ms average",
        "> 10ms or widespread impact",
        "High",
        "OEM, RAC-specific Scripts",
        "Yes"
    ],
    [
        "RAC Global Cache Block Loss Ratio",
        "Real-time Operational",
        "Percentage of cache fusion operations requiring retry due to lost blocks",
        "Block losses indicate interconnect problems in RAC. Causes performance degradation and potential cluster instability.",
        "GV$SYSSTAT metrics - block lost / blocks received. Should be near 0%. High ratio indicates serious network issues.",
        "< 0.1%",
        "> 1%",
        "> 5% or cluster instability",
        "Critical",
        "OEM, RAC-specific Scripts",
        "Yes"
    ],
    [
        "RAC Instance Membership",
        "Real-time Operational",
        "Number of RAC instances currently running and part of cluster",
        "Missing RAC instances reduce capacity and redundancy. Can indicate node failure or configuration issues affecting availability.",
        "Query GV$INSTANCE or Clusterware (crsctl status resource). All expected instances should be OPEN.",
        "All expected instances OPEN",
        "1 instance down (reduced capacity)",
        "> 1 instance down or quorum risk",
        "Critical",
        "OEM, Grid Infrastructure, Custom Script",
        "Yes"
    ],
    [
        "RAC GES/GCS Deadlock Rate",
        "Real-time Operational",
        "Global Enqueue Service / Global Cache Service deadlock occurrences",
        "RAC-specific deadlocks. Multiple instances competing for resources. Causes transaction rollbacks and application errors.",
        "Monitor alert logs for 'global enqueue deadlock' messages. Indicates cross-instance contention issues.",
        "0 deadlocks",
        "> 1 per hour",
        "Frequent deadlocks causing failures",
        "High",
        "Alert Log Analysis, OEM",
        "Yes"
    ],
    
    # === CAPACITY PLANNING & TREND ANALYSIS ===
    [
        "Database Size Growth Rate",
        "Capacity Planning",
        "Rate of database storage growth (GB per week/month)",
        "Predicts when storage capacity exhausted. Essential for budgeting and preventing storage-related outages. Plan infrastructure expansion.",
        "Query DBA_DATA_FILES size over time. Calculate growth trend. Impacts storage procurement, backup infrastructure, and costs.",
        "Predictable and budgeted",
        "Exceeding planned growth rate",
        "Exponential or runaway growth",
        "High",
        "OEM (calculated), Custom Trend Analysis",
        "Yes"
    ],
    [
        "Tablespace Growth Trends",
        "Capacity Planning",
        "Growth rate of largest/fastest-growing tablespaces",
        "Identifies tablespaces needing attention. Helps plan archiving, partitioning, or scaling before performance degrades or space runs out.",
        "Track individual tablespace sizes from DBA_DATA_FILES. Focus on top 5-10 largest tablespaces.",
        "Expected growth pattern",
        "> 50% growth month-over-month",
        "> 100% MoM or approaching limits",
        "High",
        "Custom Script, OEM Trending",
        "Yes"
    ],
    [
        "Archive Log Accumulation Rate",
        "Capacity Planning",
        "Rate of archive log generation and accumulation",
        "Affects backup storage capacity, archive dest space, and Data Guard requirements. Plan infrastructure and retention policies.",
        "Monitor archive log destination usage over time. Must balance retention requirements with storage costs.",
        "Within retention policy and capacity",
        "Approaching archive dest capacity",
        "Archive dest full or purge failing",
        "High",
        "Custom Script, OEM",
        "Yes"
    ],
    [
        "Session Count Trend",
        "Capacity Planning",
        "Trend of peak concurrent sessions over time",
        "Forecasts when hitting SESSIONS/PROCESSES limits. Helps plan for user growth and prevents connection exhaustion.",
        "Track max sessions from V$LICENSE daily/weekly. Identify growth trends to plan parameter increases.",
        "Steady and predictable",
        "Growing > 20% monthly",
        "Growing > 50% monthly",
        "High",
        "OEM Trending, Custom Analysis",
        "Yes"
    ],
    [
        "SQL Execution Volume Trend",
        "Capacity Planning",
        "Trend of executions per second over weeks/months",
        "Transaction volume growth requires capacity planning for CPU, memory, I/O. Prevents performance degradation during business growth.",
        "Track V$SYSMETRIC 'Executions Per Sec' over time. Growing workload needs infrastructure scaling.",
        "Matches expected business growth",
        "Growing faster than capacity plans",
        "Approaching known system limits",
        "High",
        "OEM Trending, AWR Comparison",
        "Yes"
    ],
    [
        "Average SQL Response Time Trend",
        "Capacity Planning",
        "Long-term trend of average SQL execution time",
        "Gradually increasing response times signal growing pains. Need optimization or scaling before user experience suffers significantly.",
        "Track from AWR reports over time. Degrading performance indicates need for tuning or hardware upgrade.",
        "Stable or improving",
        "Increasing > 25% per month",
        "Increasing > 50% or rapid degradation",
        "High",
        "AWR Comparison, OEM Trending",
        "Yes"
    ],
    [
        "Memory Usage Growth Trend",
        "Capacity Planning",
        "Trend of SGA/PGA memory consumption",
        "Growing memory needs may require more RAM or MEMORY_TARGET adjustment. Prevents swapping and OOM situations.",
        "Monitor SGA + PGA usage from V$SGA and V$PGASTAT over time. Must stay within available physical RAM.",
        "Stable within available RAM",
        "Approaching 90% of available RAM",
        "> 95% or causing memory pressure",
        "High",
        "OEM Trending, OS Monitoring",
        "Yes"
    ],
    [
        "CPU Utilization Trend",
        "Capacity Planning",
        "Trend of database server CPU usage",
        "Growing CPU consumption forecasts need for more cores or optimization. High CPU causes queuing and poor response times.",
        "Track OS CPU usage over time. Oracle process should not saturate CPU consistently without headroom.",
        "< 70% average utilization",
        "> 80% average or peaks at 100%",
        "Sustained > 90% or constant saturation",
        "High",
        "OS Monitoring, OEM, AWR Reports",
        "Yes"
    ],
    [
        "I/O Throughput Trend (IOPS & MB/s)",
        "Capacity Planning",
        "Trend of storage I/O operations and bandwidth",
        "I/O growth indicates need for faster storage or read replica offloading. Prevents I/O becoming performance bottleneck.",
        "Monitor OS-level iostat metrics and Oracle I/O stats from V$SYSSTAT. Growing I/O may need storage upgrade.",
        "Within storage system capacity",
        "> 70% of storage IOPS/bandwidth",
        "> 85% or I/O saturation occurring",
        "High",
        "OS Monitoring, Storage Arrays, OEM",
        "Yes"
    ],
    [
        "Backup Duration Trend",
        "Capacity Planning",
        "Trend of how long backups take over time",
        "Longer backups impact backup windows and RTO. May need strategy changes (incremental, parallel, compression, infrastructure upgrade).",
        "Track RMAN backup job duration from V$RMAN_BACKUP_JOB_DETAILS. Growing duration threatens backup window compliance.",
        "Within acceptable window",
        "Approaching backup window limit",
        "Exceeding backup window consistently",
        "Medium",
        "RMAN Reports, OEM Trending",
        "Yes"
    ],
    [
        "Backup Storage Growth",
        "Capacity Planning",
        "Rate of backup storage consumption increase",
        "Affects backup storage costs and capacity planning. Retention policies must balance business needs with infrastructure costs.",
        "Track backup storage usage over time. Includes full, incremental, and archive log backups.",
        "Matches database growth + retention",
        "Growing faster than expected",
        "Backup storage approaching capacity",
        "Medium",
        "Backup Tool Reports, Storage Monitoring",
        "Yes"
    ],
    [
        "Undo Retention Requirement Trend",
        "Capacity Planning",
        "Trend of undo retention needed (influenced by longest query)",
        "Growing undo retention needs indicate longer queries. May need undo tablespace expansion to prevent ORA-01555 errors.",
        "Track longest query duration and TUNED_UNDORETENTION from V$UNDOSTAT. Growing retention needs more undo space.",
        "Stable undo retention requirements",
        "Growing undo retention needs",
        "Frequent ORA-01555 errors",
        "Medium",
        "OEM, Custom Undo Analysis",
        "Yes"
    ],
    [
        "Temp Tablespace Usage Trend",
        "Capacity Planning",
        "Trend of maximum temp tablespace utilization",
        "Growing temp usage indicates more complex queries or larger sorts. Plan temp space growth to prevent ORA-01652 errors.",
        "Track maximum temp usage from V$TEMPSEG_USAGE over time. Helps size temp appropriately.",
        "Stable with adequate free space",
        "Peak usage > 80% regularly",
        "Frequent temp space exhaustion",
        "Medium",
        "OEM, Custom Script",
        "Yes"
    ],
    [
        "Number of Objects Growth",
        "Capacity Planning",
        "Trend in total number of database objects (tables, indexes, partitions)",
        "Excessive object count impacts dictionary performance and operations. May need purging or archival strategy.",
        "Count from DBA_OBJECTS over time. Very large object counts (>1M) can cause metadata performance issues.",
        "< 100K objects preferred",
        "> 500K objects",
        "> 1M objects or metadata issues",
        "Low",
        "Custom Query",
        "No"
    ],
    [
        "AWR Retention and Growth",
        "Capacity Planning",
        "AWR snapshot retention period and SYSAUX space consumption",
        "AWR snapshots consume SYSAUX space. Balance retention (for historical analysis) with space management.",
        "Monitor SYSAUX space and AWR retention settings. Typical retention 7-31 days. Adjust based on needs.",
        "7-31 days retention, space managed",
        "SYSAUX growing too fast",
        "SYSAUX space issues or purge failing",
        "Low",
        "Custom Query, OEM",
        "No"
    ],
    
    # === SECURITY & COMPLIANCE ===
    [
        "Failed Login Attempts",
        "Security & Compliance",
        "Number of failed authentication attempts",
        "Spike indicates brute force attacks or credential stuffing. Security breach risk. Must detect and block attacks to prevent unauthorized access.",
        "Query DBA_AUDIT_SESSION or unified audit trail. Pattern analysis identifies attack sources. May need IP blocking or account locking.",
        "< 10 per hour (occasional typos)",
        "> 50 per hour",
        "> 200 per hour or coordinated attack",
        "Critical",
        "Audit Trail Analysis, OEM, Custom Script",
        "Yes"
    ],
    [
        "Failed Login from Unusual Locations",
        "Security & Compliance",
        "Failed authentication attempts from unexpected IP addresses or countries",
        "External attack indicator. Unknown sources attempting access suggest reconnaissance or breach attempt. Immediate investigation required.",
        "Correlate failed logins with expected source IPs via audit trail. GeoIP analysis identifies suspicious locations.",
        "0 from unexpected sources",
        "> 0 from unknown locations",
        "Sustained attempts or high-risk countries",
        "Critical",
        "Audit Trail + GeoIP Analysis, SIEM",
        "Yes"
    ],
    [
        "Privileged User Activity",
        "Security & Compliance",
        "DBA and system privileged account activity and operations",
        "All privileged operations must be tracked for compliance and security. Unauthorized admin activity = potential insider threat or compromise.",
        "Audit all SYS, SYSTEM, and DBA role activities. Track DDL, grants, configuration changes. Required for SOX, PCI DSS, HIPAA compliance.",
        "Only authorized admin activities",
        "Unexpected privileged operations",
        "Unauthorized admin activity",
        "Critical",
        "Unified Audit, Database Vault, OEM",
        "Yes"
    ],
    [
        "GRANT/REVOKE Operations",
        "Security & Compliance",
        "Changes to user privileges and roles",
        "Privilege changes must be tracked. Unauthorized grants = potential breach or privilege escalation. Compliance requires audit trail of all permission changes.",
        "Audit all GRANT and REVOKE statements. Track via unified audit or traditional audit. Compare to approved change requests.",
        "Only authorized changes",
        "Unexpected privilege modifications",
        "Unauthorized privilege grants",
        "Critical",
        "Unified Audit, Custom Audit Analysis",
        "Yes"
    ],
    [
        "User Account Changes",
        "Security & Compliance",
        "CREATE USER, DROP USER, ALTER USER operations",
        "Account lifecycle changes must be audited. Unauthorized account creation = potential backdoor access. Required for compliance audits.",
        "Audit all user management DDL. Track password changes, account locks, profile changes. Correlate with HR system.",
        "Only authorized account changes",
        "Unexpected account modifications",
        "Unauthorized account creation",
        "Critical",
        "Unified Audit, Custom Script",
        "Yes"
    ],
    [
        "Schema Object DDL Operations",
        "Security & Compliance",
        "CREATE, ALTER, DROP operations on database objects",
        "Schema changes must follow change management process. Unauthorized DDL = potential sabotage, data loss, or compliance violation.",
        "Audit all DDL operations. Track table drops, column adds, index changes. Should match approved change tickets.",
        "Only during maintenance windows",
        "Unexpected DDL in production hours",
        "Unauthorized schema changes",
        "Critical",
        "Unified Audit, Flashback Query for tracking",
        "Yes"
    ],
    [
        "Direct SYS Logins",
        "Security & Compliance",
        "Direct connections as SYS user",
        "SYS should rarely login directly (except maintenance). Direct SYS access bypasses audit controls. Security best practice violation.",
        "Audit SYS connections. Should use named admin accounts for accountability. SYS connections may indicate emergency or threat.",
        "0 direct SYS logins (use named admins)",
        "Direct SYS logins occurring",
        "Unexpected SYS access",
        "High",
        "Unified Audit, Connection Logging",
        "Yes"
    ],
    [
        "Profile Violation Attempts",
        "Security & Compliance",
        "Password policy violations or account lockouts",
        "Profile violations indicate policy enforcement working. High rate may indicate attacks or user training issues.",
        "Track failed_login_attempts reaching limits, password_life_time violations. Indicates security policy effectiveness.",
        "Occasional (< 5/day)",
        "> 20 per day",
        "> 100 or indicating attack pattern",
        "Medium",
        "DBA_USERS, Audit Trail",
        "Yes"
    ],
    [
        "Accounts with Default Passwords",
        "Security & Compliance",
        "User accounts still using default or weak passwords",
        "Default passwords = easy breach. Critical security vulnerability. Must change immediately. Common compliance failure.",
        "Query DBA_USERS for default password status. Use password verification function. All defaults must be changed.",
        "0 accounts with default passwords",
        "> 0 default passwords detected",
        "Privileged accounts with defaults",
        "Critical",
        "Custom Security Audit Script, OEM",
        "Yes"
    ],
    [
        "Accounts with Non-Expiring Passwords",
        "Security & Compliance",
        "User accounts without password expiration policy",
        "Password rotation required by compliance. Non-expiring passwords violate security policies (PCI DSS, HIPAA, SOX).",
        "Query DBA_USERS for PASSWORD_LIFE_TIME = UNLIMITED. Apply appropriate profiles with expiration.",
        "0 (or only service accounts with justification)",
        "User accounts without expiration",
        "Multiple accounts non-compliant",
        "High",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "Unused/Dormant User Accounts",
        "Security & Compliance",
        "Accounts not used for extended period (90+ days)",
        "Dormant accounts = security risk. Forgotten accounts may not be monitored. Should disable or remove inactive accounts.",
        "Query DBA_USERS.LAST_LOGIN (12c+) or track from audit. Inactive accounts should be locked or dropped.",
        "All accounts active or locked",
        "> 10 dormant accounts",
        "> 50 or privileged accounts dormant",
        "Medium",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "Database Vault Status",
        "Security & Compliance",
        "Whether Database Vault is enabled and protecting sensitive data",
        "Database Vault prevents privileged user access to data. Compliance requirement for sensitive data. Should be enabled and functioning.",
        "Query DVSYS.DBA_DV_STATUS. Vault provides separation of duties and protects against insider threats.",
        "Enabled and protecting realms",
        "Not enabled but required",
        "Disabled or violations occurring",
        "High",
        "Database Vault Reports, OEM",
        "Yes"
    ],
    [
        "Transparent Data Encryption (TDE) Status",
        "Security & Compliance",
        "Percentage of tablespaces/tables using TDE encryption",
        "Data-at-rest encryption required for compliance (PCI DSS, HIPAA, GDPR). Unencrypted sensitive data = major compliance violation.",
        "Query V$ENCRYPTED_TABLESPACES and DBA_ENCRYPTED_COLUMNS. Should be 100% for sensitive data tablespaces.",
        "100% for sensitive data",
        "< 100% coverage",
        "Sensitive data unencrypted",
        "Critical",
        "Custom Query, OEM Security Assessment",
        "Yes"
    ],
    [
        "Network Encryption Usage",
        "Security & Compliance",
        "Percentage of connections using SQL*Net encryption or TLS",
        "Unencrypted connections expose data in transit. Compliance requires encryption (PCI DSS, HIPAA, GDPR). All production should use encryption.",
        "Check SQLNET.ENCRYPTION_SERVER setting and V$SESSION_CONNECT_INFO. All connections should show encrypted status.",
        "100% encrypted connections",
        "< 100% (some unencrypted)",
        "< 80% or sensitive data unencrypted",
        "High",
        "Custom Query, Network Monitoring",
        "Yes"
    ],
    [
        "Audit Trail Size and Growth",
        "Security & Compliance",
        "Size and growth rate of audit trail (unified or traditional)",
        "Audit logs required for compliance. Must ensure adequate storage and retention. Missing logs = audit failure and compliance violation.",
        "Monitor AUDSYS.AUD$ or unified audit trail size. Must retain per compliance requirements (often 1-7 years).",
        "Within retention policy and capacity",
        "Approaching storage limits",
        "Audit trail not being retained properly",
        "High",
        "Custom Script, SYSAUX Monitoring",
        "Yes"
    ],
    [
        "Unified Audit Status",
        "Security & Compliance",
        "Whether Unified Auditing is enabled (recommended 12c+)",
        "Unified Audit is Oracle's modern audit framework - better performance and features. Should migrate from traditional audit.",
        "Query UNIFIED_AUDIT_TRAIL vs AUD$ usage. 12c+ should use unified auditing for better compliance and performance.",
        "Unified auditing enabled",
        "Still using traditional audit",
        "No auditing or inadequate policies",
        "Medium",
        "Custom Query, OEM",
        "Yes"
    ],
    [
        "Fine-Grained Audit Policy Coverage",
        "Security & Compliance",
        "Percentage of sensitive tables covered by FGA policies",
        "Fine-Grained Audit tracks access to sensitive columns. Required for compliance with sensitive data regulations. Must cover all critical data.",
        "Query DBA_AUDIT_POLICIES. Should audit SELECT on sensitive columns (SSN, credit cards, PHI, PII).",
        "100% of sensitive data covered",
        "< 100% coverage",
        "Sensitive data not audited",
        "High",
        "Custom Audit Policy Review",
        "Yes"
    ],
    [
        "SQL Injection Pattern Detection",
        "Security & Compliance",
        "SQL statements with potential injection patterns",
        "SQL injection = major application vulnerability. Detection helps identify attacks or vulnerable code requiring remediation.",
        "Analyze V$SQL for injection patterns (UNION, comment injection, OR 1=1, etc.). Requires pattern matching or ML.",
        "0 injection patterns detected",
        "Potential injection attempts",
        "Confirmed injection attempts",
        "Critical",
        "Custom SQL Analysis, SIEM Integration",
        "Yes"
    ],
    [
        "Data Masking Policy Coverage",
        "Security & Compliance",
        "Percentage of sensitive columns with masking policies",
        "Data masking protects sensitive data in non-production. Required for compliance when using production copies. Prevents data exposure.",
        "Query DBMS_REDACT policies or Data Masking and Subsetting configurations. Must cover all PII/PHI in non-prod.",
        "100% sensitive data masked in non-prod",
        "< 100% coverage",
        "Production data exposed in dev/test",
        "High",
        "Custom Policy Review, Data Masking Reports",
        "Yes"
    ],
    [
        "Sensitive Data Access Anomalies",
        "Security & Compliance",
        "Unusual access patterns to sensitive data (volume, timing, users)",
        "Anomalies may indicate data exfiltration or insider threat. Requires baseline analysis to detect deviations requiring investigation.",
        "Analyze unified audit trail for sensitive table access. Compare to baseline patterns. ML/AI can help detect anomalies.",
        "Normal pattern baseline",
        "Moderate deviation from baseline",
        "Significant anomaly or bulk export",
        "High",
        "Audit Trail Analysis, SIEM, ML Tools",
        "Yes"
    ],
    [
        "Compliance Report Generation Status",
        "Security & Compliance",
        "Successful generation of compliance reports (SOX, PCI DSS, HIPAA, etc.)",
        "Failed reports impact audit readiness and certifications. Business and legal risk if unable to demonstrate compliance.",
        "Monitor automated compliance report jobs. Must be available for audits with historical data per retention requirements.",
        "All reports generating successfully",
        "Report generation failures",
        "Extended outage or missing reports",
        "High",
        "Custom Compliance System, Report Monitoring",
        "Yes"
    ],
    [
        "Database Patch Level Compliance",
        "Security & Compliance",
        "Whether database is current with security patches (PSU/RU/BP)",
        "Outdated patches = known vulnerabilities exploitable. Compliance frameworks require timely patching. Security risk and audit finding.",
        "Compare V$VERSION with Oracle Security Alerts. Should be within 1-2 quarters of latest CPU/PSU/RU.",
        "Current with latest patches",
        "> 2 quarters behind",
        "> 1 year behind or known vulnerabilities",
        "Critical",
        "OEM, Custom Patch Compliance Check",
        "Yes"
    ],
    [
        "PUBLIC Privilege Audit",
        "Security & Compliance",
        "Excessive or dangerous privileges granted to PUBLIC role",
        "PUBLIC grants apply to all users. Overly permissive PUBLIC grants = security hole. Should be minimal and reviewed.",
        "Query DBA_TAB_PRIVS and DBA_SYS_PRIVS for PUBLIC grants. Remove unnecessary grants per security hardening guidelines.",
        "Minimal PUBLIC grants (Oracle defaults only)",
        "Unnecessary PUBLIC grants detected",
        "Dangerous PUBLIC grants (CREATE, ALTER, etc.)",
        "High",
        "Custom Security Audit Script",
        "Yes"
    ],
    [
        "External Authentication Failures",
        "Security & Compliance",
        "Failed external authentication attempts (Kerberos, LDAP, etc.)",
        "External auth failures may indicate AD/LDAP issues or attack. Monitoring ensures integrated authentication working properly.",
        "Monitor alert log and audit trail for external auth errors. May indicate infrastructure issues or attacks.",
        "< 5 per day (occasional issues)",
        "> 20 per day",
        "> 100 or indicating attack/outage",
        "Medium",
        "Alert Log, Audit Trail, LDAP Logs",
        "Yes"
    ]
]

# Write data rows
for row_num, row_data in enumerate(metrics_data, 2):
    for col_num, value in enumerate(row_data, 1):
        cell = ws.cell(row=row_num, column=col_num)
        cell.value = value
        cell.alignment = Alignment(vertical="top", wrap_text=True)
        cell.border = Border(
            left=Side(style='thin', color='CCCCCC'),
            right=Side(style='thin', color='CCCCCC'),
            top=Side(style='thin', color='CCCCCC'),
            bottom=Side(style='thin', color='CCCCCC')
        )
        
        # Category coloring
        if col_num == 2:  # Category column
            if value == "Real-time Operational":
                cell.fill = PatternFill(start_color="E7F4FF", end_color="E7F4FF", fill_type="solid")
            elif value == "Capacity Planning":
                cell.fill = PatternFill(start_color="FFF4E7", end_color="FFF4E7", fill_type="solid")
            elif value == "Security & Compliance":
                cell.fill = PatternFill(start_color="FFE7E7", end_color="FFE7E7", fill_type="solid")
        
        # Severity Level coloring
        if col_num == 9:  # Severity Level column
            if value == "Critical":
                cell.fill = PatternFill(start_color="FF6B6B", end_color="FF6B6B", fill_type="solid")
                cell.font = Font(bold=True, color="FFFFFF")
            elif value == "High":
                cell.fill = PatternFill(start_color="FFB366", end_color="FFB366", fill_type="solid")
                cell.font = Font(bold=True, color="FFFFFF")
            elif value == "Medium":
                cell.fill = PatternFill(start_color="FFE066", end_color="FFE066", fill_type="solid")
                cell.font = Font(bold=True)
            elif value == "Low":
                cell.fill = PatternFill(start_color="B3E6B3", end_color="B3E6B3", fill_type="solid")
        
        # Alert recommendation coloring
        if col_num == 11:  # Recommended Alert column
            if value == "Yes":
                cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
                cell.font = Font(bold=True)
            elif value == "No":
                cell.fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")

# Freeze header row
ws.freeze_panes = "A2"

# Auto-filter
ws.auto_filter.ref = f"A1:K{len(metrics_data) + 1}"

# Save workbook
wb.save("/home/ubuntu/Oracle_Database_Monitoring_Metrics.xlsx")
print("✅ Oracle Database Monitoring Metrics Excel file created successfully!")
print(f"\nTotal metrics documented: {len(metrics_data)}")
print(f"- Real-time Operational: {sum(1 for m in metrics_data if m[1] == 'Real-time Operational')}")
print(f"- Capacity Planning: {sum(1 for m in metrics_data if m[1] == 'Capacity Planning')}")
print(f"- Security & Compliance: {sum(1 for m in metrics_data if m[1] == 'Security & Compliance')}")
