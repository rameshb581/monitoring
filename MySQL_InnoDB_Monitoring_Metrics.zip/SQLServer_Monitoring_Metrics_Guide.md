# SQL Server Database Monitoring Metrics - Documentation

## 📊 Overview

This comprehensive Excel spreadsheet documents **113 critical monitoring metrics** for Microsoft SQL Server database systems. The metrics are organized into three main categories to support different operational needs:

- **Real-time Operational Metrics**: 74 metrics for day-to-day monitoring and alerting
- **Capacity Planning & Trend Analysis**: 15 metrics for long-term planning and growth forecasting
- **Security & Compliance**: 24 metrics for security monitoring and regulatory compliance

## 🎯 Purpose

This document is designed for presentation to **non-technical managers and management teams**, with a focus on:
- **Business Impact**: Clear explanations of how each metric affects revenue, user experience, and downtime costs
- **Simple Language**: Technical concepts explained in business-friendly terms
- **Visual Indicators**: Color-coded severity levels for quick assessment
- **Actionable Thresholds**: Clear warning and critical thresholds for each metric

## 📁 File Information

**File Name**: `SQLServer_Database_Monitoring_Metrics.xlsx`  
**Location**: `/home/ubuntu/SQLServer_Database_Monitoring_Metrics.xlsx`

## 📋 Column Descriptions

| Column | Description |
|--------|-------------|
| **Metric Name** | Technical name used in monitoring tools (SSMS, DMVs, Perfmon, etc.) |
| **Category** | Real-time Operational / Capacity Planning / Security & Compliance |
| **Description** | Simple explanation of what this metric measures |
| **Business Impact** | Why this matters - downtime costs, user experience, revenue impact |
| **Technical Explanation** | Simplified technical details for IT teams |
| **Normal/Healthy Range** | What values are considered good |
| **Warning Threshold** | When to pay attention |
| **Critical Threshold** | When immediate action is needed |
| **Severity Level** | Critical/High/Medium/Low (color-coded) |
| **Monitoring Tool/Exporter** | Which tool captures this metric |
| **Recommended Alert** | Yes/No - should this trigger alerts? |

## 🎨 Visual Formatting

### Category Colors
- **Light Blue** (Real-time Operational): Day-to-day monitoring metrics
- **Light Orange** (Capacity Planning): Long-term planning and trend analysis
- **Light Red** (Security & Compliance): Security and audit metrics

### Severity Level Colors
- **🔴 Red (Critical)**: Immediate business impact - service outages, security breaches
- **🟠 Orange (High)**: Significant impact - performance degradation, user experience issues
- **🟡 Yellow (Medium)**: Moderate impact - potential future issues, investigation needed
- **🟢 Green (Low)**: Minor impact - informational, trending analysis

### Alert Recommendation
- **Green "Yes"**: Should trigger automated alerts
- **Gray "No"**: Monitoring only, no immediate alerts needed

## 📊 Metric Categories Breakdown

### 1. Real-time Operational Metrics (74 metrics)

#### **Connection Metrics** (6 metrics)
- User Connections, Connection Memory, Failed Login Attempts
- Monitor active connections, connection limits, and authentication issues
- Critical for preventing service outages due to connection exhaustion

#### **Query Performance** (11 metrics)
- Batch Requests/sec, SQL Compilations/Recompilations, Average Query Execution Time
- Page Life Expectancy (PLE), Buffer Cache Hit Ratio, Checkpoint activity
- Directly impacts user experience and application responsiveness

#### **Wait Statistics** (9 metrics)
- PAGEIOLATCH (I/O waits), CXPACKET (parallelism), WRITELOG (transaction log)
- LCK_* (locking), RESOURCE_SEMAPHORE (memory grants), SOS_SCHEDULER_YIELD (CPU)
- Essential for identifying performance bottlenecks and resource contention

#### **Locks & Deadlocks** (6 metrics)
- Lock Waits, Lock Wait Time, Number of Deadlocks/sec
- Track locking issues, deadlocks, and transaction conflicts
- Affects transaction throughput and user wait times

#### **Memory Metrics** (8 metrics)
- Target vs Total Server Memory, Memory Grants Pending, Page Life Expectancy
- Stolen Server Memory, OS Available Memory, Page Faults
- Key performance indicators for database memory efficiency

#### **Transaction Log** (8 metrics)
- Log Flush Wait Time, Log Bytes Flushed/sec, Percent Log Used
- Log Growths, Active Transactions, Longest Transaction Runtime
- Critical for write performance and transaction processing

#### **TempDB** (5 metrics)
- TempDB Size, Version Store Size, Allocation Contention
- Space used by internal and user objects
- Performance bottleneck for many SQL Server workloads

#### **Plan Cache** (4 metrics)
- Plan Cache Size, Hit Ratio, Single-Use Plan Count, Evictions
- Query plan reuse and compilation efficiency

#### **Always On Availability Groups** (10 metrics)
- Synchronization State, Synchronization Health, Replica Role
- Log Send Queue, Redo Queue, Estimated Data Loss/Recovery Time
- Critical for high availability and disaster recovery

#### **Performance & Resource** (7 metrics)
- CPU Utilization, Signal Wait Time %, Disk Latency (Read/Write)
- Disk Queue Length, Errors/sec, Process Memory
- Overall system health and resource utilization

### 2. Capacity Planning & Trend Analysis (15 metrics)

#### **Storage Planning**
- Database file growth rate, Transaction log growth, TempDB growth trends
- Prevents storage-related outages and supports budget planning

#### **Resource Trending**
- Connection growth, Query volume trends, CPU/Memory usage trends
- I/O throughput trends, Average query duration trends
- Forecasts when scaling or optimization is needed

#### **Performance Trends**
- Index fragmentation trends, Table size growth, Wait statistics trends
- Statistics update frequency
- Identifies degradation patterns requiring action

#### **Backup Planning**
- Backup duration and size trends
- Impacts disaster recovery capabilities and RTO

### 3. Security & Compliance (24 metrics)

#### **Authentication & Access Control**
- Failed login attempts by IP, Permission/Role changes, Account changes
- Privileged account usage, Weak authentication accounts
- Detects security threats and policy violations

#### **Data Protection & Encryption**
- TDE (Transparent Data Encryption) status
- Always Encrypted column usage, Connection encryption ratio
- Backup encryption status, Certificate expiration
- Required for regulatory compliance (PCI DSS, HIPAA, GDPR)

#### **Audit & Compliance**
- Audit log size and retention, SQL Audit status
- Extended Events session status, C2 Audit mode
- Supports audit readiness and regulatory requirements

#### **Data Access & Security**
- Sensitive data access patterns, DDL statement execution
- SQL injection pattern detection, Data classification status
- Dynamic Data Masking usage, Row-Level Security policies
- Identifies potential security incidents and data breaches

#### **Security Configuration**
- Guest user access, Cross-database ownership chaining
- TRUSTWORTHY database property, Password policy compliance
- Ensures secure database configuration

## 🛠️ Monitoring Tools Reference

The metrics can be captured using various SQL Server monitoring tools:

### **Dynamic Management Views (DMVs) & Functions (DMFs)**
- `sys.dm_exec_connections` - Connection information
- `sys.dm_exec_requests` - Currently executing requests
- `sys.dm_os_wait_stats` - Wait statistics
- `sys.dm_os_memory_clerks` - Memory allocation
- `sys.dm_io_virtual_file_stats` - I/O statistics
- `sys.dm_hadr_*` - Always On Availability Group metrics
- `sys.dm_exec_query_stats` - Query performance statistics
- `sys.databases`, `sys.master_files` - Database configuration

### **Performance Monitor (Perfmon) Counters**
- `SQLServer:SQL Statistics` - Batch Requests, Compilations, Recompilations
- `SQLServer:Buffer Manager` - Page Life Expectancy, Buffer Cache Hit Ratio
- `SQLServer:Memory Manager` - Memory Grants, Target/Total Server Memory
- `SQLServer:Locks` - Lock waits, deadlocks, timeouts
- `SQLServer:Databases` - Log flushes, transactions, space usage
- `LogicalDisk` / `PhysicalDisk` - Disk I/O metrics

### **SQL Server Management Studio (SSMS)**
- Activity Monitor - Real-time monitoring dashboard
- Extended Events - Event capture and analysis
- Execution plans and query analysis
- Always On Dashboard

### **SQL Server Audit & Extended Events**
- Security event tracking
- Performance event capture
- Custom monitoring scenarios

### **Third-Party & Open-Source Tools**
- **Azure Monitor** - Cloud-native monitoring for Azure SQL and on-premises
- **Grafana with SQL Server Exporter** - Open-source dashboards
- **Prometheus SQL Server Exporter** - Metrics collection for Prometheus
- **SQL Server Management Data Warehouse** - Built-in data collection
- **Percona Monitoring and Management (PMM)** - Multi-database monitoring
- **Custom Scripts & Solutions** - PowerShell, T-SQL, C# monitoring applications

## 🚨 Critical Metrics Requiring Immediate Alerts

The spreadsheet identifies **96 metrics** that should trigger automated alerts (marked "Yes" in Recommended Alert column). Priority examples include:

### **Availability & Connectivity**
1. **User Connections** - Approaching connection limit
2. **Failed Login Attempts** - Security breach attempts
3. **Blocked Process Count** - Queries blocked and timing out

### **Performance Critical**
4. **Page Life Expectancy (PLE)** - Memory pressure indicator
5. **Buffer Cache Hit Ratio** - Cache efficiency below acceptable
6. **Memory Grants Pending** - Queries waiting for memory
7. **PAGEIOLATCH Waits** - I/O bottleneck
8. **WRITELOG Waits** - Transaction log performance issues

### **Transaction & Data Integrity**
9. **Number of Deadlocks/sec** - Transaction failures
10. **Percent Log Used** - Transaction log approaching full
11. **Log Growths** - Transaction log auto-growth events
12. **Longest Transaction Runtime** - Long-running transaction blocking log

### **High Availability**
13. **Synchronization State** - AG replica not synchronized
14. **Synchronization Health** - AG replica unhealthy
15. **Log Send Queue Size** - Replication lag
16. **Estimated Data Loss Time** - Potential data loss in failover

### **Security**
17. **Permission/Role Changes** - Unauthorized access modifications
18. **TDE Status** - Unencrypted databases
19. **SQL Audit Status** - Audit failure
20. **SQL Injection Pattern Detection** - Attack attempts

## 📈 How to Use This Document

### For Management & Executives
1. Review **Business Impact** column to understand why metrics matter
2. Focus on **Critical** severity metrics first (red-highlighted)
3. Use **Category** filter to view specific areas of concern
4. Check metrics marked "Yes" for recommended alerts as priority monitoring
5. Understand that SQL Server monitoring is essential for:
   - **Uptime**: Preventing database outages that stop business operations
   - **Performance**: Ensuring fast application response times
   - **Security**: Protecting sensitive data and meeting compliance
   - **Cost Control**: Optimizing resource usage and capacity planning

### For Database Administrators (DBAs)
1. Use **Metric Name** to query DMVs or configure Perfmon counters
2. Reference **Normal/Healthy Range** for baseline configuration
3. Set up alerts based on **Warning** and **Critical** thresholds
4. Review **Technical Explanation** for troubleshooting guidance
5. Implement monitoring using:
   - SQL Agent jobs with DMV queries
   - Extended Events for detailed event capture
   - SQL Server Audit for compliance tracking
   - Activity Monitor for real-time investigation

### For DevOps & SRE Teams
1. Use **Monitoring Tool/Exporter** column to implement collection
2. Prioritize metrics with **Recommended Alert = Yes**
3. Build dashboards organized by **Category**
4. Track **Capacity Planning** metrics for proactive scaling
5. Integrate with modern observability stacks:
   - Export to Prometheus + Grafana
   - Stream to Azure Monitor or Application Insights
   - Centralize logs with ELK or Splunk
   - Implement AIOps for anomaly detection

### For Security & Compliance Officers
1. Focus on **Security & Compliance** category (24 metrics)
2. Ensure all security-related alerts are configured
3. Review audit log retention and encryption status
4. Monitor privileged account activity
5. Track compliance metrics for:
   - **PCI DSS**: Encryption, access controls, audit logs
   - **HIPAA**: PHI protection, audit trails, encryption
   - **GDPR**: Data classification, access logging, data protection
   - **SOX**: Change tracking, separation of duties, audit compliance

## 🎓 Best Practices

### Initial Setup
1. **Start with Critical Metrics**: Implement high-severity alerts first
2. **Establish Baselines**: Monitor normal ranges for your workload before setting alerts (1-2 weeks)
3. **Use DMV Reset Awareness**: Some DMVs reset on restart - track deltas, not absolutes
4. **Configure Perfmon Data Collector Sets**: Automate counter collection

### Alert Configuration
5. **Avoid Alert Fatigue**: Start conservative, tune thresholds based on false positives
6. **Implement Alert Grouping**: Related metrics should trigger single incident
7. **Use Severity Levels**: Critical = page immediately, High = email, Medium = ticket
8. **Test Alert Delivery**: Verify notification chains and escalation

### Ongoing Operations
9. **Review Regularly**: Update thresholds quarterly as workload evolves
10. **Correlate Metrics**: Don't view metrics in isolation - understand relationships
11. **Capacity Planning**: Review trends monthly to prevent emergencies
12. **Document Changes**: Track when thresholds are adjusted and why
13. **Maintain Runbooks**: Create response procedures for each critical alert

### SQL Server Specific
14. **Monitor Wait Statistics**: Reset `sys.dm_os_wait_stats` periodically for accurate intervals
15. **TempDB Configuration**: Ensure proper file configuration to avoid contention
16. **Always On Monitoring**: Dedicated monitoring for AG environments
17. **Index Maintenance**: Track fragmentation and rebuild schedules
18. **Statistics Updates**: Ensure auto-update statistics is enabled

## 🔍 SQL Server Wait Statistics Deep Dive

Wait statistics are THE most important diagnostic tool for SQL Server performance. The top waits tell you the bottleneck:

| Wait Type | Bottleneck | Action |
|-----------|------------|--------|
| PAGEIOLATCH_* | Disk I/O | Add memory, improve storage speed |
| WRITELOG | Transaction log I/O | Faster log disk, reduce transaction size |
| LCK_* | Locking/Blocking | Optimize queries, reduce transaction time |
| CXPACKET | Inefficient parallelism | Adjust MAXDOP, Cost Threshold for Parallelism |
| SOS_SCHEDULER_YIELD | CPU pressure | Add CPU cores, optimize queries |
| RESOURCE_SEMAPHORE | Memory grants | Add memory, optimize queries |
| ASYNC_NETWORK_IO | Client not consuming results | Application or network issue |
| PAGELATCH_* | TempDB contention | Configure multiple TempDB files |

## 📞 Support & Maintenance

### Review Schedule
- **Daily**: Check critical alerts, blocking, long-running queries
- **Weekly**: Review wait statistics, top resource-consuming queries
- **Monthly**: Capacity planning metrics, index fragmentation, statistics staleness
- **Quarterly**: Threshold tuning, security audit review, disaster recovery testing

### Escalation Paths
- **Critical Severity**: Immediate page to on-call DBA, engage vendor support
- **High Severity**: Email to DBA team, investigate within 1 hour
- **Medium Severity**: Create ticket, investigate within 4 hours
- **Low Severity**: Log for trending, investigate during business hours

### Documentation Requirements
- Maintain runbooks for critical alert responses
- Document baseline metrics for each application/database
- Track performance tuning efforts and results
- Keep configuration change history

## 🔗 Related Resources

### Microsoft Official Documentation
- SQL Server Dynamic Management Views and Functions
- SQL Server Performance Monitoring and Tuning Guide
- Always On Availability Groups Monitoring
- SQL Server Security Best Practices
- Performance Counters (Perfmon) for SQL Server

### Third-Party Tools Documentation
- Azure Monitor for SQL Server
- Grafana SQL Server Exporter
- Prometheus SQL Server Exporter
- Percona Monitoring and Management

### Books & Learning
- "SQL Server Wait Statistics" by Paul Randal
- "SQL Server 2019 Administration Inside Out" by William Assaf et al.
- "Pro SQL Server Administration" by Peter Carter
- Microsoft Learn: SQL Server Performance and Tuning

### Community Resources
- SQL Server Central (sqlservercentral.com)
- Brent Ozar's Blog (brentozar.com)
- Paul Randal's SQLskills (sqlskills.com)
- SQL Server Reddit Community

## 💡 Key SQL Server Monitoring Insights

### The Golden Signals for SQL Server
1. **Latency**: Average query execution time, wait statistics
2. **Traffic**: Batch Requests/sec, User Connections
3. **Errors**: Errors/sec, Deadlocks, Lock Timeouts
4. **Saturation**: Page Life Expectancy, CPU %, Memory Grants Pending

### Most Important Single Metrics
- **Page Life Expectancy**: Best indicator of memory pressure
- **Batch Requests/sec**: Primary throughput metric
- **Wait Statistics**: Tells you what's slowing down SQL Server
- **Buffer Cache Hit Ratio**: Cache efficiency
- **Percent Log Used**: Transaction log health

### Common Pitfalls to Avoid
❌ **Ignoring Wait Statistics**: Most critical diagnostic tool  
❌ **Shrinking Log Files**: Creates fragmentation and growth cycles  
❌ **Single TempDB File**: Causes allocation contention  
❌ **Default MAXDOP**: Often wrong for your workload  
❌ **No Baseline Metrics**: Can't detect anomalies without normal ranges  
❌ **Alert on Cumulative Counters**: Track rate of change, not totals  
❌ **Forgetting Statistics Updates**: Leads to poor execution plans  

### Always On Availability Groups Specific
- Monitor **ALL replicas**, not just primary
- Track **log send/redo queues** continuously
- Alert on **synchronization state changes**
- Measure **estimated data loss** for async replicas
- Test **failover time** regularly (RTO validation)

---

**Document Version**: 1.0  
**Last Updated**: November 23, 2025  
**Total Metrics**: 113 (74 Real-time + 15 Capacity Planning + 24 Security)  
**Alert-Worthy Metrics**: 96  
**SQL Server Versions**: Compatible with SQL Server 2016-2022, Azure SQL Database

**Note**: Some metrics (like data classification, dynamic data masking) are available in SQL Server 2016+ or Azure SQL Database only. Adjust based on your SQL Server version.
